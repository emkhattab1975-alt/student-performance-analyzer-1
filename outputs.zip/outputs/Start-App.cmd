@echo off
setlocal
title Andalus School - Local Server
set "ANDALUS_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not exist "%ANDALUS_PYTHON%" set "ANDALUS_PYTHON=python"
echo Starting Andalus School...
echo Keep this window open while using the application.
echo When READY appears, open the exact URL printed beside it.
"%ANDALUS_PYTHON%" -u "%~dp0start_local.py" --no-browser
echo.
echo The server has stopped. Copy any error above if you need help.
pause
