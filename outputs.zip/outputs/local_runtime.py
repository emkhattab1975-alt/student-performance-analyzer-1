import socket
import time
import urllib.request


def free_port(preferred, excluded=()):
    for port in range(preferred, preferred + 30):
        if port in excluded:
            continue
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
                    probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                probe.bind(('127.0.0.1', port))
                return port
        except OSError:
            continue
    raise RuntimeError(f'No free local port near {preferred}. Close old application windows.')


def ensure_running(process, name):
    code = process.poll()
    if code is not None:
        raise RuntimeError(f'{name} exited with code {code}. See the log below.')


def wait_ready(process, name, url, timeout=180):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        ensure_running(process, name)
        try:
            with opener.open(url, timeout=3) as response:
                ready = response.status == 200
        except Exception:
            ready = False
        if ready:
            # A listener on an occupied port may belong to an older process.
            # Do not accept its response while the newly spawned process exits.
            stable_until = time.monotonic() + 2
            while time.monotonic() < stable_until:
                ensure_running(process, name)
                time.sleep(0.1)
            return
        time.sleep(0.5)
    raise RuntimeError(f'{name} readiness timed out.')
