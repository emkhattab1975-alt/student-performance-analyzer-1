$ErrorActionPreference = 'Stop'
$runtimePython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $runtimePython)) { $runtimePython = 'python' }
& $runtimePython (Join-Path $PSScriptRoot 'start_local.py') --dev
if ($LASTEXITCODE -ne 0) { throw "Preview stopped with code $LASTEXITCODE" }
