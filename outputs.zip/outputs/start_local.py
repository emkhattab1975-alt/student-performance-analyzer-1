"""Start both services; first run creates secrets, never accounts or sample data."""
import argparse
import json
import os
from pathlib import Path
import secrets
import sqlite3
from datetime import datetime
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser
from local_runtime import free_port, wait_ready, ensure_running

root = Path(__file__).absolute().parent
parser = argparse.ArgumentParser()
parser.add_argument('--dev', action='store_true')
parser.add_argument('--no-browser', action='store_true')
args = parser.parse_args()
runtime = root / '.local'
runtime.mkdir(exist_ok=True)
secret_file = runtime / 'secrets.json'
if not secret_file.exists():
    with secret_file.open('x', encoding='utf-8') as stream:
        json.dump({'jwt': secrets.token_urlsafe(48), 'setup': secrets.token_urlsafe(48)}, stream)
config = json.loads(secret_file.read_text(encoding='utf-8'))
backend_port = free_port(8000)
frontend_port = free_port(3000, (backend_port,))
app_url = f'http://127.0.0.1:{frontend_port}'
backend_url = f'http://127.0.0.1:{backend_port}'
print(f'Using frontend port {frontend_port} and backend port {backend_port}.', flush=True)
env = os.environ.copy()
env.update(ANDALUS_JWT_SECRET=config['jwt'], ANDALUS_SETUP_TOKEN=config['setup'],
           SETUP_TOKEN=config['setup'], BACKEND_URL=backend_url,
           APP_ORIGIN=app_url, NEXT_TELEMETRY_DISABLED='1',
           ANDALUS_DATABASE_URL='sqlite:///' + str(root / 'andalus-backend/storage/andalus.db').replace('\\', '/'))
workspace_deps = root.parent / 'work/python-deps'
if workspace_deps.exists():
    env['PYTHONPATH'] = str(workspace_deps)
workspace_node = root.parent / 'work/node-lts/node.exe'
node = str(workspace_node) if workspace_node.exists() else shutil.which('node')
if not node:
    raise SystemExit('Install Node.js 22 or later.')
env['PATH'] = str(Path(node).parent) + os.pathsep + env.get('PATH', '')
backend = root / 'andalus-backend'
frontend = root / 'andalus-frontend'
if not (frontend / 'node_modules/next/dist/bin/next').exists():
    raise SystemExit('Run npm ci inside andalus-frontend first.')
database_file = backend / 'storage/andalus.db'
if database_file.exists():
    backup_dir = backend / 'storage/backups'
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup_file = backup_dir / ('before-start-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '.db')
    with sqlite3.connect(str(database_file)) as source, sqlite3.connect(str(backup_file)) as target:
        source.backup(target)
        if target.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise RuntimeError('Pre-upgrade backup verification failed')
    print('Database backup verified. Updating schema...', flush=True)
subprocess.run([sys.executable, '-m', 'alembic', 'upgrade', 'head'], cwd=backend, env=env, check=True)
mode = 'dev' if args.dev else 'start'
build_dir = next((name for name in ('.next-dashboard-layout', '.next-record-delete', '.next-year-edit', '.next-years', '.next-record-layout', '.next-password-import', '.next-appearance-approved', '.next-appearance-final', '.next-student-v2', '.next-manage', '.next-excel', '.next-production') if (frontend / name / 'BUILD_ID').exists()), '.next-production')
if mode == 'start':
    env['ANDALUS_BUILD_DIR'] = build_dir
if mode == 'start' and not (frontend / build_dir / 'BUILD_ID').exists():
    raise SystemExit('Run npm run build inside andalus-frontend first, or use --dev for local preview.')
front_cmd = [node, 'node_modules/next/dist/bin/next', mode]
if mode == 'dev':
    front_cmd += ['--webpack']
front_cmd += ['--hostname', '127.0.0.1', '--port', str(frontend_port)]
processes, logs, log_paths = [], [], []
run_id = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
exit_code = 0
try:
    for name, cwd, command, url in [
        ('backend', backend, [sys.executable, '-m', 'uvicorn', 'app.main:create_app', '--factory', '--host', '127.0.0.1', '--port', str(backend_port)], backend_url + '/health'),
        ('frontend', frontend, front_cmd, app_url + '/login')]:
        log_path = runtime / (run_id + '-' + name + '.log')
        log_paths.append(log_path)
        log = log_path.open('w', encoding='utf-8')
        logs.append(log)
        proc = subprocess.Popen(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        processes.append(proc)
        wait_ready(proc, name, url)
    for proc in processes:
        ensure_running(proc, 'Server')
    (runtime / 'latest-url.txt').write_text(app_url, encoding='utf-8')
    print(f'READY {app_url} - Ctrl+C to stop', flush=True)
    if not args.no_browser:
        webbrowser.open(app_url)
    while True:
        for index, proc in enumerate(processes):
            ensure_running(proc, ('backend', 'frontend')[index])
        time.sleep(1)
except KeyboardInterrupt:
    print('Stopped by user.', flush=True)
except Exception as exc:
    exit_code = 1
    print('STARTUP ERROR: ' + str(exc), flush=True)
finally:
    for proc in reversed(processes):
        if proc.poll() is None:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                proc.terminate()
    for log in logs:
        log.close()

if exit_code:
    for path in log_paths:
        print('Log: ' + str(path), flush=True)
        tail = path.read_text(encoding='utf-8', errors='replace').replace(chr(0), '').splitlines()[-15:]
        for line in tail:
            print(line.encode(sys.stdout.encoding or 'utf-8', errors='replace').decode(sys.stdout.encoding or 'utf-8'), flush=True)
raise SystemExit(exit_code)





