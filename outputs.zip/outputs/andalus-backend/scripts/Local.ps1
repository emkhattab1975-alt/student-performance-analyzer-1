param(
    [ValidateSet('Serve', 'Bootstrap', 'Test', 'Backup')]
    [string]$Action = 'Serve',
    [string]$Username = 'admin',
    [string]$Year = '2026-2027',
    [string]$Starts = '2026-09-01',
    [string]$Ends = '2027-07-01'
)
$ErrorActionPreference = 'Stop'
$backendRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$workspaceRoot = (Resolve-Path (Join-Path $backendRoot '..\..')).Path
$pythonRuntime = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$dependencyRoot = Join-Path $workspaceRoot 'work\python-deps'
if (-not (Test-Path -LiteralPath $pythonRuntime) -or -not (Test-Path -LiteralPath $dependencyRoot)) {
    throw 'Local workspace runtime not found. Use the independent installation instructions in README.md.'
}
$env:PYTHONPATH = $dependencyRoot
$env:TEMP = Join-Path $workspaceRoot 'work\tmp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
Push-Location $backendRoot
try {
    if (-not (Test-Path -LiteralPath '.env')) {
        $secretBytes = New-Object byte[] 48
        $generator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        try { $generator.GetBytes($secretBytes) } finally { $generator.Dispose() }
        $secret = [Convert]::ToBase64String($secretBytes)
        $configuration = (Get-Content -LiteralPath '.env.example' -Raw).Replace('REPLACE_WITH_A_RANDOM_SECRET_AT_LEAST_32_CHARACTERS', $secret)
        Set-Content -LiteralPath '.env' -Value $configuration -Encoding utf8
    }
    if ($Action -eq 'Test') {
        & $pythonRuntime -m pytest --basetemp (Join-Path $workspaceRoot ('work\pytest-' + [guid]::NewGuid().ToString()))
    } else {
        & $pythonRuntime -m alembic upgrade head
        if ($LASTEXITCODE -ne 0) { throw 'Database migration failed' }
        switch ($Action) {
            'Serve' { & $pythonRuntime -m uvicorn app.main:create_app --factory --host 127.0.0.1 --port 8000 }
            'Bootstrap' { & $pythonRuntime -m app.cli bootstrap --username $Username --year $Year --starts $Starts --ends $Ends }
            'Backup' { & $pythonRuntime -m app.cli backup }
        }
    }
    if ($LASTEXITCODE -ne 0) { throw "Command failed: $LASTEXITCODE" }
} finally {
    Pop-Location
}
