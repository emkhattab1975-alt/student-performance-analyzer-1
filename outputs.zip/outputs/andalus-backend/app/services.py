from decimal import Decimal
from uuid import uuid4

from fastapi import HTTPException

from . import models as m
from .analytics import Analytics
from .repositories import AuthRepository, YearContext, YearRepository
from .security import hash_password


def seed_year(session, code, starts_on, ends_on, user_id):
    auth = AuthRepository(session)
    year = auth.add(m.AcademicYear(code=code, starts_on=starts_on, ends_on=ends_on))
    membership = auth.add(m.Membership(academic_year_id=year.id, user_id=user_id, role="SYSTEM_ADMIN"))
    repo = YearRepository(session, YearContext(year.id, user_id, membership.id, "SYSTEM_ADMIN"))
    repo.initialize_current_year()
    packages = [("MID_T1", "منتصف الفصل الأول"), ("END_T1", "نهاية الفصل الأول"), ("MID_T2", "منتصف الفصل الثاني"), ("END_T2", "نهاية الفصل الثاني (الدور الأول)")]
    for i, (code, name) in enumerate(packages, 1):
        repo.add(m.Package, code=code, name_ar=name, sequence_no=i)
    for grade, track, label in [(10, "GENERAL", "10"), (11, "SCIENCE", "11 علمي"), (11, "ARTS", "11 أدبي"), (12, "SCIENCE", "12 علمي"), (12, "ARTS", "12 أدبي")]:
        repo.add(m.Stage, code=f"{grade}_{track}", grade=grade, track=track, name_ar=label)
    for code, label, lower in [("FAIL", "راسب", 0), ("WEAK", "ضعيف", 50), ("AVERAGE", "متوسط", 60), ("GOOD", "جيد", 70), ("VERY_GOOD", "جيد جداً", 80), ("EXCELLENT", "ممتاز", 90)]:
        repo.add(m.PerformanceLevel, code=code, label=label, minimum_percent=Decimal(lower), display_order=lower)
    repo.add(m.YearSettings, updated_by=user_id)
    repo.audit("CREATE_YEAR", "academic_years", year.id, after={"code": year.code})
    return year


def snapshot(row):
    from fastapi.encoders import jsonable_encoder
    return jsonable_encoder({column.name: getattr(row, column.name) for column in row.__table__.columns
                             if column.name not in {"password_hash", "token_hash"}})


class SchoolService:
    def __init__(self, repo, defer_analytics=False):
        self.r = repo
        self.defer_analytics = defer_analytics

    def refresh_analytics(self):
        if not self.defer_analytics:
            Analytics(self.r).refresh_declines()

    def create(self, resource, data, package_id=None):
        r = self.r
        admin_resources = {"sections", "subjects", "stage-subjects"}
        if resource in admin_resources:
            r.context.require("SYSTEM_ADMIN")
        r.writable(package_id)
        values = data.model_dump()
        model = None
        if resource == "students":
            model = m.Student
        elif resource == "sections":
            r.get(m.Stage, data.stage_id)
            model = m.Section
        elif resource == "subjects":
            name = " ".join(data.name_ar.split())
            values["normalized_name"] = name
            if name == "المهارات الحياتية" or data.code.upper() == "LIFE_SKILLS":
                values.update(code="LIFE_SKILLS", is_excluded=True, is_core=False)
            else:
                values["is_core"] = (name not in {"الحوسبة", "التربية البدنية", "الفنون البصرية"}) if data.is_core is None else data.is_core
                if values["is_excluded"]:
                    values["is_core"] = False
            model = m.Subject
        elif resource == "stage-subjects":
            r.get(m.Stage, data.stage_id)
            r.get(m.Subject, data.subject_id)
            model = m.StageSubject
        elif resource == "enrollments":
            r.get(m.Student, data.student_id)
            section = r.get(m.Section, data.section_id)
            values.update(package_id=package_id, stage_id=section.stage_id)
            model = m.Enrollment
        elif resource == "maxima":
            curriculum = r.get(m.StageSubject, data.stage_subject_id)
            values.update(package_id=package_id, stage_id=curriculum.stage_id)
            existing = r.one(m.SubjectMaximum, m.SubjectMaximum.package_id == package_id, m.SubjectMaximum.stage_subject_id == data.stage_subject_id)
            if existing:
                if r.one(m.Score, m.Score.subject_maximum_id == existing.id, m.Score.score > data.max_score):
                    raise HTTPException(422, "النهاية الجديدة أقل من درجة موجودة")
                before = snapshot(existing)
                existing.max_score = data.max_score
                r.session.flush()
                r.audit("UPDATE_MAXIMUM", "subject_maxima", existing.id, before, snapshot(existing))
                r.bump(package_id)
                self.refresh_analytics()
                return existing
            model = m.SubjectMaximum
        elif resource == "assignments":
            teacher = r.get(m.Teacher, data.teacher_id)
            member = r.get(m.Membership, teacher.membership_id)
            if member.role != "TEACHER" or not member.is_active:
                raise HTTPException(422, "المعلم غير فعال")
            section, curriculum = r.get(m.Section, data.section_id), r.get(m.StageSubject, data.stage_subject_id)
            if section.stage_id != curriculum.stage_id:
                raise HTTPException(422, "المادة لا تتبع مرحلة الشعبة")
            values.update(package_id=package_id, stage_id=section.stage_id)
            model = m.Assignment
        if model is None:
            raise HTTPException(404, "مورد غير معروف")
        row = r.add(model, **values)
        r.audit("CREATE", row.__tablename__, row.id, after=snapshot(row))
        if package_id:
            r.bump(package_id)
            self.refresh_analytics()
        return row

    def scores(self, package_id, data):
        r = self.r
        package = r.writable(package_id)
        if package.data_revision != data.expected_revision:
            raise HTTPException(409, "تغيرت بيانات الباقة؛ أعد تحميلها قبل الحفظ")
        keys = [(s.enrollment_id, s.subject_maximum_id, s.round) for s in data.scores]
        if len(keys) != len(set(keys)):
            raise HTTPException(422, "درجات مكررة في الطلب")
        pending = {(s.enrollment_id, s.subject_maximum_id, s.round): s for s in data.scores}
        for item in sorted(data.scores, key=lambda s: s.round):
            enrollment = r.get(m.Enrollment, item.enrollment_id)
            maximum = r.get(m.SubjectMaximum, item.subject_maximum_id)
            if enrollment.package_id != package_id or maximum.package_id != package_id or enrollment.stage_id != maximum.stage_id:
                raise HTTPException(422, "الدرجة والانتماء والنهاية لا تتبع الباقة والمرحلة نفسيهما")
            if item.score is not None and item.score > maximum.max_score:
                raise HTTPException(422, "الدرجة تتجاوز النهاية")
            existing = r.one(m.Score, m.Score.enrollment_id == enrollment.id, m.Score.subject_maximum_id == maximum.id, m.Score.round == item.round)
            if item.round == 2:
                first = r.one(m.Score, m.Score.enrollment_id == enrollment.id, m.Score.subject_maximum_id == maximum.id, m.Score.round == 1)
                if not package.has_second_round or not first or first.score_status != "EXCUSED":
                    raise HTTPException(422, "الدور الثاني للمعذور في المادة نفسها فقط")
            elif item.score_status != "EXCUSED":
                second = r.one(m.Score, m.Score.enrollment_id == enrollment.id, m.Score.subject_maximum_id == maximum.id, m.Score.round == 2)
                if second or (enrollment.id, maximum.id, 2) in pending:
                    raise HTTPException(422, "لا يمكن إزالة العذر مع وجود سجل دور ثانٍ")
            before = snapshot(existing) if existing else None
            if existing:
                existing.score_status, existing.score = item.score_status, item.score
                r.session.flush()
                row = existing
            else:
                row = r.add(m.Score, package_id=package_id, stage_id=enrollment.stage_id, **item.model_dump())
            r.audit("UPDATE_SCORE" if before else "CREATE_SCORE", "scores", row.id, before, snapshot(row))
        r.bump(package_id)
        r.session.flush()
        self.refresh_analytics()
        revision = r.get(m.Package, package_id).data_revision
        if not self.defer_analytics:
            r.add(m.Event, event_type="SCORES_UPDATED", package_id=package_id, payload={"count": len(keys), "revision": revision},
                  deduplication_key=f"scores:{package_id}:{revision}")
        return {"saved": len(keys), "data_revision": revision}

    def package(self, package_id, data):
        r = self.r
        r.context.require("SYSTEM_ADMIN")
        r.writable()
        package = r.get(m.Package, package_id)
        if package.data_revision != data.expected_revision:
            raise HTTPException(409, "تغيرت مراجعة الباقة")
        if not data.has_second_round and r.one(m.Score, m.Score.package_id == package_id, m.Score.round == 2):
            raise HTTPException(422, "لا يمكن تعطيل الدور الثاني مع وجود درجاته")
        before = snapshot(package)
        package.has_second_round, package.status = data.has_second_round, data.status
        r.bump(package_id)
        r.audit("UPDATE_PACKAGE", "packages", package.id, before, snapshot(package))
        self.refresh_analytics()
        return package

    def settings(self, data):
        r = self.r
        r.context.require("SYSTEM_ADMIN")
        r.writable()
        settings = r.one(m.YearSettings)
        if settings.revision != data.expected_revision:
            raise HTTPException(409, "تغيرت الإعدادات")
        before = {"settings": snapshot(settings), "levels": [snapshot(l) for l in r.all(m.PerformanceLevel)]}
        settings.school_name = data.school_name
        settings.decline_threshold_pp = data.decline_threshold_pp
        settings.revision += 1
        settings.updated_by = r.context.user_id
        r.replace_levels(data.levels)
        after = {"settings": snapshot(settings), "levels": [snapshot(l) for l in r.all(m.PerformanceLevel)]}
        r.audit("UPDATE_SETTINGS", "year_settings", settings.id, before, after)
        self.refresh_analytics()
        return after

    def subject_policy(self, subject_id, data):
        r = self.r
        r.context.require("SYSTEM_ADMIN")
        r.writable()
        subject = r.get(m.Subject, subject_id)
        if (subject.code == "LIFE_SKILLS" and not data.is_excluded) or (data.is_excluded and data.is_core):
            raise HTTPException(422, "المادة المستبعدة لا تكون أساسية؛ المهارات الحياتية مستبعدة دائماً")
        before = snapshot(subject)
        subject.is_core, subject.is_excluded = data.is_core, data.is_excluded
        settings = r.one(m.YearSettings)
        settings.revision += 1
        r.session.flush()
        r.audit("UPDATE_SUBJECT_POLICY", "subjects", subject.id, before, snapshot(subject))
        self.refresh_analytics()
        return subject

    def user(self, data, *, imported_password_hash=None):
        r = self.r
        r.context.require("SYSTEM_ADMIN")
        auth = AuthRepository(r.session)
        user = auth.add(m.User(username=data.username.casefold(), display_name=data.display_name, password_hash=imported_password_hash or hash_password(data.password)))
        member = r.add(m.Membership, user_id=user.id, role=data.role)
        if data.role == "TEACHER":
            r.add(m.Teacher, membership_id=member.id, employee_code=data.employee_code)
        r.audit("CREATE_USER", "users", user.id, after={"username": user.username, "role": data.role})
        return {"id": user.id, "membership_id": member.id, "username": user.username, "role": data.role}

    def membership(self, data):
        r = self.r
        r.context.require("SYSTEM_ADMIN")
        user = AuthRepository(r.session).user(data.user_id)
        if not user:
            raise HTTPException(404, "الحساب غير موجود")
        if data.role == "TEACHER" and not data.employee_code:
            raise HTTPException(422, "رمز الموظف مطلوب")
        member = r.add(m.Membership, user_id=user.id, role=data.role)
        if data.role == "TEACHER":
            r.add(m.Teacher, membership_id=member.id, employee_code=data.employee_code)
        r.audit("ADD_MEMBERSHIP", "year_memberships", member.id, after=snapshot(member))
        return member

    def user_change(self, user_id, *, active=None, password=None, imported_password_hash=None):
        r = self.r
        r.context.require("SYSTEM_ADMIN")
        auth = AuthRepository(r.session)
        if not auth.membership(r.year, user_id):
            raise HTTPException(404, "المستخدم غير موجود في العام")
        user = auth.user(user_id)
        if user.id == r.context.user_id and active is False:
            raise HTTPException(422, "لا يمكنك تعطيل حسابك الحالي")
        if active is False and auth.would_remove_last_admin(user_id):
            raise HTTPException(422, "لا يمكن تعطيل آخر مدير نظام فعال في أي عام")
        before = {"is_active": user.is_active, "auth_version": user.auth_version}
        if active is not None:
            user.is_active = active
        if password or imported_password_hash:
            user.password_hash = imported_password_hash or hash_password(password)
        user.auth_version += 1
        auth.revoke_user(user.id)
        r.audit("RESET_PASSWORD" if password or imported_password_hash else "SET_USER_STATUS", "users", user.id, before,
                {"is_active": user.is_active, "auth_version": user.auth_version, "global_effect": True})
        return {"id": user.id, "is_active": user.is_active}
