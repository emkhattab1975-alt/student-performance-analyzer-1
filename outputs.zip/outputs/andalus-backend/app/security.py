from datetime import timedelta, timezone
from hashlib import sha256
import secrets
from uuid import uuid4

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from fastapi import HTTPException
import jwt

from . import models as m
from .db import utcnow
from .repositories import AuthRepository

hasher = PasswordHasher()
DUMMY_HASH = hasher.hash(secrets.token_urlsafe(32))


def hash_password(password):
    return hasher.hash(password)


def verify_password(password, encoded):
    try:
        return hasher.verify(encoded, password)
    except (VerificationError, InvalidHashError):
        return False


def digest(token):
    return sha256(token.encode()).hexdigest()


class AuthService:
    def __init__(self, session, settings):
        self.repo = AuthRepository(session)
        self.session = session
        self.settings = settings

    def tokens(self, user, family_id=None):
        now = utcnow().replace(tzinfo=timezone.utc)
        access = jwt.encode({"sub": user.id, "ver": user.auth_version, "type": "access", "iat": now,
            "exp": now + timedelta(minutes=self.settings.access_minutes), "jti": str(uuid4()),
            "iss": self.settings.jwt_issuer, "aud": self.settings.jwt_audience}, self.settings.jwt_secret, algorithm="HS256")
        refresh = secrets.token_urlsafe(48)
        row = self.repo.add(m.RefreshSession(user_id=user.id, token_hash=digest(refresh), family_id=family_id or str(uuid4()),
                                             expires_at=utcnow() + timedelta(days=self.settings.refresh_days)))
        return {"access_token": access, "refresh_token": refresh, "token_type": "bearer", "expires_in": self.settings.access_minutes * 60}, row

    def login(self, username, password):
        user = self.repo.by_username(username.strip().casefold())
        valid = verify_password(password, user.password_hash if user else DUMMY_HASH)
        now = utcnow()
        locked = user and user.locked_until and user.locked_until > now
        if not user or not valid or not user.is_active or locked:
            if user and not locked:
                user.failed_login_count += 1
                if user.failed_login_count >= 5:
                    user.locked_until = now + timedelta(minutes=15)
                    user.failed_login_count = 0
                self.session.commit()  # failed authentication counters must survive HTTP error
            raise HTTPException(401, "بيانات الدخول غير صحيحة أو الحساب غير متاح")
        user.failed_login_count = 0
        user.locked_until = None
        user.last_login_at = now
        if hasher.check_needs_rehash(user.password_hash):
            user.password_hash = hash_password(password)
        result, _ = self.tokens(user)
        self.session.commit()
        return result

    def refresh(self, token):
        row = self.repo.refresh(digest(token))
        if not row:
            raise HTTPException(401, "جلسة غير صالحة")
        if row.revoked_at is not None:
            self.repo.revoke_family(row.family_id)
            self.session.commit()
            raise HTTPException(401, "أعيد استخدام توكن تحديث؛ ألغيت عائلة الجلسة")
        user = self.repo.user(row.user_id)
        if row.expires_at <= utcnow() or not user or not user.is_active:
            raise HTTPException(401, "جلسة منتهية أو حساب معطل")
        if not self.repo.consume_refresh(row):
            self.repo.revoke_family(row.family_id)
            self.session.commit()
            raise HTTPException(401, "جلسة مستخدمة")
        result, replacement = self.tokens(user, row.family_id)
        row.replaced_by_id = replacement.id
        self.session.commit()
        return result

    def authenticate(self, token):
        try:
            payload = jwt.decode(token, self.settings.jwt_secret, algorithms=["HS256"], issuer=self.settings.jwt_issuer,
                                 audience=self.settings.jwt_audience, options={"require": ["exp", "iat", "sub", "ver", "type", "jti"]})
            if payload["type"] != "access":
                raise jwt.InvalidTokenError()
            user = self.repo.user(payload["sub"])
            if not user or not user.is_active or user.auth_version != payload["ver"]:
                raise jwt.InvalidTokenError()
            return user
        except jwt.InvalidTokenError:
            raise HTTPException(401, "توكن وصول غير صالح أو منتهي") from None

    def logout(self, token):
        row = self.repo.refresh(digest(token))
        if row:
            self.repo.revoke_family(row.family_id)
            self.session.commit()
