import argparse
from datetime import date
from getpass import getpass
import time

from .config import get_settings
from .db import build_engine, session_factory
from .models import User
from .repositories import AuthRepository
from .security import hash_password
from .services import seed_year


def main():
    parser = argparse.ArgumentParser(description="Andalus backend administration")
    sub = parser.add_subparsers(dest="command", required=True)
    bootstrap = sub.add_parser("bootstrap")
    bootstrap.add_argument("--username", required=True)
    bootstrap.add_argument("--year", required=True)
    bootstrap.add_argument("--starts", type=date.fromisoformat, required=True)
    bootstrap.add_argument("--ends", type=date.fromisoformat, required=True)
    backup = sub.add_parser("backup")
    backup.add_argument("--loop", action="store_true", help="Run as a separate scheduled service")
    args = parser.parse_args()
    settings = get_settings()
    engine = build_engine(settings.database_url)
    sessions = session_factory(engine)
    if args.command == "bootstrap":
        if args.ends <= args.starts:
            parser.error("Year end must follow start")
        password = getpass("Admin password (12+ characters): ")
        if len(password) < 12 or password != getpass("Repeat password: "):
            parser.error("Password too short or confirmation does not match")
        with sessions.begin() as session:
            auth = AuthRepository(session)
            if auth.any_user_exists():
                parser.error("Bootstrap only works on a database without users")
            user = auth.add(User(username=args.username.strip().casefold(), display_name="مدير النظام", password_hash=hash_password(password)))
            year = seed_year(session, args.year, args.starts, args.ends, user.id)
            print(f"Created academic year: {year.id}")
    else:
        from .backups import run_backup
        while True:
            print(run_backup(engine, settings.backup_directory))
            if not args.loop:
                break
            time.sleep(settings.backup_interval_hours * 3600)
    engine.dispose()


if __name__ == "__main__":
    main()
