"""SQLite Online Backup API: separate service, never a request background task."""
import hashlib
from pathlib import Path
import sqlite3
from uuid import uuid4

from .db import session_factory, utcnow
from .models import BackupRun


def run_backup(engine, directory):
    if engine.dialect.name != "sqlite":
        raise RuntimeError("Configure pg_dump and its restore verification when deploying PostgreSQL")
    root = Path(directory).resolve()
    root.mkdir(parents=True, exist_ok=True)
    identifier = str(uuid4())
    target = root / f"andalus-{utcnow():%Y%m%d-%H%M%S}-{identifier}.db"
    sessions = session_factory(engine)
    with sessions.begin() as session:
        session.add(BackupRun(id=identifier, trigger="SCHEDULED", status="RUNNING", started_at=utcnow()))
    try:
        with engine.connect() as source, sqlite3.connect(target) as destination:
            source.connection.driver_connection.backup(destination, pages=256)
            if destination.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("Backup integrity verification failed")
            if destination.execute("PRAGMA foreign_key_check").fetchall():
                raise RuntimeError("Backup foreign key verification failed")
        checksum = hashlib.sha256(target.read_bytes()).hexdigest()
        with sessions.begin() as session:
            row = session.get(BackupRun, identifier)
            row.status, row.storage_key, row.checksum = "COMPLETED", str(target), checksum
            row.completed_at = row.verified_at = utcnow()
            row.manifest = {"database": target.name, "schema_phase": 2, "assets": [],
                            "note": "Phase 2 has no uploaded file assets; include them when imports/branding are implemented."}
        return str(target)
    except Exception as exc:
        with sessions.begin() as session:
            row = session.get(BackupRun, identifier)
            row.status, row.error_message, row.completed_at = "FAILED", str(exc), utcnow()
        raise
