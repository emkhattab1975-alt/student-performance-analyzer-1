from datetime import date, datetime
from decimal import Decimal
from hashlib import sha256

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, ForeignKeyConstraint, Index, Integer, JSON, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base, Identity


def uq(*cols):
    return UniqueConstraint("academic_year_id", *cols)


def ref(table, local, remote=None):
    remote = remote or ["id"]
    return ForeignKeyConstraint(["academic_year_id", *local], [f"{table}.academic_year_id", *[f"{table}.{c}" for c in remote]], ondelete="RESTRICT")


class Annual(Identity):
    academic_year_id: Mapped[str] = mapped_column(ForeignKey("academic_years.id", ondelete="RESTRICT"), index=True)


class AcademicYear(Identity, Base):
    __tablename__ = "academic_years"
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    starts_on: Mapped[date] = mapped_column(Date)
    ends_on: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(12), default="OPEN")
    __table_args__ = (CheckConstraint("ends_on > starts_on", name="dates"), CheckConstraint("status IN ('OPEN','CLOSED')", name="status"))


class SystemState(Base):
    __tablename__ = "system_state"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    current_year_id: Mapped[str | None] = mapped_column(ForeignKey("academic_years.id", ondelete="RESTRICT"))
    __table_args__ = (CheckConstraint("id = 1", name="singleton"),)


class User(Identity, Base):
    __tablename__ = "users"
    username: Mapped[str] = mapped_column(String(100), unique=True)
    display_name: Mapped[str] = mapped_column(String(200))
    password_hash: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    auth_version: Mapped[int] = mapped_column(Integer, default=1)
    failed_login_count: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime)


class Membership(Annual, Base):
    __tablename__ = "year_memberships"
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    role: Mapped[str] = mapped_column(String(20))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (uq("id"), uq("user_id"), CheckConstraint("role IN ('SYSTEM_ADMIN','PRINCIPAL','TEACHER')", name="role"))


class Package(Annual, Base):
    __tablename__ = "packages"
    code: Mapped[str] = mapped_column(String(30))
    name_ar: Mapped[str] = mapped_column(String(100))
    sequence_no: Mapped[int] = mapped_column(Integer)
    has_second_round: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(15), default="DRAFT")
    data_revision: Mapped[int] = mapped_column(Integer, default=0)
    __table_args__ = (uq("id"), uq("code"), uq("sequence_no"), CheckConstraint("sequence_no BETWEEN 1 AND 4", name="sequence"), CheckConstraint("status IN ('DRAFT','PUBLISHED','LOCKED')", name="status"))


class Student(Annual, Base):
    __tablename__ = "students"
    personal_number: Mapped[str] = mapped_column(String(32))
    full_name: Mapped[str] = mapped_column(String(200))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (uq("id"), uq("personal_number"), Index("ix_students_year_name", "academic_year_id", "full_name"))


class Stage(Annual, Base):
    __tablename__ = "stages"
    code: Mapped[str] = mapped_column(String(20))
    grade: Mapped[int] = mapped_column(Integer)
    track: Mapped[str] = mapped_column(String(15))
    name_ar: Mapped[str] = mapped_column(String(60))
    __table_args__ = (uq("id"), uq("code"), uq("grade", "track"), CheckConstraint("(grade = 10 AND track = 'GENERAL') OR (grade IN (11,12) AND track IN ('SCIENCE','ARTS'))", name="stage"))


class Section(Annual, Base):
    __tablename__ = "sections"
    stage_id: Mapped[str] = mapped_column(String(36))
    code: Mapped[str] = mapped_column(String(30))
    name_ar: Mapped[str] = mapped_column(String(60))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (uq("id"), uq("stage_id", "id"), uq("stage_id", "code"), ref("stages", ["stage_id"]))


class Subject(Annual, Base):
    __tablename__ = "subjects"
    code: Mapped[str] = mapped_column(String(30))
    name_ar: Mapped[str] = mapped_column(String(100))
    normalized_name: Mapped[str] = mapped_column(String(100))
    is_core: Mapped[bool] = mapped_column(Boolean, default=True)
    is_excluded: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (uq("id"), uq("code"), uq("normalized_name"), CheckConstraint("NOT is_excluded OR NOT is_core", name="excluded_not_core"), CheckConstraint("code <> 'LIFE_SKILLS' OR is_excluded", name="life_excluded"))


class StageSubject(Annual, Base):
    __tablename__ = "stage_subjects"
    stage_id: Mapped[str] = mapped_column(String(36))
    subject_id: Mapped[str] = mapped_column(String(36))
    display_order: Mapped[int] = mapped_column(Integer, default=0)
    __table_args__ = (uq("id"), uq("stage_id", "id"), uq("stage_id", "subject_id"), ref("stages", ["stage_id"]), ref("subjects", ["subject_id"]))


class Teacher(Annual, Base):
    __tablename__ = "teachers"
    membership_id: Mapped[str] = mapped_column(String(36))
    employee_code: Mapped[str] = mapped_column(String(40))
    __table_args__ = (uq("id"), uq("membership_id"), uq("employee_code"), ref("year_memberships", ["membership_id"]))


class ImportScope(Annual, Base):
    __tablename__ = "import_scopes"
    package_id: Mapped[str] = mapped_column(String(36))
    stage_id: Mapped[str] = mapped_column(String(36))
    kind: Mapped[str] = mapped_column(String(20))
    round_key: Mapped[int] = mapped_column(Integer)
    active_batch_id: Mapped[str | None] = mapped_column(String(36))
    revision: Mapped[int] = mapped_column(Integer, default=0)
    __table_args__ = (uq("id"), uq("package_id", "stage_id", "kind", "round_key"), ref("packages", ["package_id"]), ref("stages", ["stage_id"]),
        ForeignKeyConstraint(["academic_year_id", "id", "active_batch_id"], ["import_batches.academic_year_id", "import_batches.scope_id", "import_batches.id"], name="fk_scope_active_batch", use_alter=True),
        CheckConstraint("(kind = 'GRADES' AND round_key IN (1,2)) OR (kind IN ('MAXIMA','ASSIGNMENTS') AND round_key = 0)", name="kind_round"))


class ImportBatch(Annual, Base):
    __tablename__ = "import_batches"
    scope_id: Mapped[str] = mapped_column(String(36))
    upload_group_id: Mapped[str] = mapped_column(String(36))
    version_no: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20))
    original_filename: Mapped[str] = mapped_column(Text)
    source_storage_key: Mapped[str] = mapped_column(Text)
    normalized_storage_key: Mapped[str | None] = mapped_column(Text)
    source_sha256: Mapped[str] = mapped_column(String(64))
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    validation_summary: Mapped[dict] = mapped_column(JSON, default=dict)
    dependency_revisions: Mapped[dict] = mapped_column(JSON, default=dict)
    uploaded_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    approved_by: Mapped[str | None] = mapped_column(ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime)
    __table_args__ = (uq("id"), uq("scope_id", "id"), uq("scope_id", "version_no"), ref("import_scopes", ["scope_id"]), CheckConstraint("version_no > 0", name="version"), CheckConstraint("status IN ('UPLOADED','VALIDATING','INVALID','READY','APPLIED','SUPERSEDED')", name="status"))


class Enrollment(Annual, Base):
    __tablename__ = "student_enrollments"
    package_id: Mapped[str] = mapped_column(String(36))
    student_id: Mapped[str] = mapped_column(String(36))
    stage_id: Mapped[str] = mapped_column(String(36))
    section_id: Mapped[str] = mapped_column(String(36))
    source_batch_id: Mapped[str | None] = mapped_column(String(36))
    __table_args__ = (uq("id"), uq("package_id", "student_id"), uq("package_id", "stage_id", "id"), ref("packages", ["package_id"]), ref("students", ["student_id"]), ref("sections", ["stage_id", "section_id"], ["stage_id", "id"]), ref("import_batches", ["source_batch_id"]), Index("ix_enrollments_scope", "academic_year_id", "package_id", "stage_id", "section_id"))


class SubjectMaximum(Annual, Base):
    __tablename__ = "subject_maxima"
    package_id: Mapped[str] = mapped_column(String(36))
    stage_id: Mapped[str] = mapped_column(String(36))
    stage_subject_id: Mapped[str] = mapped_column(String(36))
    max_score: Mapped[Decimal] = mapped_column(Numeric(10, 2))
    source_batch_id: Mapped[str | None] = mapped_column(String(36))
    __table_args__ = (uq("id"), uq("package_id", "stage_subject_id"), uq("package_id", "stage_id", "id"), ref("packages", ["package_id"]), ref("stage_subjects", ["stage_id", "stage_subject_id"], ["stage_id", "id"]), ref("import_batches", ["source_batch_id"]), CheckConstraint("max_score > 0", name="positive"))


class Score(Annual, Base):
    __tablename__ = "scores"
    package_id: Mapped[str] = mapped_column(String(36))
    stage_id: Mapped[str] = mapped_column(String(36))
    enrollment_id: Mapped[str] = mapped_column(String(36))
    subject_maximum_id: Mapped[str] = mapped_column(String(36))
    round: Mapped[int] = mapped_column(Integer)
    score_status: Mapped[str | None] = mapped_column(String(10))
    score: Mapped[Decimal | None] = mapped_column(Numeric(10, 2))
    source_batch_id: Mapped[str | None] = mapped_column(String(36))
    __table_args__ = (uq("id"), uq("enrollment_id", "subject_maximum_id", "round"),
        ref("student_enrollments", ["package_id", "stage_id", "enrollment_id"], ["package_id", "stage_id", "id"]),
        ref("subject_maxima", ["package_id", "stage_id", "subject_maximum_id"], ["package_id", "stage_id", "id"]), ref("import_batches", ["source_batch_id"]),
        CheckConstraint("round IN (1,2)", name="round"),
        CheckConstraint("(score_status IS NULL AND score IS NULL) OR (score_status IS NOT NULL AND ((score_status = 'PRESENT' AND score IS NOT NULL AND score >= 0) OR (score_status IN ('ABSENT','CHEATING','EXCUSED') AND score IS NULL)))", name="status_value"),
        Index("ix_scores_analytics", "academic_year_id", "package_id", "subject_maximum_id", "round", "score_status"))


class Assignment(Annual, Base):
    __tablename__ = "teaching_assignments"
    package_id: Mapped[str] = mapped_column(String(36))
    teacher_id: Mapped[str] = mapped_column(String(36))
    stage_id: Mapped[str] = mapped_column(String(36))
    section_id: Mapped[str] = mapped_column(String(36))
    stage_subject_id: Mapped[str] = mapped_column(String(36))
    source_batch_id: Mapped[str | None] = mapped_column(String(36))
    __table_args__ = (uq("id"), uq("package_id", "teacher_id", "section_id", "stage_subject_id"), ref("packages", ["package_id"]), ref("teachers", ["teacher_id"]), ref("sections", ["stage_id", "section_id"], ["stage_id", "id"]), ref("stage_subjects", ["stage_id", "stage_subject_id"], ["stage_id", "id"]), ref("import_batches", ["source_batch_id"]), Index("ix_assignments_teacher", "academic_year_id", "package_id", "teacher_id"))


class YearSettings(Annual, Base):
    __tablename__ = "year_settings"
    school_name: Mapped[str] = mapped_column(String(200), default="مجمع الأندلس التعليمي")
    logo_storage_key: Mapped[str | None] = mapped_column(Text)
    institution_info: Mapped[dict] = mapped_column(JSON, default=dict)
    header_text: Mapped[str | None] = mapped_column(Text)
    footer_text: Mapped[str | None] = mapped_column(Text)
    decline_threshold_pp: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=Decimal("10"))
    revision: Mapped[int] = mapped_column(Integer, default=1)
    updated_by: Mapped[str | None] = mapped_column(ForeignKey("users.id"))
    __table_args__ = (uq("id"), UniqueConstraint("academic_year_id"), CheckConstraint("decline_threshold_pp > 0 AND decline_threshold_pp <= 100", name="threshold"))


class PerformanceLevel(Annual, Base):
    __tablename__ = "performance_levels"
    code: Mapped[str] = mapped_column(String(20))
    label: Mapped[str] = mapped_column(String(50))
    minimum_percent: Mapped[Decimal] = mapped_column(Numeric(5, 2))
    display_order: Mapped[int] = mapped_column(Integer)
    __table_args__ = (uq("id"), uq("code"), uq("minimum_percent"), CheckConstraint("minimum_percent BETWEEN 0 AND 100", name="minimum"))


class ExcelUpload(Annual, Base):
    __tablename__ = "excel_uploads"
    uploaded_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    package_id: Mapped[str | None] = mapped_column(String(36))
    kind: Mapped[str] = mapped_column(String(20))
    filename: Mapped[str] = mapped_column(String(200))
    source_sha256: Mapped[str] = mapped_column(String(64))
    source_base64: Mapped[str] = mapped_column(Text)
    payload: Mapped[dict] = mapped_column(JSON)
    preview: Mapped[dict] = mapped_column(JSON)
    fingerprint: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(12))
    applied_at: Mapped[datetime | None] = mapped_column(DateTime)
    __table_args__ = (uq("id"), ref("packages", ["package_id"]), CheckConstraint("status IN ('READY','INVALID','APPLIED')", name="status"))


class ImportErrorRow(Annual, Base):
    __tablename__ = "import_errors"
    batch_id: Mapped[str] = mapped_column(String(36))
    sheet_name: Mapped[str] = mapped_column(String(100))
    row_number: Mapped[int | None] = mapped_column(Integer)
    column_name: Mapped[str | None] = mapped_column(String(100))
    error_code: Mapped[str] = mapped_column(String(50))
    severity: Mapped[str] = mapped_column(String(10))
    message: Mapped[str] = mapped_column(Text)
    raw_value: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (uq("id"), ref("import_batches", ["batch_id"]), Index("ix_errors_batch", "academic_year_id", "batch_id", "severity"))


class AuditLog(Annual, Base):
    __tablename__ = "audit_logs"
    actor_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(60))
    entity_type: Mapped[str] = mapped_column(String(60))
    entity_id: Mapped[str | None] = mapped_column(String(36))
    before_json: Mapped[dict | None] = mapped_column(JSON)
    after_json: Mapped[dict | None] = mapped_column(JSON)
    request_id: Mapped[str] = mapped_column(String(36))
    ip_address: Mapped[str | None] = mapped_column(String(45))
    outcome: Mapped[str] = mapped_column(String(15), default="SUCCESS")
    __table_args__ = (uq("id"), Index("ix_audit_time", "academic_year_id", "created_at"), Index("ix_audit_entity", "academic_year_id", "entity_type", "entity_id"))


class RefreshSession(Identity, Base):
    __tablename__ = "refresh_sessions"
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True)
    family_id: Mapped[str] = mapped_column(String(36), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime)
    replaced_by_id: Mapped[str | None] = mapped_column(ForeignKey("refresh_sessions.id"))


class Event(Annual, Base):
    __tablename__ = "events"
    event_type: Mapped[str] = mapped_column(String(50))
    package_id: Mapped[str | None] = mapped_column(String(36))
    stage_id: Mapped[str | None] = mapped_column(String(36))
    section_id: Mapped[str | None] = mapped_column(String(36))
    subject_id: Mapped[str | None] = mapped_column(String(36))
    payload: Mapped[dict] = mapped_column(JSON)
    deduplication_key: Mapped[str] = mapped_column(String(200))
    published_at: Mapped[datetime | None] = mapped_column(DateTime)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime)
    __table_args__ = (uq("id"), uq("deduplication_key"), ref("packages", ["package_id"]), ref("stages", ["stage_id"]), ref("sections", ["section_id"]), ref("subjects", ["subject_id"]))


class EventReceipt(Annual, Base):
    __tablename__ = "event_receipts"
    event_id: Mapped[str] = mapped_column(String(36))
    membership_id: Mapped[str] = mapped_column(String(36))
    read_at: Mapped[datetime | None] = mapped_column(DateTime)
    __table_args__ = (uq("id"), uq("event_id", "membership_id"), ref("events", ["event_id"]), ref("year_memberships", ["membership_id"]))


class ReportRun(Annual, Base):
    __tablename__ = "report_runs"
    requested_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    report_type: Mapped[str] = mapped_column(String(40))
    filters: Mapped[dict] = mapped_column(JSON)
    dependency_revisions: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(20))
    output_storage_key: Mapped[str | None] = mapped_column(Text)
    output_sha256: Mapped[str | None] = mapped_column(String(64))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime)
    error_message: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (uq("id"), Index("ix_reports_requester", "academic_year_id", "requested_by", "created_at"))


class BackupRun(Identity, Base):
    __tablename__ = "backup_runs"
    requested_by: Mapped[str | None] = mapped_column(ForeignKey("users.id"))
    trigger: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(20))
    storage_key: Mapped[str | None] = mapped_column(Text)
    manifest: Mapped[dict | None] = mapped_column(JSON)
    checksum: Mapped[str | None] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime)
    error_message: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (Index("ix_backups_status", "status", "started_at"),)


# Index child foreign keys unless an existing index/unique key already covers the prefix.
# The year is always the leading column for annual cross-table relations.
for _table in Base.metadata.tables.values():
    _covered = [tuple(c.name for c in index.columns) for index in _table.indexes]
    _covered += [tuple(c.name for c in constraint.columns) for constraint in _table.constraints
                 if isinstance(constraint, UniqueConstraint)]
    for _foreign_key in _table.foreign_key_constraints:
        _columns = tuple(c.name for c in _foreign_key.columns)
        if not any(cols[:len(_columns)] == _columns for cols in _covered):
            _index_name = f"ix_{_table.name}_fk_{'_'.join(_columns)}"
            if len(_index_name) > 60:
                _index_name = _index_name[:49] + "_" + sha256(_index_name.encode()).hexdigest()[:10]
            Index(_index_name, *[_table.c[c] for c in _columns])
            _covered.append(_columns)

