"""Year-scoped edit and reviewed deletion; dependencies are never silently cascaded."""
from datetime import datetime, timezone, timedelta
from hashlib import sha256
import json
import jwt
from fastapi import HTTPException
from pydantic import Field, ValidationError
from . import models as m, schemas as s, cascade_deletion
from .analytics import Analytics
from .excel_import import fingerprint
from .repositories import AuthRepository
from .services import SchoolService, snapshot

MODELS={'sections':m.Section,'subjects':m.Subject,'students':m.Student,'teachers':m.Teacher,
        'scores':m.Score,'assignments':m.Assignment,'maxima':m.SubjectMaximum,'enrollments':m.Enrollment}
ADMIN={'sections','subjects','teachers'}
PACKAGED={'scores','assignments','maxima','enrollments'}

class EditInput(s.Input):
    revision: str
    values: dict

class Selection(s.Input):
    cascade: bool = False
    ids: list[str] = Field(min_length=1,max_length=5000)
    revision: str

class Confirmation(s.Input):
    token: str = Field(min_length=1,max_length=400000)

class StudentEnrollmentEdit(s.Input):
    section_id: s.Identifier
    full_name: s.Name | None = None


class TeacherEdit(s.Input):
    username: str = Field(min_length=3,max_length=100,pattern=r'^[a-zA-Z0-9_.@-]+$')
    display_name: s.Name
    employee_code: str = Field(min_length=1,max_length=40)
    is_active: bool


def authorize(r,kind,pid=None,write=False):
    if kind not in MODELS: raise HTTPException(404,'نوع سجل غير معروف')
    r.context.require(*(('SYSTEM_ADMIN',) if kind in ADMIN else ('SYSTEM_ADMIN','PRINCIPAL')))
    if kind in PACKAGED:
        if not pid: raise HTTPException(422,'اختر الباقة')
        r.get(m.Package,pid)
    elif pid is not None:
        raise HTTPException(422,'هذا النوع يخص العام كله ولا يقبل باقة')
    if write:r.writable(pid)


def revision(r):
    data=[fingerprint(r)]
    for model in (m.Assignment,m.Event,m.EventReceipt):
        data.append(sorted([snapshot(x) for x in r.all(model)],key=lambda x:x["id"]))
    auth=AuthRepository(r.session)
    for teacher in sorted(r.all(m.Teacher),key=lambda t:t.id):
        member=r.get(m.Membership,teacher.membership_id)
        user=auth.user(member.user_id)
        data.append([user.id,user.username,user.display_name,user.is_active,user.auth_version])
    return sha256(json.dumps(data,ensure_ascii=False).encode()).hexdigest()


def verify(r,expected):
    if revision(r)!=expected: raise HTTPException(409,'تغيرت البيانات؛ حدّث القائمة وراجع التغييرات مجدداً')


def scoped_row(r,kind,identifier,pid):
    row=r.get(MODELS[kind],identifier)
    if kind in PACKAGED and row.package_id!=pid: raise HTTPException(404,'السجل لا يتبع الباقة المعروضة')
    return row


def field(name,label,type='text',options=None,required=True):
    return {'name':name,'label':label,'type':type,'options':options,'required':required}


def listing(r,kind,pid=None):
    authorize(r,kind,pid)
    stages={x.id:x.name_ar for x in r.all(m.Stage)}
    sections={x.id:x for x in r.all(m.Section)}
    subjects={x.id:x for x in r.all(m.Subject)}
    curricula={x.id:x for x in r.all(m.StageSubject)}
    students={x.id:x for x in r.all(m.Student)}
    enrollments={x.id:x for x in r.all(m.Enrollment)}
    maxima={x.id:x for x in r.all(m.SubjectMaximum)}
    auth=AuthRepository(r.session)
    teachers={x.id:(x,r.get(m.Membership,x.membership_id)) for x in r.all(m.Teacher)}
    teacher_names={key:auth.user(member.user_id).display_name for key,(teacher,member) in teachers.items()}
    def sec_label(sec):return stages[sec.stage_id]+' / '+sec.name_ar
    def cur_label(cur):return stages[cur.stage_id]+' / '+subjects[cur.subject_id].name_ar
    fields={
        'sections':[field('code','رمز الشعبة'),field('name_ar','اسم الشعبة')],
        'subjects':[field('code','رمز المادة'),field('name_ar','اسم المادة'),field('is_core','مادة أساسية','checkbox'),field('is_excluded','مستبعدة من الحساب','checkbox')],
        'students':[field('personal_number','الرقم الشخصي'),field('full_name','اسم الطالب')],
        'teachers':[field('username','اسم المستخدم دون مسافات'),field('display_name','اسم المعلم'),field('employee_code','رمز الموظف'),field('is_active','عضوية العام فعالة','checkbox')],
        'enrollments':[field('full_name','اسم الطالب'),field('section_id','الشعبة','select',[{'value':x.id,'label':sec_label(x)} for x in sections.values()])],
        'maxima':[field('max_score','الدرجة النهائية','number')],
        'scores':[field('score_status','الحالة','select',[{'value':v,'label':label} for v,label in [('', 'غير مسجلة'),('PRESENT','حاضر'),('ABSENT','غائب'),('CHEATING','غش'),('EXCUSED','معذور')]],False),field('score','الدرجة','number',required=False)],
        'assignments':[field('teacher_id','المعلم','select',[{'value':key,'label':teacher_names[key]} for key,(_,member) in teachers.items() if member.is_active]),field('section_id','الشعبة','select',[{'value':x.id,'label':sec_label(x)} for x in sections.values()]),field('stage_subject_id','المادة والصف','select',[{'value':x.id,'label':cur_label(x)} for x in curricula.values()])]
    }[kind]
    rows=[]
    for row in r.all(MODELS[kind],*([MODELS[kind].package_id==pid] if kind in PACKAGED else [])):
        values=snapshot(row)
        label,details='', ''
        if kind=='sections': label=row.name_ar;details=stages[row.stage_id]+' · '+row.code
        elif kind=='subjects':label=row.name_ar;details=row.code
        elif kind=='students':label=row.full_name;details=row.personal_number
        elif kind=='teachers':
            member=r.get(m.Membership,row.membership_id);user=auth.user(member.user_id)
            label=user.display_name;details=user.username+' · '+row.employee_code+(' · معطل في هذا العام' if not member.is_active else '')
            values={'username':user.username,'display_name':user.display_name,'employee_code':row.employee_code,'is_active':member.is_active}
        elif kind=='enrollments':
            label=students[row.student_id].full_name
            details=sec_label(sections[row.section_id])+' · '+students[row.student_id].personal_number
            values['full_name']=students[row.student_id].full_name
        elif kind=='maxima':label=cur_label(curricula[row.stage_subject_id]);details=str(row.max_score)
        elif kind=='assignments':label=teacher_names[row.teacher_id];details=sec_label(sections[row.section_id])+' · '+cur_label(curricula[row.stage_subject_id])
        elif kind=='scores':
            en=enrollments[row.enrollment_id];maximum=maxima[row.subject_maximum_id]
            label=students[en.student_id].full_name
            status={'PRESENT':str(row.score),'ABSENT':'غائب','CHEATING':'غش','EXCUSED':'معذور',None:'غير مسجلة'}[row.score_status]
            details=sec_label(sections[en.section_id])+' · '+cur_label(curricula[maximum.stage_subject_id])+' · الدور '+str(row.round)+' · '+status
        rows.append({'id':row.id,'label':label,'details':details,'values':{f['name']:values.get(f['name']) for f in fields}})
    return {'revision':revision(r),'fields':fields,'rows':sorted(rows,key=lambda x:(x['label'],x['id'])),
            'delete_action':'تعطيل عضوية العام' if kind=='teachers' and r.context.role!='SYSTEM_ADMIN' else 'حذف',
            'notice':'تعديل اسم المعلم واسم دخوله يسري على حسابه في جميع الأعوام. الحذف يزيل ملف المعلم وعضويته وأنصبته من هذا العام فقط؛ يبقى حساب الدخول العام وأي عضويات في الأعوام الأخرى محفوظة.' if kind=='teachers' else 'تصحيح الاسم يسري على الطالب في جميع باقات العام الحالي. تغيير الشعبة يخص الباقة المختارة فقط. حذف هذا السجل يخص الانتماء ولا يحذف الطالب.' if kind=='enrollments' else 'لمدير النظام: تُعرض السجلات التابعة التي سيشملها الحذف في المعاينة قبل التأكيد. الحذف يخص العام المعروض فقط.'}


def edit(r,kind,identifier,pid,data):
    authorize(r,kind,pid,True);verify(r,data.revision)
    row=scoped_row(r,kind,identifier,pid)
    allowed={'sections':{'code','name_ar'},'subjects':{'code','name_ar','is_core','is_excluded'},
             'students':{'personal_number','full_name'},'teachers':{'username','display_name','employee_code','is_active'},
             'enrollments':{'section_id','full_name'},'scores':{'score_status','score'},'maxima':{'max_score'},
             'assignments':{'teacher_id','section_id','stage_subject_id'}}
    if set(data.values)-allowed[kind]:raise HTTPException(422,'حقول غير مسموحة للتعديل')
    before=snapshot(row);service=SchoolService(r)
    try:
        if kind=='sections':
            values=s.SectionInput(stage_id=row.stage_id,**data.values).model_dump()
        elif kind=='students': values=s.StudentInput(**data.values).model_dump()
        elif kind=='subjects':
            values=s.SubjectInput(**data.values).model_dump()
            if values['is_core'] is None: values['is_core']=row.is_core
            if row.code=='LIFE_SKILLS' and (values['code']!='LIFE_SKILLS' or values['name_ar']!='المهارات الحياتية'):
                raise HTTPException(422,'لا يمكن تغيير هوية مادة المهارات الحياتية')
            if values['name_ar']=='المهارات الحياتية' or values['code'].upper()=='LIFE_SKILLS':
                values.update(code='LIFE_SKILLS',name_ar='المهارات الحياتية',is_core=False,is_excluded=True)
            if values['is_excluded'] and values['is_core']: raise HTTPException(422,'المادة المستبعدة لا تكون أساسية')
            values['normalized_name']=' '.join(values['name_ar'].split())
        elif kind=='teachers':
            value=TeacherEdit(**data.values)
            member=r.get(m.Membership,row.membership_id)
            if member.role!='TEACHER': raise HTTPException(409,'عضوية هذا الحساب لم تعد عضوية معلم')
            auth=AuthRepository(r.session);user=auth.user(member.user_id)
            before={'teacher':before,'user':{'username':user.username,'display_name':user.display_name},'membership_active':member.is_active}
            if user.username!=value.username.casefold():
                user.auth_version+=1;auth.revoke_user(user.id)
            user.username=value.username.casefold();user.display_name=value.display_name
            row.employee_code=value.employee_code;member.is_active=value.is_active
            values={}
        elif kind=='enrollments':
            value=StudentEnrollmentEdit(**data.values)
            section=r.get(m.Section,value.section_id)
            if section.stage_id!=row.stage_id and r.one(m.Score,m.Score.enrollment_id==row.id):
                raise HTTPException(422,'لا يمكن تغيير المسار مع وجود درجات؛ راجع درجات الطالب أولاً')
            student=r.get(m.Student,row.student_id)
            if value.full_name is not None and value.full_name!=student.full_name:
                student_before=snapshot(student)
                student.full_name=value.full_name
                r.audit('EDIT_RECORD',student.__tablename__,student.id,student_before,snapshot(student))
            values={'section_id':section.id,'stage_id':section.stage_id}
        elif kind=='assignments':
            value=s.AssignmentInput(**data.values);section=r.get(m.Section,value.section_id);cur=r.get(m.StageSubject,value.stage_subject_id)
            teacher=r.get(m.Teacher,value.teacher_id);member=r.get(m.Membership,teacher.membership_id)
            if not member.is_active or member.role!='TEACHER':raise HTTPException(422,'عضوية المعلم غير فعالة')
            if section.stage_id!=cur.stage_id:raise HTTPException(422,'المادة لا تتبع صف الشعبة')
            values={**value.model_dump(),'stage_id':section.stage_id}
        elif kind=='maxima':
            service.create('maxima',s.MaximumInput(stage_subject_id=row.stage_subject_id,**data.values),pid)
            return {'saved':True}
        elif kind=='scores':
            value=s.ScoreInput(enrollment_id=row.enrollment_id,subject_maximum_id=row.subject_maximum_id,round=row.round,**data.values)
            service.scores(pid,s.ScoreBatch(expected_revision=r.get(m.Package,pid).data_revision,scores=[value]))
            return {'saved':True}
    except ValidationError as exc:
        if kind=='enrollments':
            raise HTTPException(422,'اسم الطالب مطلوب وبحد أقصى ٢٠٠ محرف، ويجب اختيار شعبة صالحة') from None
        raise HTTPException(422,'تحقق من الحقول: الرقم الشخصي أرقام فقط، اسم المستخدم دون مسافات، والدرجة غير سالبة وبمنزلتين عشريتين كحد أقصى') from None
    for key,value in values.items():setattr(row,key,value)
    r.session.flush()
    after=snapshot(row)
    if kind=='teachers': after={'teacher':after,'user':{'username':user.username,'display_name':user.display_name},'membership_active':member.is_active}
    r.audit('EDIT_RECORD',row.__tablename__,row.id,before,after)
    if pid:r.bump(pid)
    if kind=='subjects':r.one(m.YearSettings).revision+=1
    Analytics(r).refresh_declines()
    return {'saved':True}


def dependencies(r,kind,row,selected):
    def has(model,*conditions):return r.one(model,*conditions) is not None
    if kind=='sections':
        if has(m.Enrollment,m.Enrollment.section_id==row.id) or has(m.Assignment,m.Assignment.section_id==row.id) or has(m.Event,m.Event.section_id==row.id):
            return 'الشعبة مرتبطة بانتماءات طلاب أو أنصبة أو تنبيهات محفوظة'
    if kind=='subjects':
        if has(m.Event,m.Event.subject_id==row.id):return 'المادة مرتبطة بتنبيهات محفوظة'
        for cur in r.all(m.StageSubject,m.StageSubject.subject_id==row.id):
            if has(m.SubjectMaximum,m.SubjectMaximum.stage_subject_id==cur.id) or has(m.Assignment,m.Assignment.stage_subject_id==cur.id):
                return 'المادة مرتبطة بنهايات أو أنصبة؛ راجعها قبل حذف المادة'
    if kind=='students' and has(m.Enrollment,m.Enrollment.student_id==row.id):return 'الطالب مرتبط بانتماءات محفوظة؛ راجع درجاته وانتماءاته أولاً'
    if kind=='enrollments' and has(m.Score,m.Score.enrollment_id==row.id):return 'الانتماء مرتبط بدرجات؛ احذف الدرجات المطلوبة أولاً بعد مراجعتها'
    if kind=='maxima' and has(m.Score,m.Score.subject_maximum_id==row.id):return 'النهاية مرتبطة بدرجات؛ لا يمكن حذفها قبل مراجعة الدرجات'
    if kind=='scores' and row.round==1:
        second=r.one(m.Score,m.Score.enrollment_id==row.enrollment_id,m.Score.subject_maximum_id==row.subject_maximum_id,m.Score.round==2)
        if second and second.id not in selected:return 'حدد درجة الدور الثاني المرتبطة أيضاً أو احذفها أولاً'
    return None


def delete_preview(r,kind,pid,data,secret):
    authorize(r,kind,pid,True);verify(r,data.revision)
    if data.cascade:
        r.context.require('SYSTEM_ADMIN')
        ids=sorted(set(data.ids))
        rows=[scoped_row(r,kind,identifier,pid) for identifier in ids]
        selected,summary,digest,packages=cascade_deletion.plan(r,MODELS[kind],rows)
        descriptions={x['id']:x['label']+' · '+x['details'] for x in listing(r,kind,pid)['rows']}
        token=jwt.encode({'aud':'andalus-record-deletion','exp':datetime.now(timezone.utc)+timedelta(minutes=5),
                         'actor':r.context.user_id,'year':r.year,'kind':kind,'package':pid,'ids':ids,
                         'revision':data.revision,'cascade':True,'plan':digest},secret,algorithm='HS256')
        package_names={x.id:x.name_ar for x in r.all(m.Package)}
        return {'count':len(ids),'items':[{'id':x,'label':descriptions[x]} for x in ids],'blocked':[],
                'token':token,'curriculum_links':0,'summary':summary,'total_deleted':sum(x['count'] for x in summary),
                'packages':[package_names[x] for x in sorted(packages)],
                'action':'حذف المحدد والسجلات التابعة الموضحة أدناه من هذا العام، بعد نسخة احتياطية؛ تبقى سجلات التدقيق وملفات الاستيراد السابقة وحسابات الدخول العامة محفوظة'}
    ids=sorted(set(data.ids));items=[];blocked=[];links=0
    descriptions={row['id']:row['label']+' · '+row['details'] for row in listing(r,kind,pid)['rows']}
    for identifier in ids:
        row=scoped_row(r,kind,identifier,pid)
        reason=dependencies(r,kind,row,set(ids))
        label=descriptions[identifier]
        if kind=='teachers':
            member=r.get(m.Membership,row.membership_id)
            if member.role!='TEACHER':reason='هذه ليست عضوية معلم'
            label=AuthRepository(r.session).user(member.user_id).display_name
        if kind=='subjects':links+=len(r.all(m.StageSubject,m.StageSubject.subject_id==row.id))
        items.append({'id':identifier,'label':label})
        if reason:blocked.append({'id':identifier,'label':label,'reason':reason})
    token=None
    if not blocked:
        token=jwt.encode({'aud':'andalus-record-deletion','exp':datetime.now(timezone.utc)+timedelta(minutes=5),
                          'actor':r.context.user_id,'year':r.year,'kind':kind,'package':pid,'ids':ids,'revision':data.revision},secret,algorithm='HS256')
    return {'count':len(ids),'items':items,'blocked':blocked,'token':token,'curriculum_links':links,
            'action':'تعطيل عضوية المعلم في هذا العام فقط مع حفظ الأنصبة والتاريخ' if kind=='teachers' else 'حذف السجلات المحددة مع حفظ نسخها في سجل التدقيق'}


def delete_confirm(r,kind,pid,data,secret,settings=None):
    authorize(r,kind,pid,True)
    try:payload=jwt.decode(data.token,secret,algorithms=['HS256'],audience='andalus-record-deletion')
    except jwt.PyJWTError:raise HTTPException(409,'انتهت صلاحية معاينة الحذف أو تغيرت؛ أعد المعاينة') from None
    if (payload.get('actor'),payload.get('year'),payload.get('kind'),payload.get('package'))!=(r.context.user_id,r.year,kind,pid):
        raise HTTPException(403,'تأكيد الحذف لا يخص المستخدم أو العام أو النطاق الحالي')
    verify(r,payload['revision']);ids=payload['ids']
    rows=[scoped_row(r,kind,identifier,pid) for identifier in ids]
    if payload.get('cascade'):
        r.context.require('SYSTEM_ADMIN')
        selected,summary,digest,packages=cascade_deletion.plan(r,MODELS[kind],rows)
        if payload.get('plan')!=digest:raise HTTPException(409,'تغيرت السجلات التابعة؛ أعد معاينة الحذف')
        if settings is None:raise HTTPException(503,'إعداد النسخ الاحتياطي غير متاح')
        return cascade_deletion.apply(r,selected,packages,kind,ids,settings)
    for row in rows:
        if dependencies(r,kind,row,set(ids)):raise HTTPException(409,'تغيرت علاقات السجلات؛ أعد معاينة الحذف')
    for row in sorted(rows,key=lambda row:getattr(row,'round',0),reverse=True):
        if kind=='teachers':
            member=r.get(m.Membership,row.membership_id)
            if member.role!='TEACHER':raise HTTPException(409,'عضوية غير صالحة للحذف')
            before=snapshot(member);member.is_active=False
            r.audit('DISABLE_YEAR_TEACHER','year_memberships',member.id,before,snapshot(member))
        else:
            if kind=='subjects':
                for cur in r.all(m.StageSubject,m.StageSubject.subject_id==row.id):
                    r.audit('DELETE_RECORD',cur.__tablename__,cur.id,snapshot(cur),None);r.remove(cur)
            r.audit('DELETE_RECORD',row.__tablename__,row.id,snapshot(row),None)
            r.remove(row)
    if pid:r.bump(pid)
    if kind=='subjects':r.one(m.YearSettings).revision+=1
    r.session.flush();Analytics(r).refresh_declines()
    r.audit('BULK_RECORD_ACTION',kind,None,after={'ids':ids,'count':len(ids),'package_id':pid})
    return {'affected':len(ids)}
