"""Administrator-only current-year selection and verified annual data removal."""
from datetime import datetime, timezone, timedelta
from hashlib import sha256
from pathlib import Path
from uuid import uuid4
import json
import sqlite3
import jwt
from fastapi import HTTPException
from pydantic import BaseModel, Field
from . import models as m
from .services import snapshot
from .schemas import YearInput

ORDER = [m.EventReceipt,m.Event,m.Score,m.Assignment,m.Enrollment,m.SubjectMaximum,
         m.ImportErrorRow,m.ReportRun,m.ExcelUpload,m.ImportBatch,m.ImportScope,m.Teacher,
         m.Membership,m.StageSubject,m.Section,m.Student,m.Subject,m.Stage,
         m.PerformanceLevel,m.YearSettings,m.Package]
LABELS = ['قراءات الإشعارات','الإشعارات','الدرجات','أنصبة المعلمين','انتماءات الطلاب','الدرجات النهائية',
          'أخطاء الاستيراد','التقارير المحفوظة','ملفات Excel','إصدارات الاستيراد','نطاقات الاستيراد',
          'ملفات المعلمين','عضويات الحسابات','روابط المواد بالصفوف','الشعب','الطلاب','المواد','الصفوف',
          'مستويات الأداء','إعدادات العام','الباقات']

class Confirmation(BaseModel):
    token: str = Field(max_length=4096)
    code: str = Field(max_length=20)
    acknowledge: bool

class EditInput(YearInput):
    revision: str = Field(min_length=64, max_length=64)


def year_revision(year):
    return sha256(json.dumps(snapshot(year),sort_keys=True).encode()).hexdigest()


def edit(r,data):
    r.context.require("SYSTEM_ADMIN")
    year=r.year_record()
    if data.revision!=year_revision(year):
        raise HTTPException(409,'تغيرت بيانات العام؛ أغلق نافذة التعديل وحدّث الصفحة ثم أعد المحاولة')
    before=snapshot(year)
    r.update_year_details(data.code,data.starts_on,data.ends_on)
    r.audit('EDIT_YEAR','academic_years',year.id,before,snapshot(year))
    return {'ok':True}


def listing(r):
    state=r.system_state()
    return [{'id':y.id,'code':y.code,'starts_on':y.starts_on,'ends_on':y.ends_on,
             'is_current':state.current_year_id==y.id,'can_manage':role=='SYSTEM_ADMIN','revision':year_revision(y)}
            for y,role in r.available_years()]

def set_current(r):
    state=r.system_state(lock=True)
    year=r.year_record()
    previous=state.current_year_id
    state.current_year_id=year.id
    r.audit('SET_CURRENT_YEAR','academic_years',year.id,{'current_year_id':previous},{'current_year_id':year.id,'code':year.code})
    return {'ok':True}

def deletable(r):
    state=r.system_state(lock=True)
    year=r.year_record()
    if not state.current_year_id or state.current_year_id==year.id:
        raise HTTPException(409,'لا يمكن حذف العام الحالي؛ عيّن عاماً آخر كعام حالي أولاً')
    return year,state

def inventory(r,state):
    digest=sha256(json.dumps([snapshot(r.year_record()),state.current_year_id],sort_keys=True).encode())
    counts=[]
    for model,label in zip(ORDER,LABELS):
        rows=sorted(r.all(model),key=lambda x:x.id)
        counts.append({'label':label,'count':len(rows)})
        for row in rows:
            digest.update(json.dumps(snapshot(row),sort_keys=True,ensure_ascii=False).encode())
    return counts,digest.hexdigest()

def preview(r,secret):
    year,state=deletable(r)
    counts,revision=inventory(r,state)
    token=jwt.encode({'aud':'andalus-year-deletion','exp':datetime.now(timezone.utc)+timedelta(minutes=5),
                      'actor':r.context.user_id,'year':year.id,'revision':revision},secret,algorithm='HS256')
    return {'id':year.id,'code':year.code,'counts':counts,'token':token}

def backup(r,directory):
    engine=r.session.get_bind()
    if engine.dialect.name!='sqlite' or not engine.url.database or engine.url.database==':memory:':
        raise HTTPException(409,'يلزم إعداد نسخ احتياطي موثوق لهذه القاعدة قبل حذف الأعوام')
    try:
        folder=Path(directory);folder.mkdir(parents=True,exist_ok=True)
        dest=folder/('before-year-delete-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+str(uuid4())+'.db')
        # Separate read-only connection sees committed data without contending for the writer lock.
        with sqlite3.connect(Path(engine.url.database).resolve().as_uri()+'?mode=ro',uri=True) as source:
            with sqlite3.connect(dest) as target:
                source.backup(target)
                if target.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or target.execute('PRAGMA foreign_key_check').fetchall():
                    raise ValueError('Backup integrity failed')
        return {'file':dest.name,'sha256':sha256(dest.read_bytes()).hexdigest()}
    except (OSError,sqlite3.Error,ValueError):
        raise HTTPException(503,'تعذر إنشاء نسخة احتياطية سليمة؛ لم يُحذف العام') from None

def confirm(r,data,settings):
    year,state=deletable(r)
    try: payload=jwt.decode(data.token,settings.jwt_secret,algorithms=['HS256'],audience='andalus-year-deletion')
    except jwt.PyJWTError: raise HTTPException(409,'انتهت المعاينة أو تغيرت؛ أعد معاينة الحذف') from None
    if (payload.get('actor'),payload.get('year'))!=(r.context.user_id,r.year):
        raise HTTPException(403,'المعاينة لا تخص هذا العام أو المستخدم')
    if not data.acknowledge or data.code!=year.code:
        raise HTTPException(422,'اكتب اسم العام مطابقاً وأكد مراجعة البيانات')
    counts,revision=inventory(r,state)
    if payload.get('revision')!=revision: raise HTTPException(409,'تغيرت البيانات منذ المعاينة؛ أعد المعاينة')
    copy=backup(r,settings.backup_directory)
    r.audit('DELETE_YEAR','academic_years',year.id,after={'code':year.code,'counts':counts,'backup':copy})
    r.purge_year_data(ORDER)
    return {'ok':True,'backup':copy['file']}
