from collections import defaultdict
from fractions import Fraction

from fastapi import HTTPException

from . import domain as d, models as m
from .db import utcnow


class Analytics:
    def __init__(self, repository):
        self.repo = repository

    def marks(self, package_id, *, section_id=None, stage_id=None, stage_subject_id=None):
        """Authorization narrows subjects AND enrollments before score queries/aggregation."""
        r = self.repo
        package = r.get(m.Package, package_id)
        pairs = r.permitted_pairs(package_id)
        maxima = r.all(m.SubjectMaximum, m.SubjectMaximum.package_id == package_id,
                       *([m.SubjectMaximum.stage_id == stage_id] if stage_id else []),
                       *([m.SubjectMaximum.stage_subject_id == stage_subject_id] if stage_subject_id else []))
        if pairs is not None:
            maxima = [mx for mx in maxima if any(ss == mx.stage_subject_id and (not section_id or sec == section_id) for sec, ss in pairs)]
        allowed_stage_ids = {mx.stage_id for mx in maxima}
        enrollment_conditions = [m.Enrollment.package_id == package_id, m.Enrollment.stage_id.in_(allowed_stage_ids)]
        if section_id:
            enrollment_conditions.append(m.Enrollment.section_id == section_id)
        if stage_id:
            enrollment_conditions.append(m.Enrollment.stage_id == stage_id)
        if pairs is not None:
            enrollment_conditions.append(m.Enrollment.section_id.in_({sec for sec, _ in pairs}))
        enrollments = r.all(m.Enrollment, *enrollment_conditions)
        scores = r.all(m.Score, m.Score.package_id == package_id,
                       m.Score.enrollment_id.in_([e.id for e in enrollments]),
                       m.Score.subject_maximum_id.in_([mx.id for mx in maxima]))
        index = {(s.enrollment_id, s.subject_maximum_id, s.round): d.Mark(s.score_status, s.score) for s in scores}
        subjects = {s.id: s for s in r.all(m.Subject)}
        curricula = {s.id: s for s in r.all(m.StageSubject)}
        result = {}
        for enrollment in enrollments:
            marks = []
            for mx in maxima:
                if mx.stage_id != enrollment.stage_id or (pairs is not None and (enrollment.section_id, mx.stage_subject_id) not in pairs):
                    continue
                subject = subjects[curricula[mx.stage_subject_id].subject_id]
                marks.append(d.effective(subject.id, mx.max_score,
                    index.get((enrollment.id, mx.id, 1), d.Mark()), index.get((enrollment.id, mx.id, 2)),
                    second_round_enabled=package.has_second_round, core=subject.is_core, excluded=subject.is_excluded))
            result[enrollment.id] = (enrollment, marks)
        return result

    def student_report(self, package_id, section_id=None, stage_id=None):
        self.repo.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        if section_id:
            section = self.repo.get(m.Section, section_id)
            if stage_id and stage_id != section.stage_id:
                raise HTTPException(422, "الشعبة لا تتبع المرحلة")
            stage_id = section.stage_id
        if stage_id:
            self.repo.get(m.Stage, stage_id)
        # Load entire stage to preserve stage ranking even when filtering a section.
        rows = self.marks(package_id, stage_id=stage_id)
        # Include enrollments even before maxima exist: no denominator => unranked.
        for enrollment in self.repo.all(m.Enrollment, m.Enrollment.package_id == package_id,
                                       *([m.Enrollment.stage_id == stage_id] if stage_id else [])):
            rows.setdefault(enrollment.id, (enrollment, []))
        levels = [(l.minimum_percent, l.label) for l in self.repo.all(m.PerformanceLevel)]
        results = {eid: d.student_result(marks, levels) for eid, (_, marks) in rows.items()}
        stage_groups, section_groups = defaultdict(dict), defaultdict(dict)
        for eid, (enrollment, _) in rows.items():
            stage_groups[enrollment.stage_id][eid] = results[eid]
            section_groups[enrollment.section_id][eid] = results[eid]
        stage_ranks = {k: rank for group in stage_groups.values() for k, rank in d.ranks(group).items()}
        section_ranks = {k: rank for group in section_groups.values() for k, rank in d.ranks(group).items()}
        students = {s.id: s for s in self.repo.all(m.Student, m.Student.id.in_([e.student_id for e, _ in rows.values()]))}
        output = []
        for eid, (e, marks) in rows.items():
            if section_id and e.section_id != section_id:
                continue
            student = students[e.student_id]
            output.append({"student_id": student.id, "personal_number": student.personal_number,
                           "name": student.full_name, "enrollment_id": eid, "stage_id": e.stage_id, "section_id": e.section_id,
                           **results[eid].output(), "stage_rank": stage_ranks[eid], "section_rank": section_ranks[eid],
                           "rank_label": "بلا ترتيب" if stage_ranks[eid] is None else str(stage_ranks[eid]),
                           "subjects": [mark.output() for mark in marks]})
        return sorted(output, key=lambda row: (row["stage_id"], row["stage_rank"] or 10**9, row["personal_number"]))

    def subject_report(self, package_id, section_id, stage_subject_id):
        r = self.repo
        section = r.get(m.Section, section_id)
        curriculum = r.get(m.StageSubject, stage_subject_id)
        if curriculum.stage_id != section.stage_id:
            raise HTTPException(422, "المادة لا تتبع مرحلة الشعبة")
        r.authorize_subject(package_id, section_id, stage_subject_id)
        rows = self.marks(package_id, section_id=section_id, stage_subject_id=stage_subject_id)
        marks = [mark for _, items in rows.values() for mark in items]
        stats = d.subject_result(marks)
        students = {s.id: s for s in r.all(m.Student, m.Student.id.in_([e.student_id for e, _ in rows.values()]))}
        return {"subject_id": curriculum.subject_id, "section_id": section_id, **stats.output(),
                "students": [{"student_id": e.student_id, "name": students[e.student_id].full_name,
                              "mark": items[0].output()} for e, items in rows.values() if items]}

    def achievements(self, package_id, section_id, core_only=False):
        rows = self.marks(package_id, section_id=section_id)
        grouped = defaultdict(list)
        for _, marks in rows.values():
            for mark in marks:
                if not mark.excluded and (not core_only or mark.core):
                    grouped[mark.subject_id].append(mark)
        return {subject: d.subject_result(marks) for subject, marks in grouped.items()}

    def comparison(self, first_id, second_id, section_id, core_only=False):
        r = self.repo
        first, second = r.get(m.Package, first_id), r.get(m.Package, second_id)
        if first.sequence_no >= second.sequence_no:
            raise HTTPException(422, "اختر باقتين بترتيب زمني تصاعدي")
        section = r.get(m.Section, section_id)
        a, b = self.achievements(first.id, section.id, core_only), self.achievements(second.id, section.id, core_only)
        if r.context.role == "TEACHER":
            # Never disclose a material assigned in only one of the selected packages.
            allowed_a = r.permitted_pairs(first.id)
            allowed_b = r.permitted_pairs(second.id)
            ids = {ss for sec, ss in allowed_a & allowed_b if sec == section.id}
            subjects = {s.subject_id for s in r.all(m.StageSubject, m.StageSubject.id.in_(ids))}
            a, b = {k: v for k, v in a.items() if k in subjects}, {k: v for k, v in b.items() if k in subjects}
            if not subjects:
                raise HTTPException(403, "لا يوجد إسناد مشترك في الباقتين")
        settings = r.one(m.YearSettings)
        overall = d.compare({k: v.achievement for k, v in a.items()}, {k: v.achievement for k, v in b.items()}, settings.decline_threshold_pp)
        subjects = []
        for subject_id in sorted(a.keys() | b.keys()):
            av, bv = a.get(subject_id), b.get(subject_id)
            compared = d.compare({subject_id: av.achievement if av else None}, {subject_id: bv.achievement if bv else None}, settings.decline_threshold_pp)
            subjects.append({"subject_id": subject_id, **compared, "first_coverage": av.output() if av else None, "second_coverage": bv.output() if bv else None})
        return {"first_package_id": first.id, "second_package_id": second.id, "section_id": section.id,
                "core_only": core_only, "consecutive": second.sequence_no == first.sequence_no + 1,
                "cohort_policy": "all_students_in_each_package", "overall": overall, "subjects": subjects}

    def teacher_report(self, package_id, teacher_id):
        r = self.repo
        teacher = r.get(m.Teacher, teacher_id)
        if r.context.role == "TEACHER" and teacher.id != r.teacher().id:
            raise HTTPException(403, "لا يمكنك عرض تحصيل معلم آخر")
        grouped = defaultdict(list)
        for assignment in r.all(m.Assignment, m.Assignment.package_id == package_id, m.Assignment.teacher_id == teacher.id):
            curriculum = r.get(m.StageSubject, assignment.stage_subject_id)
            stats = self.achievements(package_id, assignment.section_id).get(curriculum.subject_id)
            grouped[curriculum.subject_id].append((assignment.section_id, stats.achievement if stats else None))
        return [{"subject_id": subject, "achievement": d.display(d.average(value for _, value in entries)),
                 "included_sections": sum(value is not None for _, value in entries), "total_sections": len(entries),
                 "sections": [{"section_id": section, "achievement": d.display(value)} for section, value in entries]} for subject, entries in grouped.items()]

    def progress(self, first_id, second_id):
        r = self.repo
        r.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        if r.get(m.Package, first_id).sequence_no >= r.get(m.Package, second_id).sequence_no:
            raise HTTPException(422, "ترتيب الباقتين غير صحيح")
        first = {e.student_id: (e, marks) for e, marks in self.marks(first_id).values()}
        second = {e.student_id: (e, marks) for e, marks in self.marks(second_id).values()}
        output = []
        for student_id in sorted(first.keys() | second.keys()):
            a, b = first.get(student_id), second.get(student_id)
            ar = d.student_result(a[1]) if a else None
            br = d.student_result(b[1]) if b else None
            delta = br.percentage - ar.percentage if ar and br and ar.percentage is not None and br.percentage is not None else None
            ap = {x.subject_id: Fraction(x.mark.score) / Fraction(x.maximum) * 100 for x in a[1] if x.subject_included} if a else {}
            bp = {x.subject_id: Fraction(x.mark.score) / Fraction(x.maximum) * 100 for x in b[1] if x.subject_included} if b else {}
            output.append({"student_id": student_id, "first_percentage": d.display(ar.percentage) if ar else None,
                           "second_percentage": d.display(br.percentage) if br else None, "delta_pp": d.display(delta),
                           "direction": "متقدم" if delta is not None and delta > 0 else "متراجع" if delta is not None and delta < 0 else "ثابت" if delta == 0 else "غير قابل للمقارنة",
                           "stage_changed": bool(a and b and a[0].stage_id != b[0].stage_id),
                           "section_changed": bool(a and b and a[0].section_id != b[0].section_id),
                           "subjects_changed": bool(a and b and {x.subject_id for x in a[1] if x.student_included} != {x.subject_id for x in b[1] if x.student_included}),
                           "common_present_subjects": [{"subject_id": k, "delta_pp": d.display(bp[k] - ap[k])} for k in sorted(ap.keys() & bp.keys())]})
        return output

    def refresh_declines(self):
        """Persist current alerts atomically; old alerts become resolved, not deleted."""
        r = self.repo
        r.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        packages = sorted(r.all(m.Package), key=lambda p: p.sequence_no)
        active_keys = set()
        for first, second in zip(packages, packages[1:]):
            for section in r.all(m.Section):
                report = self.comparison(first.id, second.id, section.id)
                rows = [(None, report["overall"])] + [(row["subject_id"], row) for row in report["subjects"]]
                for subject_id, stats in rows:
                    if not stats["is_decline"]:
                        continue
                    key = f"decline:{first.id}:{second.id}:{section.id}:{subject_id or 'overall'}"
                    active_keys.add(key)
                    event = r.one(m.Event, m.Event.deduplication_key == key)
                    payload = {"first_package_id": first.id, "second_package_id": second.id, "delta_pp": stats["delta_pp"],
                               "first_revision": first.data_revision, "second_revision": second.data_revision}
                    if event:
                        event.payload, event.resolved_at = payload, None
                    else:
                        r.add(m.Event, event_type="GROUP_DECLINE", package_id=second.id, stage_id=section.stage_id,
                              section_id=section.id, subject_id=subject_id, payload=payload, deduplication_key=key)
        for event in r.all(m.Event, m.Event.event_type == "GROUP_DECLINE", m.Event.resolved_at.is_(None)):
            if event.deduplication_key not in active_keys:
                event.resolved_at = utcnow()
