from functools import lru_cache

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ANDALUS_", env_file=".env", env_file_encoding="utf-8-sig", extra="ignore")
    database_url: str = "sqlite:///./storage/andalus.db"
    jwt_secret: str = Field(min_length=32)
    jwt_issuer: str = "andalus-results"
    jwt_audience: str = "andalus-api"
    access_minutes: int = Field(default=15, ge=1, le=60)
    refresh_days: int = Field(default=7, ge=1, le=30)
    allowed_origins: list[str] = []
    backup_directory: str = "./storage/backups"
    backup_interval_hours: int = Field(default=24, ge=1)
    setup_token: str | None = Field(default=None, min_length=32)

    @field_validator("jwt_secret")
    @classmethod
    def reject_placeholder(cls, value: str) -> str:
        if value.startswith("REPLACE_"):
            raise ValueError("Set a randomly generated JWT secret")
        return value


@lru_cache
def get_settings() -> Settings:
    return Settings()
