"""Andalus results backend."""
