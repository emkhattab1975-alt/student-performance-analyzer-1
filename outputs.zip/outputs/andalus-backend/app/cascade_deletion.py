"""Explicit, administrator-reviewed dependency deletion within one academic year."""
from hashlib import sha256
import json
from fastapi import HTTPException
from . import models as m
from .services import snapshot
from .analytics import Analytics
from .year_management import backup

ORDER=[m.EventReceipt,m.Event,m.Score,m.Assignment,m.Enrollment,m.SubjectMaximum,m.Teacher,m.Membership,m.StageSubject,m.Section,m.Student,m.Subject]
LABELS=['قراءات الإشعارات','الإشعارات المرتبطة','الدرجات','أنصبة المعلمين','تشعيب الطلاب','الدرجات النهائية','ملفات المعلمين','عضويات المعلمين في العام','روابط المواد بالصفوف','الشعب','الطلاب','المواد']

def plan(r,model,rows):
    r.context.require('SYSTEM_ADMIN')
    selected={cls:{row.id:row for row in rows} if cls is model else {} for cls in ORDER}
    catalog={cls:r.all(cls) for cls in ORDER}
    def include(cls,predicate):
        for row in catalog[cls]:
            if predicate(row):selected[cls][row.id]=row
    include(m.StageSubject,lambda x:x.subject_id in selected[m.Subject])
    include(m.SubjectMaximum,lambda x:x.stage_subject_id in selected[m.StageSubject])
    include(m.Enrollment,lambda x:x.section_id in selected[m.Section] or x.student_id in selected[m.Student])
    include(m.Assignment,lambda x:x.section_id in selected[m.Section] or x.stage_subject_id in selected[m.StageSubject] or x.teacher_id in selected[m.Teacher])
    include(m.Score,lambda x:x.enrollment_id in selected[m.Enrollment] or x.subject_maximum_id in selected[m.SubjectMaximum])
    firsts={(x.enrollment_id,x.subject_maximum_id) for x in selected[m.Score].values() if x.round==1}
    include(m.Score,lambda x:x.round==2 and (x.enrollment_id,x.subject_maximum_id) in firsts)
    member_ids={x.membership_id for x in selected[m.Teacher].values()}
    include(m.Membership,lambda x:x.id in member_ids)
    if any(x.role!='TEACHER' for x in selected[m.Membership].values()):
        raise HTTPException(409,'يمكن حذف عضويات المعلمين فقط من هذه القائمة')
    include(m.Event,lambda x:x.section_id in selected[m.Section] or x.subject_id in selected[m.Subject])
    include(m.EventReceipt,lambda x:x.event_id in selected[m.Event] or x.membership_id in selected[m.Membership])
    packages={x.package_id for values in selected.values() for x in values.values() if getattr(x,'package_id',None)}
    for pid in packages:r.writable(pid)
    items=[{'label':label,'count':len(selected[cls])} for cls,label in zip(ORDER,LABELS) if selected[cls]]
    serialized={cls.__tablename__:[snapshot(x) for x in sorted(selected[cls].values(),key=lambda x:x.id)] for cls in ORDER}
    digest=sha256(json.dumps(serialized,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return selected,items,digest,packages

def apply(r,selected,packages,kind,ids,settings):
    r.context.require('SYSTEM_ADMIN')
    saved=backup(r,settings.backup_directory)
    count=0
    for cls in ORDER:
        for row in sorted(selected[cls].values(),key=lambda x:(-getattr(x,'round',0),x.id)):
            r.audit('DELETE_RECORD',row.__tablename__,row.id,snapshot(row),None)
            r.remove(row);count+=1
    for pid in packages:r.bump(pid)
    if selected[m.Subject]:r.one(m.YearSettings).revision+=1
    Analytics(r).refresh_declines()
    r.audit('BULK_RECORD_ACTION',kind,None,after={'ids':ids,'count':len(ids),'total_deleted':count,'backup':saved})
    return {'affected':len(ids),'total_deleted':count,'backup':saved['file']}
