"""All persisted reads/writes live here. Academic repositories require an explicit year."""
from dataclasses import dataclass
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from . import models as m
from .db import utcnow


@dataclass(frozen=True)
class YearContext:
    academic_year_id: str
    user_id: str
    membership_id: str
    role: str

    def require(self, *roles):
        if self.role not in roles:
            raise HTTPException(403, "لا تملك صلاحية هذه العملية")


class AuthRepository:
    """Explicit global identity operations; never returns school results."""
    def __init__(self, session: Session):
        self.session = session

    def user(self, user_id):
        return self.session.get(m.User, user_id)

    def by_username(self, username):
        return self.session.scalar(select(m.User).where(m.User.username == username))

    def membership(self, year_id, user_id):
        return self.session.scalar(select(m.Membership).where(m.Membership.academic_year_id == year_id, m.Membership.user_id == user_id, m.Membership.is_active.is_(True)).join(m.AcademicYear, m.AcademicYear.id == m.Membership.academic_year_id).where(m.AcademicYear.deleted_at.is_(None)))

    def memberships(self, user_id):
        return list(self.session.scalars(select(m.Membership).join(m.AcademicYear, m.AcademicYear.id == m.Membership.academic_year_id).where(m.Membership.user_id == user_id, m.Membership.is_active.is_(True), m.AcademicYear.deleted_at.is_(None))))

    def import_teacher_identity(self,user_id):
        # Global identity metadata only; school results remain year-scoped.
        memberships=list(self.session.scalars(select(m.Membership).where(m.Membership.user_id==user_id)))
        profiles=list(self.session.execute(select(m.Teacher.employee_code,m.Teacher.membership_id).join(m.Membership,m.Membership.id==m.Teacher.membership_id).where(m.Membership.user_id==user_id)))
        return memberships,profiles

    def lock_year(self, year_id):
        self.session.execute(select(m.AcademicYear.id).where(m.AcademicYear.id == year_id).with_for_update())

    def any_user_exists(self):
        return self.session.scalar(select(m.User.id).limit(1)) is not None

    def year_info(self, year_id):
        year = self.session.get(m.AcademicYear, year_id)
        state = self.session.get(m.SystemState, 1)
        return {"code": year.code, "status": year.status, "is_current": bool(state and state.current_year_id == year.id)} if year else {}

    def would_remove_last_admin(self, user_id):
        for membership in self.memberships(user_id):
            if membership.role != "SYSTEM_ADMIN":
                continue
            remaining = self.session.scalar(select(m.Membership.id).join(m.User, m.User.id == m.Membership.user_id).where(
                m.Membership.academic_year_id == membership.academic_year_id, m.Membership.role == "SYSTEM_ADMIN",
                m.Membership.is_active.is_(True), m.User.is_active.is_(True), m.User.id != user_id).limit(1))
            if not remaining:
                return True
        return False

    def refresh(self, token_hash):
        return self.session.scalar(select(m.RefreshSession).where(m.RefreshSession.token_hash == token_hash))

    def consume_refresh(self, row):
        return self.session.execute(update(m.RefreshSession).where(m.RefreshSession.id == row.id, m.RefreshSession.revoked_at.is_(None)).values(revoked_at=utcnow())).rowcount == 1

    def revoke_family(self, family_id):
        self.session.execute(update(m.RefreshSession).where(m.RefreshSession.family_id == family_id).values(revoked_at=utcnow()))

    def revoke_user(self, user_id):
        self.session.execute(update(m.RefreshSession).where(m.RefreshSession.user_id == user_id).values(revoked_at=utcnow()))

    def add(self, obj):
        self.session.add(obj)
        self.session.flush()
        return obj


class YearRepository:
    def __init__(self, session: Session, context: YearContext):
        if not context.academic_year_id:
            raise ValueError("An explicit academic year is mandatory")
        self.session = session
        self.context = context
        self.year = context.academic_year_id

    def query(self, model, *conditions):
        if not issubclass(model, m.Annual):
            raise TypeError("Only year-scoped models are accepted")
        return select(model).where(model.academic_year_id == self.year, *conditions)

    def all(self, model, *conditions):
        return list(self.session.scalars(self.query(model, *conditions)))

    def one(self, model, *conditions):
        return self.session.scalar(self.query(model, *conditions))

    def get(self, model, identifier):
        row = self.one(model, model.id == identifier)
        if row is None:
            raise HTTPException(404, "السجل غير موجود في العام المحدد")
        return row

    def add(self, model, **values):
        if "academic_year_id" in values:
            raise ValueError("Year comes from the repository context only")
        row = model(academic_year_id=self.year, **values)
        self.session.add(row)
        self.session.flush()
        return row

    def year_record(self):
        row = self.session.scalar(select(m.AcademicYear).where(m.AcademicYear.id == self.year))
        if row is None or row.deleted_at is not None:
            raise HTTPException(404, "العام غير موجود")
        return row

    def writable(self, package_id=None):
        self.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        if self.year_record().status != "OPEN":
            raise HTTPException(409, "العام مغلق")
        if package_id:
            package = self.get(m.Package, package_id)
            if package.status == "LOCKED":
                raise HTTPException(409, "الباقة مقفلة")
            return package

    def teacher(self):
        row = self.one(m.Teacher, m.Teacher.membership_id == self.context.membership_id)
        if not row:
            raise HTTPException(403, "لا يوجد ملف معلم مرتبط بالحساب")
        return row

    def permitted_pairs(self, package_id):
        if self.context.role != "TEACHER":
            return None
        teacher = self.teacher()
        return {(a.section_id, a.stage_subject_id) for a in self.all(m.Assignment, m.Assignment.package_id == package_id, m.Assignment.teacher_id == teacher.id)}

    def authorize_subject(self, package_id, section_id, stage_subject_id):
        permitted = self.permitted_pairs(package_id)
        if permitted is not None and (section_id, stage_subject_id) not in permitted:
            raise HTTPException(403, "المادة والشعبة غير مسندتين إليك في هذه الباقة")

    def bump(self, package_id):
        # SQL increment prevents lost updates. Runs in the same transaction as data writes.
        self.session.execute(update(m.Package).where(m.Package.academic_year_id == self.year, m.Package.id == package_id).values(data_revision=m.Package.data_revision + 1))

    def audit(self, action, entity, identifier, before=None, after=None):
        return self.add(m.AuditLog, actor_user_id=self.context.user_id, action=action, entity_type=entity,
                        entity_id=identifier, before_json=before, after_json=after, request_id=str(uuid4()))

    def recent_audit(self):
        return list(self.session.scalars(self.query(m.AuditLog).order_by(m.AuditLog.created_at.desc()).limit(200)))

    def replace_levels(self, levels):
        self.session.execute(delete(m.PerformanceLevel).where(m.PerformanceLevel.academic_year_id == self.year))
        for i, level in enumerate(levels):
            self.add(m.PerformanceLevel, **level.model_dump(), display_order=i)

    def users(self):
        self.context.require("SYSTEM_ADMIN")
        rows = self.session.execute(select(m.User, m.Membership).join(m.Membership, m.Membership.user_id == m.User.id).where(m.Membership.academic_year_id == self.year)).all()
        return [{"id": user.id, "username": user.username, "display_name": user.display_name,
                 "is_active": user.is_active, "role": member.role, "membership_id": member.id,
                 "membership_active": member.is_active} for user, member in rows]

    def recent_excel_uploads(self):
        self.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        statement = select(m.ExcelUpload.id, m.ExcelUpload.kind, m.ExcelUpload.filename,
                           m.ExcelUpload.status, m.ExcelUpload.created_at,
                           m.ExcelUpload.preview['row_count'].as_integer().label('row_count')).where(
                               m.ExcelUpload.academic_year_id == self.year,
                               m.ExcelUpload.uploaded_by == self.context.user_id).order_by(
                                   m.ExcelUpload.created_at.desc()).limit(30)
        return [dict(row) for row in self.session.execute(statement).mappings()]

    def remove(self, row):
        if not isinstance(row, m.Annual) or row.academic_year_id != self.year:
            raise ValueError('Deletion requires the current year context')
        self.session.delete(row)
        self.session.flush()


    def system_state(self, lock=False):
        self.context.require("SYSTEM_ADMIN")
        statement = select(m.SystemState).where(m.SystemState.id == 1)
        if lock: statement = statement.with_for_update()
        return self.session.scalar(statement)

    def available_years(self):
        self.context.require("SYSTEM_ADMIN")
        return list(self.session.execute(select(m.AcademicYear, m.Membership.role).join(m.Membership, m.Membership.academic_year_id == m.AcademicYear.id).where(m.Membership.user_id == self.context.user_id, m.Membership.is_active.is_(True), m.AcademicYear.deleted_at.is_(None)).order_by(m.AcademicYear.starts_on.desc())))

    def initialize_current_year(self):
        if self.session.get(m.SystemState, 1) is None:
            self.session.add(m.SystemState(id=1, current_year_id=self.year))
        else:
            self.session.execute(update(m.SystemState).where(m.SystemState.id == 1, m.SystemState.current_year_id.is_(None)).values(current_year_id=self.year))
        self.session.flush()

    def purge_year_data(self, ordered_models):
        self.context.require("SYSTEM_ADMIN")
        self.session.execute(update(m.ImportScope).where(m.ImportScope.academic_year_id == self.year).values(active_batch_id=None))
        for model in ordered_models:
            if not issubclass(model, m.Annual) or model is m.AuditLog:
                raise ValueError('Only annual operational data can be purged')
            self.session.execute(delete(model).where(model.academic_year_id == self.year))
        year = self.year_record()
        year.deleted_at = utcnow()
        self.session.flush()

    def update_year_details(self,code,starts_on,ends_on):
        self.context.require("SYSTEM_ADMIN")
        year=self.year_record()
        duplicate=self.session.scalar(select(m.AcademicYear.id).where(m.AcademicYear.code==code,m.AcademicYear.id!=self.year))
        if duplicate:
            raise HTTPException(409,"اسم العام مستخدم مسبقاً؛ اختر اسماً آخر")
        year.code,year.starts_on,year.ends_on=code,starts_on,ends_on
        self.session.flush()
