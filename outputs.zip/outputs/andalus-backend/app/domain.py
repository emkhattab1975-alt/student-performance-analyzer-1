"""Pure calculations. Fractions keep ranking and thresholds exact; rounding is display-only."""
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction
from typing import Iterable

STATUSES = {"PRESENT", "ABSENT", "CHEATING", "EXCUSED"}
LABELS = {"ABSENT": "غائب", "CHEATING": "غش", "EXCUSED": "معذور", None: "غير مسجلة"}
DEFAULT_LEVELS = [(Decimal("90"), "ممتاز"), (Decimal("80"), "جيد جداً"), (Decimal("70"), "جيد"), (Decimal("60"), "متوسط"), (Decimal("50"), "ضعيف"), (Decimal("0"), "راسب")]
FOOTNOTE = "تتضمن النتيجة مواد غياب/غش احتُسبت بصفر"
PRINT_LEGEND = "غائب/غش: صفر في نتيجة الطالب فقط؛ معذور وغير مسجلة: مستثناة؛ * تتضمن النتيجة مواد غياب/غش احتُسبت بصفر."


def display(value: Fraction | Decimal | None) -> str | None:
    if value is None:
        return None
    number = Decimal(value.numerator) / Decimal(value.denominator) if isinstance(value, Fraction) else value
    return str(number.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def average(values: Iterable[Fraction | None]) -> Fraction | None:
    valid = [v for v in values if v is not None]
    return sum(valid, Fraction()) / len(valid) if valid else None


@dataclass(frozen=True)
class Mark:
    status: str | None = None
    score: Decimal | None = None

    def __post_init__(self):
        if self.status is not None and self.status not in STATUSES:
            raise ValueError("حالة درجة غير معروفة")
        if self.status == "PRESENT":
            if self.score is None or not self.score.is_finite() or self.score < 0:
                raise ValueError("الحاضر يحتاج درجة رقمية غير سالبة")
        elif self.score is not None:
            raise ValueError("الحالة غير الحاضرة لا تقبل درجة رقمية")


@dataclass(frozen=True)
class EffectiveMark:
    subject_id: str
    maximum: Decimal
    mark: Mark
    original_status: str | None
    round_used: int
    core: bool
    excluded: bool
    second_status: str | None = None

    @property
    def student_included(self):
        return not self.excluded and self.mark.status in {"PRESENT", "ABSENT", "CHEATING"}

    @property
    def subject_included(self):
        return not self.excluded and self.mark.status == "PRESENT"

    def output(self):
        return {
            "subject_id": self.subject_id, "maximum": display(self.maximum),
            "score": display(self.mark.score), "status": self.mark.status,
            "display": display(self.mark.score) if self.mark.status == "PRESENT" else LABELS[self.mark.status],
            "original_status": self.original_status, "round_used": self.round_used,
            "second_round_status": self.second_status, "is_core": self.core, "is_excluded": self.excluded,
            "student_included": self.student_included, "subject_included": self.subject_included,
            "tone": "muted-red" if self.mark.status in {"ABSENT", "CHEATING"} else "gray" if self.mark.status == "EXCUSED" else "default",
        }


def effective(subject_id: str, maximum: Decimal, first: Mark, second: Mark | None = None,
              *, second_round_enabled: bool = False, core: bool = True, excluded: bool = False) -> EffectiveMark:
    if not maximum.is_finite() or maximum <= 0:
        raise ValueError("النهاية يجب أن تكون موجبة")
    for mark in (first, second):
        if mark and mark.score is not None and mark.score > maximum:
            raise ValueError("الدرجة تتجاوز النهاية")
    if second is not None and (not second_round_enabled or first.status != "EXCUSED"):
        raise ValueError("الدور الثاني للمعذور في المادة نفسها فقط")
    replacement = second is not None and second.status == "PRESENT"
    return EffectiveMark(subject_id, maximum, second if replacement else first, first.status,
                         2 if replacement else 1, core, excluded, second.status if second else None)


@dataclass(frozen=True)
class StudentResult:
    total: Decimal
    denominator: Decimal
    percentage: Fraction | None
    level: str | None
    flags: tuple[str, ...]

    def output(self):
        return {"total": display(self.total), "denominator": display(self.denominator),
                "percentage": display(self.percentage), "level": self.level or "غير متاح",
                "has_zero_penalty": bool(self.flags), "flags": list(self.flags),
                "marker": "*" if self.flags else "", "footnote": FOOTNOTE if self.flags else None}


def student_result(marks: Iterable[EffectiveMark], levels=DEFAULT_LEVELS) -> StudentResult:
    included = [m for m in marks if m.student_included]
    total = sum((m.mark.score or Decimal(0) for m in included), Decimal(0))
    denominator = sum((m.maximum for m in included), Decimal(0))
    percentage = Fraction(total) / Fraction(denominator) * 100 if denominator else None
    level = next((label for lower, label in sorted(levels, reverse=True) if percentage is not None and percentage >= Fraction(lower)), None)
    flags = tuple(LABELS[s] for s in ("ABSENT", "CHEATING") if any(m.mark.status == s for m in included))
    return StudentResult(total, denominator, percentage, level, flags)


def ranks(results: dict[str, StudentResult]) -> dict[str, int | None]:
    ordered = sorted(((key, result.percentage) for key, result in results.items() if result.percentage is not None), key=lambda item: item[1], reverse=True)
    output = {key: None for key in results}
    prior, rank = None, None
    for position, (key, value) in enumerate(ordered, 1):
        if value != prior:
            rank = position
        output[key] = rank
        prior = value
    return output


@dataclass(frozen=True)
class SubjectResult:
    achievement: Fraction | None
    pass_rate: Fraction | None
    total: int
    included: int
    passed: int
    absent: int
    cheating: int
    excused: int
    blank: int
    excluded_subject: bool = False

    def output(self):
        excluded = self.absent + self.cheating + self.excused
        return {"achievement": display(self.achievement), "pass_rate": display(self.pass_rate),
                "total_students": self.total, "included_students": self.included, "passed": self.passed,
                "absent": self.absent, "cheating": self.cheating, "excused": self.excused,
                "blank": self.blank, "excluded_students": excluded, "excluded_subject": self.excluded_subject,
                "coverage_text": "مادة مستبعدة من الحسابات" if self.excluded_subject else f"الطلاب المحتسبون: {self.included} من أصل {self.total} (استُثني {excluded} غائب/غش/معذور، و{self.blank} مادة غير مسجلة)"}


def subject_result(marks: Iterable[EffectiveMark]) -> SubjectResult:
    rows = list(marks)
    if rows and len({(m.subject_id, m.maximum, m.excluded) for m in rows}) != 1:
        raise ValueError("إحصاء المادة يحتاج مادة واحدة ونهاية واحدة وسياسة واحدة")
    excluded_subject = bool(rows and rows[0].excluded)
    present = [m for m in rows if m.subject_included]
    achievement = average(Fraction(m.mark.score) / Fraction(m.maximum) * 100 for m in present)
    passed = sum(m.mark.score * 2 >= m.maximum for m in present)
    counts = {status: sum(m.mark.status == status for m in rows) for status in ("ABSENT", "CHEATING", "EXCUSED", None)}
    return SubjectResult(achievement, Fraction(passed * 100, len(present)) if present else None, len(rows), len(present), passed,
                         counts["ABSENT"], counts["CHEATING"], counts["EXCUSED"], counts[None], excluded_subject)


def compare(first: dict[str, Fraction | None], second: dict[str, Fraction | None], threshold: Decimal = Decimal("10")) -> dict:
    shared = sorted(k for k in first.keys() & second.keys() if first[k] is not None and second[k] is not None)
    a = average(first[k] for k in shared)
    b = average(second[k] for k in shared)
    delta = b - a if a is not None and b is not None else None
    return {"first": display(a), "second": display(b), "delta_pp": display(delta),
            "is_decline": delta is not None and delta <= -Fraction(threshold),
            "shared_subject_ids": shared, "shared_subject_count": len(shared),
            "omitted_subject_ids": sorted((first.keys() | second.keys()) - set(shared))}
