from datetime import date
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Identifier = Annotated[str, Field(min_length=1, max_length=36)]
Name = Annotated[str, Field(min_length=1, max_length=200)]
Amount = Annotated[Decimal, Field(ge=0, max_digits=10, decimal_places=2, allow_inf_nan=False)]
Role = Literal["SYSTEM_ADMIN", "PRINCIPAL", "TEACHER"]


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Login(Input):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)
    username: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=1, max_length=1024)


class Refresh(Input):
    refresh_token: str = Field(min_length=20, max_length=512)


class YearInput(Input):
    code: str = Field(min_length=1, max_length=20)
    starts_on: date
    ends_on: date

    @model_validator(mode="after")
    def dates(self):
        if self.ends_on <= self.starts_on:
            raise ValueError("نهاية العام يجب أن تلي بدايته")
        return self


class SetupInput(YearInput):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)
    username: str = Field(min_length=3, max_length=100, pattern=r"^[a-zA-Z0-9_.@-]+$")
    display_name: Name
    password: str = Field(min_length=12, max_length=256)


class StudentInput(Input):
    personal_number: str = Field(min_length=1, max_length=32)
    full_name: Name

    @field_validator("personal_number")
    @classmethod
    def normalize_number(cls, value):
        converted = value.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789"))
        if not converted.isascii() or not converted.isdigit():
            raise ValueError("الرقم الشخصي نص من أرقام فقط")
        return converted


class SectionInput(Input):
    stage_id: Identifier
    code: str = Field(min_length=1, max_length=30)
    name_ar: str = Field(min_length=1, max_length=60)


class SubjectInput(Input):
    code: str = Field(min_length=1, max_length=30)
    name_ar: str = Field(min_length=1, max_length=100)
    is_core: bool | None = None
    is_excluded: bool = False


class SubjectPolicy(Input):
    is_core: bool
    is_excluded: bool


class StageSubjectInput(Input):
    stage_id: Identifier
    subject_id: Identifier
    display_order: int = Field(default=0, ge=0)


class EnrollmentInput(Input):
    student_id: Identifier
    section_id: Identifier


class MaximumInput(Input):
    stage_subject_id: Identifier
    max_score: Amount = Field(gt=0)


class AssignmentInput(Input):
    teacher_id: Identifier
    section_id: Identifier
    stage_subject_id: Identifier


class ScoreInput(Input):
    enrollment_id: Identifier
    subject_maximum_id: Identifier
    round: Literal[1, 2] = 1
    score_status: Literal["PRESENT", "ABSENT", "CHEATING", "EXCUSED"] | None = None
    score: Amount | None = None

    @model_validator(mode="after")
    def validate_status(self):
        if (self.score_status == "PRESENT") != (self.score is not None):
            raise ValueError("الدرجة الرقمية للحاضر فقط؛ غيره يحتاج قيمة فارغة")
        return self


class ScoreBatch(Input):
    expected_revision: int = Field(ge=0)
    scores: list[ScoreInput] = Field(min_length=1, max_length=5000)


class PackageUpdate(Input):
    has_second_round: bool
    status: Literal["DRAFT", "PUBLISHED", "LOCKED"]
    expected_revision: int = Field(ge=0)


class UserInput(Input):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)
    username: str = Field(min_length=3, max_length=100, pattern=r"^[a-zA-Z0-9_.@-]+$")
    display_name: Name
    password: str = Field(min_length=12, max_length=256)
    role: Role
    employee_code: str | None = Field(default=None, min_length=1, max_length=40)

    @model_validator(mode="after")
    def teacher_code(self):
        if self.role == "TEACHER" and not self.employee_code:
            raise ValueError("رمز الموظف مطلوب للمعلم")
        return self


class MembershipInput(Input):
    user_id: Identifier
    role: Role
    employee_code: str | None = Field(default=None, min_length=1, max_length=40)


class UserStatus(Input):
    is_active: bool


class PasswordInput(Input):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)
    password: str = Field(min_length=12, max_length=256)


class LevelInput(Input):
    code: str = Field(min_length=1, max_length=20)
    label: str = Field(min_length=1, max_length=50)
    minimum_percent: Decimal = Field(ge=0, le=100, decimal_places=2, allow_inf_nan=False)


class SettingsInput(Input):
    school_name: Name
    decline_threshold_pp: Decimal = Field(gt=0, le=100, decimal_places=2, allow_inf_nan=False)
    levels: list[LevelInput] = Field(min_length=1, max_length=20)
    expected_revision: int = Field(ge=1)

    @model_validator(mode="after")
    def valid_levels(self):
        starts = [r.minimum_percent for r in self.levels]
        codes = [r.code for r in self.levels]
        if min(starts) != 0 or len(set(starts)) != len(starts) or len(set(codes)) != len(codes):
            raise ValueError("المستويات يجب أن تبدأ بصفر دون تكرار الحدود أو الرموز")
        return self
