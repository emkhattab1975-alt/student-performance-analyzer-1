"""Role-scoped presentation data, calculated exclusively from persisted school records."""
from collections import Counter, defaultdict
from fractions import Fraction

from fastapi import HTTPException
from . import domain as d, models as m
from .analytics import Analytics
from .repositories import AuthRepository


def context(repo):
    settings = repo.one(m.YearSettings)
    teacher = repo.teacher() if repo.context.role == "TEACHER" else None
    assignments = repo.all(m.Assignment, m.Assignment.teacher_id == teacher.id) if teacher else repo.all(m.Assignment)
    section_ids = {a.section_id for a in assignments}
    curriculum_ids = {a.stage_subject_id for a in assignments}
    curricula = repo.all(m.StageSubject, *([m.StageSubject.id.in_(curriculum_ids)] if teacher else []))
    sections = repo.all(m.Section, *([m.Section.id.in_(section_ids)] if teacher else []))
    subjects = repo.all(m.Subject, *([m.Subject.id.in_({c.subject_id for c in curricula})] if teacher else []))
    stages = repo.all(m.Stage, *([m.Stage.id.in_({s.stage_id for s in sections})] if teacher else []))
    teachers = [teacher] if teacher else repo.all(m.Teacher)
    auth = AuthRepository(repo.session)
    teacher_labels = []
    for item in teachers:
        member = repo.get(m.Membership, item.membership_id)
        user = auth.user(member.user_id)
        teacher_labels.append({"id": item.id, "name": user.display_name, "employee_code": item.employee_code})
    return {
        "academic_year_id": repo.year, "year_code": repo.year_record().code, "role": repo.context.role,
        "school_name": settings.school_name, "header_text": settings.header_text, "footer_text": settings.footer_text,
        "teacher_id": teacher.id if teacher else None,
        "packages": [{"id": p.id, "name_ar": p.name_ar, "sequence_no": p.sequence_no, "status": p.status,
                      "has_second_round": p.has_second_round, "data_revision": p.data_revision} for p in sorted(repo.all(m.Package), key=lambda x: x.sequence_no)],
        "stages": [{"id": s.id, "name_ar": s.name_ar} for s in stages],
        "sections": [{"id": s.id, "name_ar": s.name_ar, "stage_id": s.stage_id} for s in sections],
        "subjects": [{"id": s.id, "name_ar": s.name_ar, "is_core": s.is_core, "is_excluded": s.is_excluded} for s in subjects],
        "stage_subjects": [{"id": c.id, "stage_id": c.stage_id, "subject_id": c.subject_id} for c in curricula],
        "assignments": [{"id": a.id, "package_id": a.package_id, "teacher_id": a.teacher_id, "section_id": a.section_id, "stage_subject_id": a.stage_subject_id} for a in assignments],
        "teachers": teacher_labels,
        "levels": [{"label": l.label, "minimum_percent": str(l.minimum_percent)} for l in sorted(repo.all(m.PerformanceLevel), key=lambda l: l.minimum_percent, reverse=True)],
    }


def section_statistics(repo, package_id, stage_id=None, section_id=None, core_only=False):
    if stage_id:
        repo.get(m.Stage, stage_id)
    if section_id:
        section = repo.get(m.Section, section_id)
        if stage_id and section.stage_id != stage_id:
            raise HTTPException(422, "الشعبة لا تتبع المرحلة المحددة")
    rows = Analytics(repo).marks(package_id, stage_id=stage_id, section_id=section_id)
    grouped = defaultdict(list)
    for enrollment, marks in rows.values():
        for mark in marks:
            if not mark.excluded and (not core_only or mark.core):
                grouped[(enrollment.section_id, enrollment.stage_id, mark.subject_id)].append(mark)
    return [{"section_id": section, "stage_id": stage, "subject_id": subject, **d.subject_result(marks).output()}
            for (section, stage, subject), marks in grouped.items()]


def dashboard(repo, package_id, stage_id=None, section_id=None, core_only=False):
    analytics = Analytics(repo)
    statistics = section_statistics(repo, package_id, stage_id, section_id, core_only)
    marks = analytics.marks(package_id, stage_id=stage_id, section_id=section_id)
    scoped_marks = {eid: [m for m in items if not m.excluded and (not core_only or m.core)] for eid, (_, items) in marks.items()}
    pupils = set(scoped_marks)
    # An enrolled pupil exists even if no maxima or grades have been entered yet.
    pairs = repo.permitted_pairs(package_id)
    conditions = [m.Enrollment.package_id == package_id]
    if stage_id:
        conditions.append(m.Enrollment.stage_id == stage_id)
    if section_id:
        conditions.append(m.Enrollment.section_id == section_id)
    if pairs is not None:
        conditions.append(m.Enrollment.section_id.in_({sec for sec, _ in pairs}))
    pupils.update(e.id for e in repo.all(m.Enrollment, *conditions))
    counted = sum(any(mark.subject_included for mark in items) for items in scoped_marks.values())
    numeric = [d.subject_result(items).achievement for items in _group_marks(marks, core_only).values()]
    by_subject = defaultdict(list)
    for (_, _, subject), items in _group_marks(marks, core_only).items():
        by_subject[subject].append(d.subject_result(items).achievement)
    levels = []
    if repo.context.role != "TEACHER":
        results = analytics.student_report(package_id, section_id, stage_id)
        counts = Counter(row["level"] for row in results)
        levels = [{"name": level.label, "count": counts.get(level.label, 0)} for level in sorted(repo.all(m.PerformanceLevel), key=lambda l: l.minimum_percent, reverse=True)]
        if counts.get("غير متاح"):
            levels.append({"name": "بلا نسبة", "count": counts["غير متاح"]})
    trend = []
    for package in sorted(repo.all(m.Package), key=lambda p: p.sequence_no):
        values = _group_marks(analytics.marks(package.id, stage_id=stage_id, section_id=section_id), core_only)
        mean = d.average(d.subject_result(items).achievement for items in values.values())
        trend.append({"package_id": package.id, "name": package.name_ar, "achievement": d.display(mean)})
    return {"student_count": len(pupils), "counted_student_count": counted,
            "achievement": d.display(d.average(numeric)),
            "record_count": sum(row["included_students"] for row in statistics),
            "excluded_record_count": sum(row["excluded_students"] for row in statistics),
            "blank_record_count": sum(row["blank"] for row in statistics),
            "subject_count": len(by_subject), "section_count": len({row["section_id"] for row in statistics}),
            "subject_achievements": [{"subject_id": key, "achievement": d.display(d.average(values))} for key, values in by_subject.items()],
            "levels": levels, "trend": trend, "statistics": statistics,
            "has_results": any(v is not None for v in numeric)}


def _group_marks(rows, core_only):
    grouped = defaultdict(list)
    for enrollment, marks in rows.values():
        for mark in marks:
            if not mark.excluded and (not core_only or mark.core):
                grouped[(enrollment.section_id, enrollment.stage_id, mark.subject_id)].append(mark)
    return grouped
