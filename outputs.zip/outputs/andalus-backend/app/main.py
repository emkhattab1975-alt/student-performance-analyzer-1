from contextlib import asynccontextmanager
import secrets

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError, OperationalError

from . import models as m, schemas as s, workspace, excel_import, management, year_management
from .analytics import Analytics
from .config import Settings, get_settings
from .db import build_engine, session_factory
from .repositories import AuthRepository, YearContext, YearRepository
from .security import AuthService
from .security import hash_password
from .services import SchoolService, seed_year, snapshot

bearer = HTTPBearer(auto_error=False)


def database(request: Request):
    with request.app.state.sessions() as session:
        try:
            if request.method in {"POST", "PUT", "PATCH", "DELETE"} and session.bind.dialect.name == "sqlite":
                # Reserve SQLite's single writer before read/validate/write to prevent races.
                session.execute(text("BEGIN IMMEDIATE"))
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise


def current_user(request: Request, credentials: HTTPAuthorizationCredentials | None = Depends(bearer), session=Depends(database)):
    if not credentials:
        raise HTTPException(401, "تسجيل الدخول مطلوب")
    return AuthService(session, request.app.state.settings).authenticate(credentials.credentials)


def repository(year_id: str, request: Request, user=Depends(current_user), session=Depends(database)):
    auth = AuthRepository(session)
    membership = auth.membership(year_id, user.id)
    if not membership:
        raise HTTPException(403, "لا تملك صلاحية الوصول إلى هذا العام")
    repo = YearRepository(session, YearContext(year_id, user.id, membership.id, membership.role))
    if request.method in {"POST", "PUT", "PATCH", "DELETE"} and session.bind.dialect.name != "sqlite":
        # Serialize school mutations per year on PostgreSQL too.
        auth.lock_year(year_id)
    return repo


def create_app(settings: Settings | None = None, engine=None):
    settings = settings or get_settings()
    engine = engine or build_engine(settings.database_url)

    @asynccontextmanager
    async def lifespan(app):
        yield
        engine.dispose()

    app = FastAPI(title="مجمع الأندلس التعليمي — API النتائج", version="0.3.0", lifespan=lifespan,
                  description="قاعدة البيانات والمصادقة والحسابات وواجهات بيانات التطبيق العربي.")
    app.state.settings, app.state.engine, app.state.sessions = settings, engine, session_factory(engine)
    if settings.allowed_origins:
        app.add_middleware(CORSMiddleware, allow_origins=settings.allowed_origins, allow_credentials=False,
                           allow_methods=["GET", "POST", "PUT", "PATCH"], allow_headers=["Authorization", "Content-Type"])

    @app.exception_handler(IntegrityError)
    async def integrity_error(request, exc):
        return JSONResponse(status_code=409, content={"detail": "تعارض مع سجل موجود أو قيود الربط؛ لم يُعتمد الطلب"})

    @app.exception_handler(OperationalError)
    async def operational_error(request, exc):
        return JSONResponse(status_code=503, content={"detail": "قاعدة البيانات غير متاحة مؤقتاً؛ أعد المحاولة"}, headers={"Retry-After": "2"})

    @app.get("/health", tags=["system"])
    def health(session=Depends(database)):
        session.execute(text("SELECT 1"))
        return {"status": "ok", "version": "0.3.0"}

    def setup_access(request: Request):
        supplied = request.headers.get("X-Setup-Token", "")
        if not settings.setup_token or not secrets.compare_digest(supplied, settings.setup_token):
            raise HTTPException(403, "التهيئة الأولية غير متاحة")

    @app.get("/api/v1/setup", tags=["setup"])
    def setup_status(request: Request, session=Depends(database)):
        setup_access(request)
        return {"needs_setup": not AuthRepository(session).any_user_exists()}

    @app.post("/api/v1/setup", tags=["setup"], status_code=201)
    def setup(data: s.SetupInput, request: Request, session=Depends(database)):
        setup_access(request)
        auth = AuthRepository(session)
        if auth.any_user_exists():
            raise HTTPException(409, "تمت تهيئة النظام مسبقاً")
        user = auth.add(m.User(username=data.username.casefold(), display_name=data.display_name, password_hash=hash_password(data.password)))
        year = seed_year(session, data.code, data.starts_on, data.ends_on, user.id)
        return {"ok": True, "academic_year_id": year.id}

    @app.post("/api/v1/auth/login", tags=["auth"])
    def login(data: s.Login, session=Depends(database)):
        return AuthService(session, settings).login(data.username, data.password)

    @app.post("/api/v1/auth/refresh", tags=["auth"])
    def refresh(data: s.Refresh, session=Depends(database)):
        return AuthService(session, settings).refresh(data.refresh_token)

    @app.post("/api/v1/auth/logout", tags=["auth"])
    def logout(data: s.Refresh, session=Depends(database)):
        AuthService(session, settings).logout(data.refresh_token)
        return {"ok": True}

    @app.get("/api/v1/me", tags=["auth"])
    def me(user=Depends(current_user), session=Depends(database)):
        return {"id": user.id, "display_name": user.display_name,
                "memberships": [{"academic_year_id": row.academic_year_id, "role": row.role, **AuthRepository(session).year_info(row.academic_year_id)} for row in AuthRepository(session).memberships(user.id)]}

    prefix = "/api/v1/years/{year_id}"

    @app.get(prefix + "/imports", tags=["excel"])
    def excel_history(repo=Depends(repository)):
        return repo.recent_excel_uploads()

    @app.get(prefix + "/imports/templates/{kind}", tags=["excel"])
    def excel_template(kind: str, package_id: str | None = None, repo=Depends(repository)):
        return excel_import.template(repo, kind, package_id)

    @app.post(prefix + "/imports/preview/{kind}", tags=["excel"])
    def excel_preview(kind: str, data: excel_import.UploadInput, repo=Depends(repository)):
        return excel_import.preview(repo, kind, data)

    @app.post(prefix + "/imports/{upload_id}/approve", tags=["excel"])
    def excel_approve(upload_id: str, data: excel_import.ApprovalInput, repo=Depends(repository)):
        return excel_import.approve(repo, upload_id, data.acknowledge_replacement)

    @app.get(prefix + "/manage/{kind}", tags=["management"])
    def managed_records(kind: str, package_id: str | None = None, repo=Depends(repository)):
        return management.listing(repo,kind,package_id)

    @app.patch(prefix + "/manage/{kind}/{identifier}", tags=["management"])
    def edit_record(kind: str, identifier: str, data: management.EditInput, package_id: str | None = None, repo=Depends(repository)):
        return management.edit(repo,kind,identifier,package_id,data)

    @app.post(prefix + "/manage/{kind}/delete-preview", tags=["management"])
    def preview_record_deletion(kind: str, data: management.Selection, request: Request, package_id: str | None = None, repo=Depends(repository)):
        return management.delete_preview(repo,kind,package_id,data,request.app.state.settings.jwt_secret)

    @app.post(prefix + "/manage/{kind}/delete-confirm", tags=["management"])
    def confirm_record_deletion(kind: str, data: management.Confirmation, request: Request, package_id: str | None = None, repo=Depends(repository)):
        return management.delete_confirm(repo,kind,package_id,data,request.app.state.settings.jwt_secret,request.app.state.settings)

    @app.get(prefix + "/context", tags=["workspace"])
    def workspace_context(repo=Depends(repository)):
        return workspace.context(repo)

    @app.get(prefix + "/packages/{package_id}/dashboard", tags=["workspace"])
    def dashboard(package_id: str, stage_id: str | None = None, section_id: str | None = None, core_only: bool = False, repo=Depends(repository)):
        return workspace.dashboard(repo, package_id, stage_id, section_id, core_only)

    @app.get(prefix + "/packages/{package_id}/statistics", tags=["workspace"])
    def statistics(package_id: str, stage_id: str | None = None, section_id: str | None = None, core_only: bool = False, repo=Depends(repository)):
        return workspace.section_statistics(repo, package_id, stage_id, section_id, core_only)

    @app.get(prefix + "/users", tags=["administration"])
    def users(repo=Depends(repository)):
        return repo.users()

    @app.get(prefix + "/students", tags=["school"])
    def students(repo=Depends(repository)):
        repo.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        return [snapshot(row) for row in repo.all(m.Student)]

    @app.get(prefix + "/packages/{package_id}/editor", tags=["school"])
    def editor(package_id: str, repo=Depends(repository)):
        repo.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        package = repo.get(m.Package, package_id)
        return {"data_revision": package.data_revision, "status": package.status,
                "enrollments": [snapshot(row) for row in repo.all(m.Enrollment, m.Enrollment.package_id == package_id)],
                "maxima": [snapshot(row) for row in repo.all(m.SubjectMaximum, m.SubjectMaximum.package_id == package_id)],
                "scores": [snapshot(row) for row in repo.all(m.Score, m.Score.package_id == package_id)]}

    @app.post(prefix + "/years", tags=["administration"], status_code=201)
    def new_year(data: s.YearInput, repo=Depends(repository)):
        repo.context.require("SYSTEM_ADMIN")
        return snapshot(seed_year(repo.session, data.code, data.starts_on, data.ends_on, repo.context.user_id))

    @app.get(prefix + "/years", tags=["administration"])
    def list_years(repo=Depends(repository)):
        return year_management.listing(repo)

    @app.patch(prefix + "/year-details", tags=["administration"])
    def edit_year_details(data: year_management.EditInput, repo=Depends(repository)):
        return year_management.edit(repo,data)

    @app.post(prefix + "/set-current", tags=["administration"])
    def set_current_year(repo=Depends(repository)):
        return year_management.set_current(repo)

    @app.post(prefix + "/delete-year-preview", tags=["administration"])
    def preview_year_deletion(repo=Depends(repository)):
        return year_management.preview(repo, settings.jwt_secret)

    @app.post(prefix + "/delete-year-confirm", tags=["administration"])
    def confirm_year_deletion(data: year_management.Confirmation, repo=Depends(repository)):
        return year_management.confirm(repo, data, settings)

    @app.get(prefix + "/catalog", tags=["school"])
    def catalog(repo=Depends(repository)):
        repo.context.require("SYSTEM_ADMIN", "PRINCIPAL")
        return {name: [snapshot(row) for row in repo.all(model)] for name, model in {
            "packages": m.Package, "stages": m.Stage, "sections": m.Section, "subjects": m.Subject,
            "stage_subjects": m.StageSubject, "teachers": m.Teacher,
        }.items()}

    @app.get(prefix + "/my-assignments", tags=["school"])
    def my_assignments(repo=Depends(repository)):
        repo.context.require("TEACHER")
        return [snapshot(row) for row in repo.all(m.Assignment, m.Assignment.teacher_id == repo.teacher().id)]

    @app.post(prefix + "/students", tags=["school"], status_code=201)
    def student(data: s.StudentInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).create("students", data))

    @app.post(prefix + "/sections", tags=["administration"], status_code=201)
    def section(data: s.SectionInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).create("sections", data))

    @app.post(prefix + "/subjects", tags=["administration"], status_code=201)
    def subject(data: s.SubjectInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).create("subjects", data))

    @app.patch(prefix + "/subjects/{subject_id}/policy", tags=["administration"])
    def subject_policy(subject_id: str, data: s.SubjectPolicy, repo=Depends(repository)):
        return snapshot(SchoolService(repo).subject_policy(subject_id, data))

    @app.post(prefix + "/stage-subjects", tags=["administration"], status_code=201)
    def curriculum(data: s.StageSubjectInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).create("stage-subjects", data))

    package_prefix = prefix + "/packages/{package_id}"

    @app.patch(package_prefix, tags=["administration"])
    def package(package_id: str, data: s.PackageUpdate, repo=Depends(repository)):
        return snapshot(SchoolService(repo).package(package_id, data))

    @app.post(package_prefix + "/enrollments", tags=["school"], status_code=201)
    def enrollment(package_id: str, data: s.EnrollmentInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).create("enrollments", data, package_id))

    @app.put(package_prefix + "/maxima", tags=["school"])
    def maximum(package_id: str, data: s.MaximumInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).create("maxima", data, package_id))

    @app.post(package_prefix + "/assignments", tags=["administration"], status_code=201)
    def assignment(package_id: str, data: s.AssignmentInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).create("assignments", data, package_id))

    @app.put(package_prefix + "/scores", tags=["school"])
    def scores(package_id: str, data: s.ScoreBatch, repo=Depends(repository)):
        return SchoolService(repo).scores(package_id, data)

    @app.get(package_prefix + "/students", tags=["analytics"])
    def student_report(package_id: str, section_id: str | None = None, stage_id: str | None = None, repo=Depends(repository)):
        return Analytics(repo).student_report(package_id, section_id, stage_id)

    @app.get(package_prefix + "/subjects/{stage_subject_id}/sections/{section_id}", tags=["analytics"])
    def subject_report(package_id: str, stage_subject_id: str, section_id: str, repo=Depends(repository)):
        return Analytics(repo).subject_report(package_id, section_id, stage_subject_id)

    @app.get(package_prefix + "/teachers/{teacher_id}", tags=["analytics"])
    def teacher_report(package_id: str, teacher_id: str, repo=Depends(repository)):
        return Analytics(repo).teacher_report(package_id, teacher_id)

    @app.get(prefix + "/comparisons", tags=["analytics"])
    def comparison(first_package_id: str, second_package_id: str, section_id: str, core_only: bool = False, repo=Depends(repository)):
        return Analytics(repo).comparison(first_package_id, second_package_id, section_id, core_only)

    @app.get(prefix + "/student-progress", tags=["analytics"])
    def progress(first_package_id: str, second_package_id: str, repo=Depends(repository)):
        return Analytics(repo).progress(first_package_id, second_package_id)

    @app.get(prefix + "/settings", tags=["administration"])
    def settings_read(repo=Depends(repository)):
        repo.context.require("SYSTEM_ADMIN")
        return {"settings": snapshot(repo.one(m.YearSettings)), "levels": [snapshot(l) for l in repo.all(m.PerformanceLevel)]}

    @app.put(prefix + "/settings", tags=["administration"])
    def settings_write(data: s.SettingsInput, repo=Depends(repository)):
        return SchoolService(repo).settings(data)

    @app.post(prefix + "/users", tags=["administration"], status_code=201)
    def create_user(data: s.UserInput, repo=Depends(repository)):
        return SchoolService(repo).user(data)

    @app.post(prefix + "/memberships", tags=["administration"], status_code=201)
    def membership(data: s.MembershipInput, repo=Depends(repository)):
        return snapshot(SchoolService(repo).membership(data))

    @app.patch(prefix + "/users/{user_id}", tags=["administration"])
    def user_status(user_id: str, data: s.UserStatus, repo=Depends(repository)):
        return SchoolService(repo).user_change(user_id, active=data.is_active)

    @app.put(prefix + "/users/{user_id}/password", tags=["administration"])
    def password(user_id: str, data: s.PasswordInput, repo=Depends(repository)):
        return SchoolService(repo).user_change(user_id, password=data.password)

    @app.get(prefix + "/audit", tags=["administration"])
    def audit(repo=Depends(repository)):
        repo.context.require("SYSTEM_ADMIN")
        return [snapshot(row) for row in repo.recent_audit()]

    @app.get(prefix + "/events", tags=["notifications"])
    def events(repo=Depends(repository)):
        rows = repo.all(m.Event)
        if repo.context.role == "TEACHER":
            permitted = []
            for row in rows:
                if row.event_type != "GROUP_DECLINE" or not row.subject_id:
                    continue
                curriculum = repo.one(m.StageSubject, m.StageSubject.subject_id == row.subject_id, m.StageSubject.stage_id == row.stage_id)
                if not curriculum:
                    continue
                first = repo.permitted_pairs(row.payload["first_package_id"])
                second = repo.permitted_pairs(row.payload["second_package_id"])
                if (row.section_id, curriculum.id) in first & second:
                    permitted.append(row)
            rows = permitted
        return [snapshot(row) for row in sorted(rows, key=lambda e: e.created_at, reverse=True)[:200]]

    return app

