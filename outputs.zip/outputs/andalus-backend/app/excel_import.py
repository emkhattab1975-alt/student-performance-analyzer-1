"""Bounded XLSX import. Preview executes under rollback; approval replays atomically."""
import base64
from datetime import timedelta
from decimal import Decimal, InvalidOperation
from hashlib import sha256
from io import BytesIO
import json
import secrets
from zipfile import ZipFile, BadZipFile

from fastapi import HTTPException
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill
from pydantic import BaseModel, Field, ValidationError
from sqlalchemy.exc import IntegrityError

from . import models as m, schemas as s
from .analytics import Analytics
from .db import utcnow
from .repositories import AuthRepository
from .services import SchoolService, snapshot
from .security import hash_password

TEMPLATES = {
    'sections': ['الصف', 'المسار', 'رمز الشعبة', 'اسم الشعبة'],
    'subjects': ['رمز المادة', 'المادة', 'الصف', 'المسار'],
    'students': ['الرقم الشخصي', 'الاسم', 'الصف', 'المسار', 'الشعبة'],
    'grades': ['الرقم الشخصي', 'الاسم', 'الصف', 'المسار', 'الشعبة'],
    'teachers': ['اسم المستخدم', 'اسم المعلم', 'رمز الموظف', 'كلمة المرور'],
    'maxima': ['الصف', 'المسار', 'المادة', 'الدرجة النهائية'],
    'assignments': ['رمز الموظف', 'الصف', 'المسار', 'الشعبة', 'المادة'],
}
ADMIN_KINDS = {'sections', 'subjects', 'teachers'}
PACKAGE_KINDS = {'students', 'grades', 'maxima', 'assignments'}
MAX_BYTES = 1_000_000
MAX_ROWS = 2000


class UploadInput(BaseModel):
    filename: str = Field(min_length=1, max_length=200)
    content: str = Field(max_length=1_400_000)
    package_id: str | None = None
    round: int = Field(default=1, ge=1, le=2)


class ApprovalInput(BaseModel):
    acknowledge_replacement: bool = False


def require(r, kind, package_id=None):
    if kind not in TEMPLATES:
        raise HTTPException(404, 'نوع استيراد غير معروف')
    r.context.require(*(('SYSTEM_ADMIN',) if kind in ADMIN_KINDS else ('SYSTEM_ADMIN', 'PRINCIPAL')))
    if kind in PACKAGE_KINDS and not package_id:
        raise HTTPException(422, 'اختر الباقة أولاً')
    r.writable(package_id if kind in PACKAGE_KINDS else None)


def fingerprint(r, teacher_usernames=None):
    models = [m.Package, m.Stage, m.Section, m.Subject, m.StageSubject, m.Student,
              m.Enrollment, m.SubjectMaximum, m.Score, m.Teacher, m.Membership, m.YearSettings]
    data = {model.__tablename__: sorted([snapshot(row) for row in r.all(model)], key=lambda row: row['id']) for model in models}
    data['year'] = snapshot(r.year_record())
    auth = AuthRepository(r.session)
    data['identities'] = sorted([(u.id, u.username, u.display_name, u.auth_version, u.is_active) for member in r.all(m.Membership) if (u := auth.user(member.user_id))], key=lambda x:x[0])
    if teacher_usernames is not None:
        imported=[]
        for username in sorted(set(x.casefold() for x in teacher_usernames)):
            user=auth.by_username(username)
            if not user:
                imported.append([username,None]);continue
            members,profiles=auth.import_teacher_identity(user.id)
            imported.append([username,user.id,user.display_name,user.auth_version,user.is_active,
                             sorted((x.academic_year_id,x.id,x.role,x.is_active) for x in members),sorted(tuple(x) for x in profiles)])
        data['imported_identities']=imported
    return sha256(json.dumps(data, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def read_xlsx(encoded):
    try:
        raw = base64.b64decode(encoded, validate=True)
        if len(raw) > MAX_BYTES:
            raise ValueError('الحد الأقصى للملف ١ ميغابايت')
        with ZipFile(BytesIO(raw)) as archive:
            entries = archive.infolist()
            if len(entries) > 500 or sum(i.file_size for i in entries) > 20_000_000:
                raise ValueError('الملف أكبر من حدود المعالجة بعد فك الضغط')
            if any('vbaProject' in i.filename or i.filename.startswith('xl/externalLinks/') for i in entries):
                raise ValueError('الماكرو والروابط الخارجية غير مسموحة')
        book = load_workbook(BytesIO(raw), read_only=True, data_only=False, keep_links=False)
    except Exception as exc:
        raise HTTPException(422, str(exc) if isinstance(exc, ValueError) else 'ملف Excel غير صالح') from None
    try:
        sheets = [ws for ws in book.worksheets if ws.title != 'تعليمات']
        if len(sheets) != 1:
            raise HTTPException(422, 'استخدم ورقة بيانات واحدة فقط، عدا ورقة تعليمات القالب')
        ws = sheets[0]
        if (ws.max_row or 0) > MAX_ROWS + 1 or (ws.max_column or 0) > 100:
            raise HTTPException(422, 'الحد الأقصى ٢٠٠٠ صف و١٠٠ عمود؛ قسّم الملف')
        result, issues = [], []
        for row_index, row in enumerate(ws.iter_rows(max_row=MAX_ROWS + 2, max_col=min(ws.max_column or 1, 100)), 1):
            values = []
            for cell in row:
                value = cell.value
                if cell.data_type in ('f', 'e'):
                    issues.append({'row': row_index, 'column': cell.column_letter, 'message': 'الصيغ والأخطاء غير مسموحة؛ الصق القيم فقط'})
                if value is None:
                    values.append('')
                elif isinstance(value, (str, int, float)) and not isinstance(value, bool):
                    text = str(value).strip()
                    if isinstance(value, float) and value.is_integer():
                        text = str(int(value))
                    if isinstance(value, (int, float)) and str(cell.number_format).strip('0') == '':
                        text = text.zfill(len(cell.number_format))
                    if len(text) > 256:
                        issues.append({'row': row_index, 'column': cell.column_letter, 'message': 'قيمة أطول من ٢٥٦ محرفاً'})
                        text = text[:256]
                    values.append(text)
                else:
                    issues.append({'row': row_index, 'column': cell.column_letter, 'message': 'نوع الخلية غير مدعوم؛ استخدم نصاً أو رقماً'})
                    values.append('')
            if row_index == 1 or any(values):
                result.append((row_index, values))
        if len(result) < 2:
            raise HTTPException(422, 'الملف فارغ؛ أضف بيانات تحت العناوين')
        return raw, result, issues
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(422, 'تعذرت قراءة المصنف؛ احفظ نسخة .xlsx سليمة بلا صيغ أو روابط خارجية') from None
    finally:
        book.close()


def template(r, kind, package_id=None):
    require(r, kind, package_id)
    headers = list(TEMPLATES[kind])
    if kind == 'grades':
        headers += [row.name_ar for row in r.all(m.Subject)]
        if len(headers) == 5:
            raise HTTPException(422, 'عرّف المواد أولاً ثم نزّل قالب الدرجات')
    book = Workbook()
    ws = book.active
    ws.title = 'البيانات'
    ws.sheet_view.rightToLeft = True
    ws.append(headers)
    ws.freeze_panes = 'A2'
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='AC2440')
        ws.column_dimensions[cell.column_letter].width = 24
    # Empty text-formatted input rows protect leading zeros; no sample school records.
    for row in ws.iter_rows(min_row=2, max_row=101, max_col=len(headers)):
        for cell in row:
            cell.number_format = '@'
    note = book.create_sheet('تعليمات')
    note.sheet_view.rightToLeft = True
    instructions = [
        'أدخل بيانات المدرسة الحقيقية في ورقة البيانات. لا تعدّل أسماء الأعمدة الأساسية.',
        'العام والباقة والدور تُختار من شاشة الاستيراد؛ لا تحتاج إلى أعمدتها في الملف.',
        'الصف: 10 أو 11 أو 12. المسار: عام للعاشر، علمي أو أدبي للحادي عشر والثاني عشر.',
        'الشعبة: رمز الشعبة المطابق للنظام، وليس اسمها. المادة: اسم المادة العربي المطابق للنظام.',
        'الأرقام الشخصية ورموز الموظفين تُكتب كنص للحفاظ على الأصفار الأولى. لا تستخدم الصيغ.',
        'الدرجات: رقم للحاضر، غ للغائب، غش للغش، م للمعذور. الفراغ يلغي الدرجة ضمن الأعمدة المرفوعة فقط.',
        'يمكن حذف أعمدة المواد غير المطلوبة من قالب الدرجات؛ لا تتأثر درجات المواد المحذوفة من الملف.',
        'الخلايا الفارغة لمادة لا تخص صف الطالب تُتجاهل. وجود قيمة لمادة غير مرتبطة بالصف خطأ.',
        'المعاينة لا تعتمد سجلات المدرسة. اعتماد الملف عملية واحدة؛ أي خطأ يمنع الاعتماد كله.',
        'السجلات الموجودة تُطابق دون تغيير الأسماء أو الشعب. أي اختلاف يتطلب تصحيحه قبل الاستيراد.',
        'حسابات المعلمين: كلمة المرور اختيارية، من 6 إلى 256 محرفاً دون شروط تركيب. يمكن توحيدها؛ الفراغ يولّد كلمة للحساب الجديد ويُبقي كلمة الحساب الموجود. كلمة محددة تحدّث الحساب المطابق بعد تأكيد الاستبدال؛ الحساب مشترك بين الأعوام. اكتبها كنص؛ المسافات الطرفية تزال.',
        'نهاية المادة والأنصبة تخصان الباقة المختارة. لا يحذف الاستيراد أي سجلات غير واردة في الملف.',
    ]
    for line in instructions:
        note.append([line])
    note.column_dimensions['A'].width = 125
    out = BytesIO()
    book.save(out)
    return {'filename': kind + '.xlsx', 'content': base64.b64encode(out.getvalue()).decode()}


class RowProblem(Exception):
    def __init__(self, column, message):
        self.column, self.message = column, message


def fail(column, message):
    raise RowProblem(column, message)


def stage(r, row):
    grade = row['الصف'].translate(str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789'))
    track = {'': 'GENERAL', 'عام': 'GENERAL', 'GENERAL': 'GENERAL', 'علمي': 'SCIENCE', 'SCIENCE': 'SCIENCE', 'أدبي': 'ARTS', 'ادبي': 'ARTS', 'ARTS': 'ARTS'}.get(row['المسار'])
    if grade not in ('10', '11', '12'):
        fail('الصف', 'الصف يجب أن يكون 10 أو 11 أو 12')
    found = r.one(m.Stage, m.Stage.grade == int(grade), m.Stage.track == track)
    if not found:
        fail('المسار', 'المسار لا يتوافق مع الصف؛ العاشر عام، والبقية علمي أو أدبي')
    return found


def section(r, row, st):
    found = r.one(m.Section, m.Section.stage_id == st.id, m.Section.code == row['الشعبة'])
    if not found:
        fail('الشعبة', 'رمز الشعبة غير موجود في هذا الصف؛ استورد الشعب أولاً')
    return found


def curriculum(r, row, st):
    subject = r.one(m.Subject, m.Subject.normalized_name == ' '.join(row['المادة'].split()))
    if not subject:
        fail('المادة', 'مادة غير معروفة؛ استورد المواد أولاً')
    found = r.one(m.StageSubject, m.StageSubject.stage_id == st.id, m.StageSubject.subject_id == subject.id)
    if not found:
        fail('المادة', 'المادة غير مرتبطة بالصف')
    return found


def process_row(r, kind, row, pid, round_no, dry, seen, number=None, teacher_label=None):
    service = SchoolService(r, defer_analytics=True)
    changes = []
    def unique(key):
        if key in seen:
            fail('', 'سجل مكرر داخل الملف')
        seen.add(key)
    def create(resource, data, package=None):
        obj = service.create(resource, data, package)
        changes.append({'action': 'إضافة', 'entity': resource})
        return obj
    st = stage(r, row) if kind != 'teachers' else None
    if kind == 'sections':
        data = s.SectionInput(stage_id=st.id, code=row['رمز الشعبة'], name_ar=row['اسم الشعبة'])
        unique((st.id, data.code))
        old = r.one(m.Section, m.Section.stage_id == st.id, m.Section.code == data.code)
        if old and old.name_ar != data.name_ar:
            fail('اسم الشعبة', 'رمز الشعبة موجود باسم مختلف')
        if not old:
            create('sections', data)
    elif kind == 'subjects':
        data = s.SubjectInput(code=row['رمز المادة'], name_ar=row['المادة'])
        unique((st.id, data.code))
        old = r.one(m.Subject, m.Subject.code == data.code)
        if data.name_ar == 'المهارات الحياتية':
            old = r.one(m.Subject, m.Subject.code == 'LIFE_SKILLS')
        if old and old.name_ar != data.name_ar:
            fail('المادة', 'رمز المادة موجود باسم مختلف')
        subject = old or create('subjects', data)
        if not r.one(m.StageSubject, m.StageSubject.stage_id == st.id, m.StageSubject.subject_id == subject.id):
            create('stage-subjects', s.StageSubjectInput(stage_id=st.id, subject_id=subject.id))
    elif kind == 'teachers':
        data = s.UserInput(username=row['اسم المستخدم'], display_name=row['اسم المعلم'], employee_code=row['رمز الموظف'], password=secrets.token_urlsafe(18), role='TEACHER')
        unique(data.username.casefold())
        auth = AuthRepository(r.session)
        existing = auth.by_username(data.username.casefold())
        if existing:
            members,profiles=auth.import_teacher_identity(existing.id)
            member=next((x for x in members if x.academic_year_id==r.year),None)
            if not existing.is_active:
                fail('اسم المستخدم','الحساب معطل؛ راجعه في إدارة المستخدمين قبل ربطه بالعام')
            if any(x.role!='TEACHER' for x in members):
                fail('اسم المستخدم','الحساب مرتبط بصلاحيات مدير أو مدير نظام؛ لا يمكن ربطه أو تغيير كلمة مروره باستيراد المعلمين')
            if existing.display_name != data.display_name:
                fail('اسم المعلم','اسم المعلم لا يطابق الحساب الموجود؛ راجع هوية المعلم قبل ربطه بالعام')
            if any(code!=data.employee_code for code,_ in profiles):
                fail('رمز الموظف','رمز الموظف لا يطابق رمز الحساب الموجود؛ راجع هوية المعلم')
            profile=r.one(m.Teacher,m.Teacher.employee_code==data.employee_code)
            if member:
                if not member.is_active or not profile or profile.membership_id!=member.id:
                    fail('رمز الموظف','عضوية المعلم في هذا العام معطلة أو غير مطابقة؛ راجع إدارة المستخدمين')
            else:
                if profile:
                    fail('رمز الموظف','رمز الموظف مرتبط بحساب آخر في هذا العام')
                changes.append({'action':'إضافة','entity':'ربط حساب معلم موجود بالعام الدراسي','after':data.display_name+' ('+data.username.casefold()+')'})
                if dry:
                    member=r.add(m.Membership,user_id=existing.id,role='TEACHER')
                    r.add(m.Teacher,membership_id=member.id,employee_code=data.employee_code)
                else:
                    service.membership(s.MembershipInput(user_id=existing.id,role='TEACHER',employee_code=data.employee_code))
            if row.get('_password_hash'):
                changes.append({'action':'استبدال', 'entity':'كلمة مرور المعلم', 'before':'مخفية', 'after':'كلمة جديدة محددة في الملف؛ تنتهي الجلسات السابقة'})
                if not dry:
                    service.user_change(existing.id, imported_password_hash=row['_password_hash'])
            return changes, None
        if r.one(m.Teacher, m.Teacher.employee_code == data.employee_code):
            fail('رمز الموظف', 'رمز الموظف موجود مسبقاً')
        if dry:
            user = AuthRepository(r.session).add(m.User(username=data.username.casefold(), display_name=data.display_name, password_hash='PREVIEW-NOT-A-PASSWORD-HASH'))
            member = r.add(m.Membership, user_id=user.id, role='TEACHER')
            r.add(m.Teacher, membership_id=member.id, employee_code=data.employee_code)
        else:
            service.user(data, imported_password_hash=row.get('_password_hash'))
        changes.append({'action': 'إضافة', 'entity': 'teachers'})
        return changes, None if dry or row.get('_password_hash') else {'username': data.username.casefold(), 'name': data.display_name, 'password': data.password}
    elif kind in ('students', 'grades'):
        data = s.StudentInput(personal_number=row['الرقم الشخصي'], full_name=row['الاسم'])
        unique(data.personal_number)
        sec = section(r, row, st)
        old = r.one(m.Student, m.Student.personal_number == data.personal_number)
        if old and old.full_name != data.full_name:
            fail('الاسم', 'الرقم الشخصي موجود باسم مختلف؛ راجع الاسم قبل الاعتماد')
        student = old or create('students', data)
        enrollment = r.one(m.Enrollment, m.Enrollment.package_id == pid, m.Enrollment.student_id == student.id)
        if enrollment and enrollment.section_id != sec.id:
            fail('الشعبة', 'الطالب مسند إلى شعبة مختلفة في هذه الباقة؛ لن يُنقل تلقائياً')
        enrollment = enrollment or create('enrollments', s.EnrollmentInput(student_id=student.id, section_id=sec.id), pid)
        if kind == 'grades':
            scores = []
            for name, value in row.items():
                if name in TEMPLATES['grades']:
                    continue
                subject = r.one(m.Subject, m.Subject.normalized_name == ' '.join(name.split()))
                if not subject:
                    fail(name, 'عمود مادة غير معروفة')
                cur = r.one(m.StageSubject, m.StageSubject.stage_id == st.id, m.StageSubject.subject_id == subject.id)
                if not cur:
                    if value:
                        fail(name, 'هذه المادة لا تتبع صف الطالب')
                    continue
                maximum = r.one(m.SubjectMaximum, m.SubjectMaximum.package_id == pid, m.SubjectMaximum.stage_subject_id == cur.id)
                if not maximum:
                    if value:
                        fail(name, 'الدرجة النهائية للمادة غير محددة في الباقة')
                    continue
                status = {'غ': 'ABSENT', 'غائب': 'ABSENT', 'غش': 'CHEATING', 'م': 'EXCUSED', 'معذور': 'EXCUSED', '': None}.get(value, 'PRESENT')
                try:
                    amount = Decimal(value) if status == 'PRESENT' else None
                except InvalidOperation:
                    fail(name, 'استخدم درجة رقمية أو غ أو غش أو م أو اتركها فارغة')
                try:
                    item = s.ScoreInput(enrollment_id=enrollment.id, subject_maximum_id=maximum.id, round=round_no, score_status=status, score=amount)
                except ValidationError:
                    fail(name, 'الدرجة يجب أن تكون رقماً غير سالب بمنزلتين عشريتين كحد أقصى')
                if amount is not None and amount > maximum.max_score:
                    fail(name, f'الدرجة تتجاوز النهاية {maximum.max_score}')
                old_score = r.one(m.Score, m.Score.enrollment_id == enrollment.id, m.Score.subject_maximum_id == maximum.id, m.Score.round == round_no)
                if old_score and old_score.score_status == status and old_score.score == amount:
                    continue
                if not old_score and status is None:
                    continue
                changes.append({'action': 'استبدال' if old_score else 'إضافة', 'entity': name,
                                'before': {'status': old_score.score_status, 'score': str(old_score.score) if old_score.score is not None else None} if old_score else None,
                                'after': {'status': status, 'score': str(amount) if amount is not None else None}})
                scores.append(item)
            if scores:
                service.scores(pid, s.ScoreBatch(expected_revision=r.get(m.Package, pid).data_revision, scores=scores))
    elif kind == 'maxima':
        cur = curriculum(r, row, st)
        unique(cur.id)
        data = s.MaximumInput(stage_subject_id=cur.id, max_score=row['الدرجة النهائية'])
        old = r.one(m.SubjectMaximum, m.SubjectMaximum.package_id == pid, m.SubjectMaximum.stage_subject_id == cur.id)
        if not old or old.max_score != data.max_score:
            changes.append({'action': 'استبدال' if old else 'إضافة', 'entity': row['المادة'], 'before': str(old.max_score) if old else None, 'after': str(data.max_score)})
            service.create('maxima', data, pid)
    elif kind == 'assignments':
        cur, sec = curriculum(r, row, st), section(r, row, st)
        key = (sec.id, cur.id)
        if key in seen:
            first_number, first_teacher = seen[key]
            fail('المادة والشعبة', f'إسناد مكرر للمادة {row["المادة"]} والشعبة {row["الشعبة"]}: صف Excel {first_number}: {first_teacher}؛ وصف Excel {number}: {teacher_label}. احتفظ بالإسناد الصحيح أو صحح المادة/الشعبة؛ لا يمكن اعتماد الاثنين في الباقة نفسها')
        seen[key] = (number, teacher_label)
        teacher = r.one(m.Teacher, m.Teacher.employee_code == row['رمز الموظف'])
        if not teacher:
            fail('رمز الموظف', 'المعلم غير موجود في العام؛ استورد حسابات المعلمين أولاً')
        old = r.one(m.Assignment, m.Assignment.package_id == pid, m.Assignment.section_id == sec.id, m.Assignment.stage_subject_id == cur.id)
        if old and old.teacher_id != teacher.id:
            fail('رمز الموظف', 'المادة والشعبة مسندتان إلى معلم مختلف؛ لن يُستبدل الإسناد تلقائياً')
        if not old:
            create('assignments', s.AssignmentInput(teacher_id=teacher.id, section_id=sec.id, stage_subject_id=cur.id), pid)
    return changes, None


def execute(r, kind, payload, dry):
    rows, errors, credentials = [], [], []
    seen = {} if kind == 'assignments' else set()
    teacher_names = {}
    for number, row in payload['rows']:
        display_row = {k:v for k,v in row.items() if k != '_password_hash'}
        teacher_label = None
        if kind == 'assignments':
            code = row['رمز الموظف']
            if code not in teacher_names:
                teacher = r.one(m.Teacher, m.Teacher.employee_code == code)
                member = r.get(m.Membership, teacher.membership_id) if teacher else None
                user = AuthRepository(r.session).user(member.user_id) if member else None
                teacher_names[code] = user.display_name if user else 'معلم غير موجود في العام المختار'
            teacher_label = f'{teacher_names[code]} ({code})'
            display_row = {'رمز الموظف': code, 'اسم المعلم': teacher_names[code], **{k:v for k,v in row.items() if k != 'رمز الموظف'}}
        try:
            with r.session.begin_nested():
                changes, credential = process_row(r, kind, row, payload['package_id'], payload['round'], dry, seen, number, teacher_label)
            rows.append({'row': number, 'values': display_row, 'changes': changes})
            if credential:
                credentials.append(credential)
        except (RowProblem, ValidationError, HTTPException, IntegrityError) as exc:
            if not dry:
                raise HTTPException(409, 'تغيرت البيانات أو تعذر الاعتماد؛ لم يُحفظ أي جزء. أعد المعاينة') from None
            column, message = '', 'تعارض مع سجل موجود أو تكرار رمز داخل الملف'
            if isinstance(exc, RowProblem):
                column, message = exc.column, exc.message
            elif isinstance(exc, HTTPException):
                message = str(exc.detail)
            elif isinstance(exc, ValidationError):
                labels = {'username': 'اسم المستخدم', 'display_name': 'اسم المعلم', 'employee_code': 'رمز الموظف',
                          'personal_number': 'الرقم الشخصي', 'full_name': 'الاسم', 'code': 'الرمز',
                          'name_ar': 'الاسم', 'max_score': 'الدرجة النهائية'}
                fields = [str(e['loc'][-1]) for e in exc.errors() if e['loc']]
                column = '، '.join(labels.get(field, 'حقل مطلوب') for field in fields)
                tips = {'username': 'اسم المستخدم من ٣ إلى ١٠٠ محرف إنجليزي أو رقم دون مسافات',
                        'personal_number': 'الرقم الشخصي مطلوب كنص من أرقام فقط، حتى ٣٢ رقماً',
                        'max_score': 'النهاية رقم موجب بمنزلتين عشريتين كحد أقصى',
                        'employee_code': 'رمز الموظف مطلوب وبحد أقصى ٤٠ محرفاً'}
                message = '؛ '.join(tips.get(field, 'قيمة مفقودة أو أطول من الحد المسموح: ' + labels.get(field, 'حقل مطلوب')) for field in fields)
            if teacher_label:
                message = f'المعلم: {teacher_label} — {message}'
            errors.append({'row': number, 'column': column, 'message': message})
            rows.append({'row': number, 'values': display_row, 'changes': []})
    return {'rows': rows, 'errors': errors, 'row_count': len(rows),
            'replacement_count': sum(c['action'] == 'استبدال' for row in rows for c in row['changes']),
            'change_count': sum(len(row['changes']) for row in rows)}, credentials


def preview(r, kind, data):
    require(r, kind, data.package_id)
    if not data.filename.lower().endswith('.xlsx'):
        raise HTTPException(422, 'يدعم الاستيراد ملفات .xlsx فقط؛ احفظ الملف بهذه الصيغة من Excel')
    raw, table, issues = read_xlsx(data.content)
    headers = table[0][1]
    if any(not h for h in headers) or len(set(headers)) != len(headers):
        raise HTTPException(422, 'عناوين الأعمدة فارغة أو مكررة')
    required = TEMPLATES[kind]
    missing = set(required) - set(headers)
    if kind == 'teachers':
        missing.discard('كلمة المرور')
    extra = set(headers) - set(required)
    if missing or (extra and kind != 'grades'):
        raise HTTPException(422, 'الأعمدة لا تطابق القالب. مفقودة: ' + '، '.join(sorted(missing)) + '؛ غير متوقعة: ' + ('، '.join(sorted(extra)) if kind != 'grades' else ''))
    if kind == 'grades' and not extra:
        raise HTTPException(422, 'أضف عمود مادة واحداً على الأقل')
    if kind == 'grades' and len(extra) * (len(table) - 1) > 5000:
        raise HTTPException(422, 'الحد الأقصى ٥٠٠٠ خلية درجات؛ قسّم الملف')
    if kind == 'teachers' and len(table) > 201:
        raise HTTPException(422, 'الحد الأقصى ٢٠٠ حساب في الملف الواحد')
    payload = {'rows': [(n, dict(zip(headers, values))) for n, values in table[1:]],
               'package_id': data.package_id if kind in PACKAGE_KINDS else None, 'round': data.round}
    stored_content = data.content
    if kind == 'teachers':
        # Archive only a newly constructed, redacted workbook: no original cells,
        # comments, hidden sheets or shared strings containing credentials survive.
        archive_book = Workbook(); archive_sheet = archive_book.active
        archive_sheet.title = 'البيانات'; archive_sheet.append(TEMPLATES['teachers'])
        for number, row in payload['rows']:
            password = row.pop('كلمة المرور', '')
            if password:
                if not 6 <= len(password) <= 256:
                    issues.append({'row':number, 'column':'كلمة المرور', 'message':'كلمة المرور يجب أن تكون من 6 إلى 256 محرفاً؛ لا يشترط نوع محدد من المحارف'})
                else:
                    row['_password_hash'] = hash_password(password)
            row['كلمة المرور'] = 'محددة في الملف (مخفية)' if password else 'توليد تلقائي'
            archive_sheet.append([row.get(h, '') for h in TEMPLATES['teachers']])
        stream = BytesIO(); archive_book.save(stream)
        stored_content = base64.b64encode(stream.getvalue()).decode()
    teacher_usernames=[row['اسم المستخدم'] for _,row in payload['rows']] if kind=='teachers' else None
    before = fingerprint(r,teacher_usernames)
    transaction = r.session.begin_nested()
    try:
        result, _ = execute(r, kind, payload, True)
    finally:
        transaction.rollback()
        r.session.expire_all()
    result['errors'] = issues + result['errors']
    result['valid'] = not result['errors']
    job = r.add(m.ExcelUpload, uploaded_by=r.context.user_id, package_id=payload['package_id'], kind=kind,
                filename=data.filename, source_sha256=sha256(raw).hexdigest(), source_base64=stored_content,
                payload=payload, preview=result, fingerprint=before, status='READY' if result['valid'] else 'INVALID')
    r.audit('PREVIEW_EXCEL', 'excel_uploads', job.id, after={'kind': kind, 'sha256': job.source_sha256, 'rows': result['row_count'], 'errors': len(result['errors'])})
    return {'id': job.id, 'kind': kind, 'filename': job.filename, **result}


def approve(r, identifier, acknowledgement):
    job = r.get(m.ExcelUpload, identifier)
    require(r, job.kind, job.package_id)
    if job.uploaded_by != r.context.user_id:
        raise HTTPException(403, 'المعاينة تخص مستخدماً آخر')
    if job.status != 'READY':
        raise HTTPException(409, 'الملف يحتوي أخطاء أو اعتُمد مسبقاً')
    if utcnow() - job.created_at > timedelta(hours=24) or fingerprint(r,[row['اسم المستخدم'] for _,row in job.payload['rows']] if job.kind=='teachers' else None) != job.fingerprint:
        raise HTTPException(409, 'تغيرت بيانات النظام أو انتهت صلاحية المعاينة؛ ارفع الملف للمعاينة مجدداً')
    if job.preview['replacement_count'] and not acknowledgement:
        raise HTTPException(422, 'أكد استبدال القيم المعروضة في المعاينة أولاً')
    result, credentials = execute(r, job.kind, job.payload, False)
    if job.kind in PACKAGE_KINDS:
        Analytics(r).refresh_declines()
    job.status, job.applied_at = 'APPLIED', utcnow()
    r.audit('APPLY_EXCEL', 'excel_uploads', job.id, after={'kind': job.kind, 'sha256': job.source_sha256, 'rows': result['row_count'], 'changes': result['change_count']})
    r.add(m.Event, event_type='EXCEL_IMPORTED', package_id=job.package_id, payload={'kind': job.kind, 'rows': result['row_count']}, deduplication_key='excel:' + job.id)
    return {'id': job.id, 'saved_rows': result['row_count'], 'change_count': result['change_count'], 'credentials': credentials}
