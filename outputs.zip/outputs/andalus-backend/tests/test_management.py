from datetime import date
from sqlalchemy import select
from app import models as m
from app.repositories import AuthRepository
from app.services import seed_year
from conftest import post, mark, save_scores, PASSWORD
from test_api import teacher


def listing(e,kind,pid=None,headers=None):
    response=e['client'].get(e['prefix']+'/manage/'+kind,params={'package_id':pid} if pid else {},headers=headers or e['headers'])
    assert response.status_code==200,response.text
    return response.json()


def review(e,kind,ids,pid=None,rev=None,headers=None):
    return e['client'].post(e['prefix']+'/manage/'+kind+'/delete-preview',params={'package_id':pid} if pid else {},headers=headers or e['headers'],json={'ids':ids,'revision':rev or listing(e,kind,pid)['revision']})


def confirm(e,kind,token,pid=None,headers=None):
    return e['client'].post(e['prefix']+'/manage/'+kind+'/delete-confirm',params={'package_id':pid} if pid else {},headers=headers or e['headers'],json={'token':token})


def edit(e,kind,identifier,values,pid=None,rev=None,headers=None):
    return e['client'].patch(e['prefix']+'/manage/'+kind+'/'+identifier,params={'package_id':pid} if pid else {},headers=headers or e['headers'],json={'revision':rev or listing(e,kind,pid)['revision'],'values':values})


def test_individual_and_all_delete_only_explicit_ids(env):
    a=post(env,'/students',{'personal_number':'01','full_name':'أ'})
    b=post(env,'/students',{'personal_number':'02','full_name':'ب'})
    c=post(env,'/students',{'personal_number':'03','full_name':'ج'})
    first=review(env,'students',[a['id']]).json();assert first['token']
    assert len(listing(env,'students')['rows'])==3
    assert confirm(env,'students',first['token']).status_code==200
    assert confirm(env,'students',first['token']).status_code==409
    second=review(env,'students',[b['id'],c['id']]).json()
    assert confirm(env,'students',second['token']).json()['affected']==2
    assert listing(env,'students')['rows']==[]
    with env['sessions']() as session:
        audits=list(session.scalars(select(m.AuditLog).where(m.AuditLog.action=='DELETE_RECORD')))
        assert len(audits)==3 and all(x.before_json['full_name'] for x in audits)


def test_dependencies_block_whole_selection(school):
    e=school
    blank=post(e,'/students',{'personal_number':'99','full_name':'دون انتماء'})
    result=review(e,'students',[blank['id'],e['students'][0]['id']]).json()
    assert result['token'] is None and len(result['blocked'])==1
    assert len(listing(e,'students')['rows'])==4
    assert review(e,'sections',[e['section']['id']]).json()['blocked']
    assert review(e,'subjects',[e['subject']['id']]).json()['blocked']


def test_score_edit_delete_recalculates_and_keeps_other_package(school):
    e=school;p=e['packages'][0]['id'];p2=e['packages'][1]['id']
    save_scores(e,p,[mark(e,p,0,'PRESENT','90')]);save_scores(e,p2,[mark(e,p2,0,'PRESENT','40')])
    row=listing(e,'scores',p)['rows'][0]
    assert edit(e,'scores',row['id'],{'score_status':'ABSENT','score':None},p).status_code==200
    result=e['client'].get(e['prefix']+'/packages/'+p+'/students',headers=e['headers']).json()
    assert result
    assert edit(e,'scores',row['id'],{'score_status':'PRESENT','score':'101'},p).status_code==422
    token=review(e,'scores',[row['id']],p).json()['token']
    assert confirm(e,'scores',token,p2).status_code==403
    assert confirm(e,'scores',token,p).status_code==200
    assert listing(e,'scores',p)['rows']==[] and len(listing(e,'scores',p2)['rows'])==1


def test_stale_edit_and_tampered_delete_denied(env):
    student=post(env,'/students',{'personal_number':'01','full_name':'قبل'})
    current=listing(env,'students')['revision']
    token=review(env,'students',[student['id']]).json()['token']
    assert edit(env,'students',student['id'],{'personal_number':'01','full_name':'بعد'}).status_code==200
    assert edit(env,'students',student['id'],{'personal_number':'02','full_name':'قديم'},rev=current).status_code==409
    assert confirm(env,'students',token).status_code==409
    assert confirm(env,'students',token+'bad').status_code==409


def test_year_and_role_isolation(school):
    e=school;_,_,headers=teacher(e)
    for kind in ['students','teachers','scores']:
        response=e['client'].get(e['prefix']+'/manage/'+kind,headers=headers)
        assert response.status_code==403
    post(e,'/users',{'username':'manager_edit','display_name':'مدير','password':PASSWORD,'role':'PRINCIPAL'})
    login=e['client'].post('/api/v1/auth/login',json={'username':'manager_edit','password':PASSWORD}).json()
    manager={'Authorization':'Bearer '+login['access_token']}
    assert e['client'].get(e['prefix']+'/manage/teachers',headers=manager).status_code==403
    assert e['client'].get(e['prefix']+'/manage/students',headers=manager).status_code==200
    token=review(e,'students',[e['students'][0]['id']]).json()
    other=e['client'].patch('/api/v1/years/'+e['other']+'/manage/students/'+e['students'][0]['id'],headers=e['headers'],json={'revision':listing(e,'students')['revision'],'values':{'personal_number':'09','full_name':'غير مسموح'}})
    assert other.status_code in (404,409)
    assert e['client'].post(e['prefix']+'/years',headers=manager,json={'code':'2029','starts_on':'2029-01-01','ends_on':'2029-12-31'}).status_code==403


def test_teacher_disable_is_annual_and_restore_keeps_history(school):
    e=school;user,tid,headers=teacher(e)
    with e['sessions'].begin() as session:
        t=session.get(m.Teacher,tid);member=session.get(m.Membership,t.membership_id)
        user_id=member.user_id
        session.add(m.Membership(academic_year_id=e['other'],user_id=user_id,role='TEACHER'))
    row=listing(e,'teachers')['rows'][0]
    token=review(e,'teachers',[tid]).json()['token']
    assert confirm(e,'teachers',token).status_code==200
    assert e['client'].get(e['prefix']+'/context',headers=headers).status_code==403
    with e['sessions']() as session:
        assert AuthRepository(session).membership(e['other'],user_id) is not None
        assert session.get(m.User,user_id).is_active
    values=row['values'];values['is_active']=True;values['display_name']='اسم مصحح'
    assert edit(e,'teachers',tid,values).status_code==200
    assert e['client'].get(e['prefix']+'/context',headers=headers).status_code==200


def test_maximum_protection_and_valid_edit(school):
    e=school;p=e['packages'][0]['id'];save_scores(e,p,[mark(e,p,0,'PRESENT','90')])
    maximum=e['maxima'][p][0]['id']
    assert edit(e,'maxima',maximum,{'max_score':'80'},p).status_code==422
    assert edit(e,'maxima',maximum,{'max_score':'120'},p).status_code==200
    assert review(e,'maxima',[maximum],p).json()['blocked']


def test_locked_package_cannot_change_or_delete(school):
    e=school;p=e['packages'][0]['id'];save_scores(e,p,[mark(e,p,0,'PRESENT','40')])
    row=listing(e,'scores',p)['rows'][0]
    token=review(e,'scores',[row['id']],p).json()['token']
    with e['sessions'].begin() as session:session.get(m.Package,p).status='LOCKED'
    assert confirm(e,'scores',token,p).status_code==409
    assert edit(e,'scores',row['id'],{'score_status':'ABSENT','score':None},p).status_code==409


def test_subject_delete_also_removes_only_unused_curriculum(env):
    e=env;catalog=e['client'].get(e['prefix']+'/catalog',headers=e['headers']).json()
    sub=post(e,'/subjects',{'code':'ART','name_ar':'الفنون البصرية'})
    post(e,'/stage-subjects',{'stage_id':catalog['stages'][0]['id'],'subject_id':sub['id']})
    result=review(e,'subjects',[sub['id']]).json();assert result['curriculum_links']==1
    assert confirm(e,'subjects',result['token']).status_code==200
    assert listing(e,'subjects')['rows']==[]


def test_new_year_has_four_packages_and_no_copied_results(school):
    e=school
    year=post(e,'/years',{'code':'2030-2031','starts_on':'2030-09-01','ends_on':'2031-07-01'})
    ctx=e['client'].get('/api/v1/years/'+year['id']+'/context',headers=e['headers']).json()
    assert len(ctx['packages'])==4 and ctx['sections']==[] and ctx['subjects']==[]
    students=e['client'].get('/api/v1/years/'+year['id']+'/students',headers=e['headers']).json()
    assert students==[] and len(listing(e,'students')['rows'])==3


def test_assignment_and_enrollment_edits_validate_relations(school):
    e=school;p=e['packages'][0]['id'];_,tid,_=teacher(e)
    a=post(e,'/packages/'+p+'/assignments',{'teacher_id':tid,'section_id':e['section']['id'],'stage_subject_id':e['curriculum']['id']})
    assert edit(e,'assignments',a['id'],{'teacher_id':tid,'section_id':e['section2']['id'],'stage_subject_id':e['curriculum']['id']},p).status_code==200
    token=review(e,'assignments',[a['id']],p).json()['token']
    assert confirm(e,'assignments',token,p).status_code==200
    en=e['enrollments'][p][0]['id']
    assert edit(e,'enrollments',en,{'section_id':e['section2']['id']},p).status_code==200
    token=review(e,'enrollments',[en],p).json()['token']
    assert confirm(e,'enrollments',token,p).status_code==200


def test_round_two_requires_selected_first_and_no_extra_edit_keys(school):
    e=school;p=e['packages'][0]['id']
    with e['sessions'].begin() as session:session.get(m.Package,p).has_second_round=True
    save_scores(e,p,[mark(e,p,0,'EXCUSED')]);save_scores(e,p,[mark(e,p,0,'PRESENT','50',round=2)])
    rows=listing(e,'scores',p)['rows'];first=next(x for x in rows if 'الدور 1' in x['details'])
    assert review(e,'scores',[first['id']],p).json()['blocked']
    assert edit(e,'scores',first['id'],{'round':2,'score_status':None,'score':None},p).status_code==422
    token=review(e,'scores',[row['id'] for row in rows],p).json()['token']
    assert confirm(e,'scores',token,p).status_code==200
    assert listing(e,'scores',p)['rows']==[]


def test_student_name_and_section_saved_together_without_changing_other_package(school):
    e=school;p=e['packages'][0]['id'];p2=e['packages'][1]['id']
    save_scores(e,p,[mark(e,p,0,'PRESENT','90')])
    en=e['enrollments'][p][0]['id'];student_id=e['students'][0]['id']
    data=listing(e,'enrollments',p)
    assert [f['name'] for f in data['fields']]==['full_name','section_id']
    assert next(row for row in data['rows'] if row['id']==en)['values']['full_name']=='طالب 1'
    response=edit(e,'enrollments',en,{'full_name':'الاسم المصحح','section_id':e['section2']['id']},p)
    assert response.status_code==200,response.text
    with e['sessions']() as session:
        assert session.get(m.Student,student_id).full_name=='الاسم المصحح'
        assert session.get(m.Enrollment,en).section_id==e['section2']['id']
        assert session.get(m.Enrollment,e['enrollments'][p2][0]['id']).section_id==e['section']['id']
        assert session.scalar(select(m.Score).where(m.Score.enrollment_id==en)).score==90
        audits=list(session.scalars(select(m.AuditLog).where(m.AuditLog.action=='EDIT_RECORD')))
        assert any(a.entity_id==student_id and a.before_json['full_name']=='طالب 1' and a.after_json['full_name']=='الاسم المصحح' for a in audits)
        assert any(a.entity_id==en and a.after_json['section_id']==e['section2']['id'] for a in audits)


def test_combined_student_edit_invalid_move_rolls_back_name(school):
    e=school;p=e['packages'][0]['id'];en=e['enrollments'][p][0]['id']
    save_scores(e,p,[mark(e,p,0,'PRESENT','90')])
    stages=e['client'].get(e['prefix']+'/catalog',headers=e['headers']).json()['stages']
    stage=next(x for x in stages if x['grade']==11)
    section=post(e,'/sections',{'stage_id':stage['id'],'code':'Q','name_ar':'شعبة أخرى'})
    response=edit(e,'enrollments',en,{'full_name':'لا يجب حفظه','section_id':section['id']},p)
    assert response.status_code==422
    with e['sessions']() as session:
        assert session.get(m.Student,e['students'][0]['id']).full_name=='طالب 1'
        assert session.get(m.Enrollment,en).section_id==e['section']['id']


def test_combined_student_edit_rejects_empty_name_and_foreign_year_section(school):
    e=school;p=e['packages'][0]['id'];en=e['enrollments'][p][0]['id']
    assert edit(e,'enrollments',en,{'full_name':'  ','section_id':e['section2']['id']},p).status_code==422
    other_catalog=e['client'].get('/api/v1/years/'+e['other']+'/catalog',headers=e['headers']).json()
    section=e['client'].post('/api/v1/years/'+e['other']+'/sections',headers=e['headers'],json={'stage_id':other_catalog['stages'][0]['id'],'code':'A','name_ar':'أ'}).json()
    assert edit(e,'enrollments',en,{'full_name':'غير محفوظ','section_id':section['id']},p).status_code==404
    with e['sessions']() as session:assert session.get(m.Student,e['students'][0]['id']).full_name=='طالب 1'


def test_combined_student_edit_obeys_lock_and_teacher_permissions(school):
    e=school;p=e['packages'][0]['id'];en=e['enrollments'][p][0]['id'];_,_,headers=teacher(e)
    data={'full_name':'اسم جديد','section_id':e['section2']['id']}
    assert edit(e,'enrollments',en,data,p,headers=headers).status_code==403
    with e['sessions'].begin() as session:session.get(m.Package,p).status='LOCKED'
    assert edit(e,'enrollments',en,data,p).status_code==409
    with e['sessions']() as session:assert session.get(m.Student,e['students'][0]['id']).full_name=='طالب 1'
