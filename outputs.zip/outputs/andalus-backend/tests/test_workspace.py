from sqlalchemy import select
from app import models as m
from app.main import create_app
from app.config import Settings
from app.db import build_engine
from fastapi.testclient import TestClient
from alembic import command
from alembic.config import Config
from conftest import mark, post, save_scores, ROOT
from test_api import teacher, get


def test_empty_dashboard_has_no_fabricated_results(env):
    ctx = get(env, "/context")
    package = ctx["packages"][0]["id"]
    data = get(env, f"/packages/{package}/dashboard")
    assert data["student_count"] == 0
    assert data["achievement"] is None
    assert data["statistics"] == [] and data["subject_achievements"] == []
    assert not data["has_results"]
    assert all(row["achievement"] is None for row in data["trend"])


def test_teacher_context_and_dashboard_are_scoped(school):
    e = school
    p = e["packages"][0]["id"]
    _, tid, headers = teacher(e)
    post(e, f"/packages/{p}/assignments", {"teacher_id": tid, "section_id": e["section"]["id"], "stage_subject_id": e["curriculum"]["id"]})
    save_scores(e, p, [mark(e,p,0,"PRESENT","80"),mark(e,p,0,"PRESENT","10",subject_index=1)])
    ctx = get(e,"/context",headers)
    assert [s["id"] for s in ctx["subjects"]] == [e["subject"]["id"]]
    assert [s["id"] for s in ctx["sections"]] == [e["section"]["id"]]
    assert [t["id"] for t in ctx["teachers"]] == [tid]
    data = get(e,f"/packages/{p}/dashboard",headers)
    assert data["achievement"] == "80.00" and data["levels"] == []
    assert data["record_count"] == 1
    assert all(s["subject_id"] == e["subject"]["id"] for s in data["statistics"])
    for path in ["/students", "/users", f"/packages/{p}/editor"]:
        assert e["client"].get(e["prefix"]+path,headers=headers).status_code == 403


def test_user_directory_does_not_expose_credentials(env):
    data = get(env,"/users")
    assert data[0]["display_name"]
    assert "password_hash" not in str(data) and "token" not in str(data)
    me = env["client"].get("/api/v1/me",headers=env["headers"]).json()
    assert me["memberships"][0]["code"]


def test_statistics_coverage_matches_report(school):
    e, p = school, school["packages"][0]["id"]
    save_scores(e,p,[mark(e,p,0,"PRESENT","50"),mark(e,p,1,"ABSENT"),mark(e,p,2,"EXCUSED")])
    stats=get(e,f"/packages/{p}/statistics")
    row=next(r for r in stats if r["subject_id"]==e["subject"]["id"])
    assert row["total_students"]==3 and row["included_students"]==1 and row["absent"]==1 and row["excused"]==1
    assert row["achievement"]=="50.00" and row["pass_rate"]=="100.00"


def test_first_run_requires_internal_secret_and_runs_once(tmp_path,monkeypatch):
    url=f"sqlite:///{(tmp_path/'setup.db').as_posix()}"
    monkeypatch.setenv("ANDALUS_DATABASE_URL",url)
    command.upgrade(Config(str(ROOT/'alembic.ini')),"head")
    engine=build_engine(url)
    app=create_app(Settings(database_url=url,jwt_secret="s"*40,setup_token="t"*40),engine)
    headers={"X-Setup-Token":"t"*40}
    with TestClient(app) as client:
        assert client.get('/api/v1/setup').status_code==403
        assert client.get('/api/v1/setup',headers=headers).json()=={"needs_setup":True}
        payload={"username":"real_admin","display_name":"مدير المدرسة","password":"correct-horse-12345","code":"2026-2027","starts_on":"2026-09-01","ends_on":"2027-07-01"}
        assert client.post('/api/v1/setup',headers=headers,json=payload).status_code==201
        assert client.post('/api/v1/setup',headers=headers,json=payload).status_code==409
        assert client.get('/api/v1/setup',headers=headers).json()=={"needs_setup":False}
        login=client.post('/api/v1/auth/login',json={"username":payload['username'],"password":payload['password']})
        assert login.status_code==200
        with app.state.sessions() as session:
            assert session.scalar(select(m.Student.id)) is None
            assert session.scalar(select(m.Score.id)) is None
