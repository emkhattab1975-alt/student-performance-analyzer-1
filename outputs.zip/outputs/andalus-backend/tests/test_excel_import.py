import base64
from io import BytesIO
from openpyxl import Workbook, load_workbook
from sqlalchemy import select, func
from app import models as m
from app.excel_import import TEMPLATES
from conftest import post, mark, save_scores, PASSWORD
from test_api import teacher


def file_content(headers, rows):
    book=Workbook(); ws=book.active; ws.append(headers)
    for row in rows: ws.append(row)
    out=BytesIO(); book.save(out)
    return base64.b64encode(out.getvalue()).decode()


def preview(e, kind, rows, headers=None, package=None):
    return e['client'].post(e['prefix']+'/imports/preview/'+kind, headers=e['headers'], json={
        'filename':'school.xlsx','content':file_content(headers or TEMPLATES[kind],rows), 'package_id':package})


def approve(e, result, **values):
    return e['client'].post(e['prefix']+'/imports/'+result['id']+'/approve',headers=e['headers'],json=values)


def count(e, model):
    with e['sessions']() as session: return session.scalar(select(func.count()).select_from(model))


def test_sections_preview_is_read_only_and_commit_once(env):
    e=env
    response=preview(e,'sections',[[10,'عام','A','أ'],[11,'علمي','A','أ']])
    assert response.status_code==200,response.text
    result=response.json(); assert result['valid'] and count(e,m.Section)==0
    assert approve(e,result).status_code==200
    assert count(e,m.Section)==2
    assert approve(e,result).status_code==409
    assert count(e,m.Section)==2


def test_duplicate_and_unknown_stage_prevent_entire_file(env):
    r=preview(env,'sections',[[10,'عام','A','أ'],[10,'عام','A','أ'],[12,'عام','B','ب']]).json()
    assert not r['valid'] and len(r['errors'])==2
    assert approve(env,r).status_code==409 and count(env,m.Section)==0


def test_subjects_preserve_default_policies_and_link(env):
    r=preview(env,'subjects',[['MATH','الرياضيات',10,'عام'],['MATH','الرياضيات',11,'علمي'],['LIFE','المهارات الحياتية',10,'عام']]).json()
    assert r['valid'],r
    assert approve(env,r).status_code==200
    with env['sessions']() as session:
        subjects=list(session.scalars(select(m.Subject)))
        assert len(subjects)==2 and next(x for x in subjects if x.code=='LIFE_SKILLS').is_excluded
    assert count(env,m.StageSubject)==3


def test_grades_statuses_replacement_and_previous_version(school):
    e=school; pid=e['packages'][0]['id']; headers=TEMPLATES['grades']+['الرياضيات']
    rows=[['0001','طالب 1',10,'عام','A',80],['0002','طالب 2',10,'عام','A','غ'],['0003','طالب 3',10,'عام','A','م']]
    r=preview(e,'grades',rows,headers,pid).json(); assert r['valid'],r
    assert count(e,m.Score)==0
    assert approve(e,r).status_code==200
    rows[0][-1]=75; rows[1][-1]=''
    r2=preview(e,'grades',rows,headers,pid).json(); assert r2['replacement_count']==2
    assert approve(e,r2).status_code==422
    assert approve(e,r2,acknowledge_replacement=True).status_code==200
    with e['sessions']() as session:
        scores=list(session.scalars(select(m.Score)))
        assert {x.score_status for x in scores}=={'PRESENT','EXCUSED',None}
        uploads=list(session.scalars(select(m.ExcelUpload)))
        assert len(uploads)==2 and all(u.status=='APPLIED' for u in uploads)
        assert uploads[0].payload['rows'][0][1]['الرياضيات']=='80'
        audits=list(session.scalars(select(m.AuditLog).where(m.AuditLog.action=='UPDATE_SCORE')))
        assert any(a.before_json['score']==80 for a in audits)


def test_bad_grades_rollback_new_students_and_other_valid_rows(school):
    e=school; pid=e['packages'][0]['id']
    r=preview(e,'grades',[['0099','جديد',10,'عام','A',88],['0098','آخر',10,'عام','A',101]],TEMPLATES['grades']+['الرياضيات'],pid).json()
    assert not r['valid'] and r['errors'][0]['row']==3
    assert count(e,m.Student)==3 and count(e,m.Score)==0
    assert approve(e,r).status_code==409


def test_formula_and_headers_rejected(env):
    r=preview(env,'sections',[[10,'عام','A','=1+1']]).json()
    assert not r['valid'] and any('الصيغ' in x['message'] for x in r['errors'])
    assert preview(env,'sections',[[10]],['خطأ']).status_code==422


def test_stale_preview_and_cross_year_rejected(env):
    r=preview(env,'sections',[[10,'عام','A','أ']]).json()
    other=env['client'].post('/api/v1/years/'+env['other']+'/imports/'+r['id']+'/approve',headers=env['headers'],json={})
    assert other.status_code==404
    post(env,'/students',{'personal_number':'001','full_name':'حقيقي'})
    assert approve(env,r).status_code==409 and count(env,m.Section)==0


def test_teacher_account_password_is_only_returned_on_commit(env):
    r=preview(env,'teachers',[['math.teacher','معلم الرياضيات','EMP001']]).json()
    assert r['valid'] and count(env,m.User)==1
    assert 'password' not in str(r)
    response=approve(env,r); assert response.status_code==200,response.text
    credentials=response.json()['credentials']; assert len(credentials)==1
    credential=credentials[0]
    login=env['client'].post('/api/v1/auth/login',json={'username':credential['username'],'password':credential['password']})
    assert login.status_code==200
    with env['sessions']() as session:
        job=session.scalar(select(m.ExcelUpload))
        assert credential['password'] not in str(job.payload)+str(job.preview)+job.source_base64
        member=session.scalar(select(m.Membership).where(m.Membership.role=='TEACHER'))
        assert member.academic_year_id==env['year']
    assert approve(env,r).status_code==409
    again=preview(env,'teachers',[['math.teacher','معلم الرياضيات','EMP001']]).json()
    assert again['valid'] and again['change_count']==0 and count(env,m.User)==2


def test_roles_guard_preview_and_approval(school):
    e=school; _,_,teacher_headers=teacher(e)
    data={'filename':'x.xlsx','content':file_content(TEMPLATES['sections'],[[10,'عام','Z','ز']])}
    assert e['client'].post(e['prefix']+'/imports/preview/sections',headers=teacher_headers,json=data).status_code==403
    post(e,'/users',{'username':'principal_import','display_name':'مدير','password':PASSWORD,'role':'PRINCIPAL'})
    login=e['client'].post('/api/v1/auth/login',json={'username':'principal_import','password':PASSWORD}).json()
    headers={'Authorization':'Bearer '+login['access_token']}
    for kind in ['sections','subjects','teachers']:
        assert e['client'].post(e['prefix']+'/imports/preview/'+kind,headers=headers,json=data).status_code==403
    pid=e['packages'][0]['id']
    data.update(content=file_content(TEMPLATES['students'],[['0099','طالب جديد',10,'عام','A']]),package_id=pid)
    p=e['client'].post(e['prefix']+'/imports/preview/students',headers=headers,json=data)
    assert p.status_code==200 and p.json()['valid']
    assert approve(e,p.json()).status_code==403
    result=e['client'].post(e['prefix']+'/imports/'+p.json()['id']+'/approve',headers=headers,json={})
    assert result.status_code==200


def test_maxima_assignments_and_templates(school):
    e=school; pid=e['packages'][0]['id']; _,tid,_=teacher(e)
    with e['sessions']() as session: employee=session.get(m.Teacher,tid).employee_code
    r=preview(e,'assignments',[[employee,10,'عام','A','الرياضيات']],package=pid).json()
    assert r['valid'],r
    assert approve(e,r).status_code==200
    r=preview(e,'maxima',[[10,'عام','الرياضيات',50]],package=pid).json()
    assert r['valid'] and r['replacement_count']==1
    assert approve(e,r,acknowledge_replacement=True).status_code==200
    response=e['client'].get(e['prefix']+'/imports/templates/grades?package_id='+pid,headers=e['headers'])
    assert response.status_code==200
    book=load_workbook(BytesIO(base64.b64decode(response.json()['content'])))
    assert book['البيانات']['F1'].value=='الرياضيات'
    assert all(cell.value is None for row in book['البيانات'].iter_rows(min_row=2) for cell in row)


def test_second_round_requires_excuse(school):
    e=school; pid=e['packages'][0]['id']
    data={'filename':'x.xlsx','content':file_content(TEMPLATES['grades']+['الرياضيات'],[['0001','طالب 1',10,'عام','A',70]]),'package_id':pid,'round':2}
    r=e['client'].post(e['prefix']+'/imports/preview/grades',headers=e['headers'],json=data).json()
    assert not r['valid'] and count(e,m.Score)==0


def test_malformed_extension_formula_and_zip_limits(env):
    import zipfile
    import json
    import pytest
    base={'filename':'bad.xlsx','content':base64.b64encode(b'not a zip').decode()}
    response=env['client'].post(env['prefix']+'/imports/preview/sections',headers=env['headers'],json=base)
    assert response.status_code==422
    base['filename']='old.xls'
    assert env['client'].post(env['prefix']+'/imports/preview/sections',headers=env['headers'],json=base).status_code==422
    stream=BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('large.xml',b'0'*20_000_001)
    base.update(filename='large.xlsx',content=base64.b64encode(stream.getvalue()).decode())
    assert env['client'].post(env['prefix']+'/imports/preview/sections',headers=env['headers'],json=base).status_code==422


def test_preview_expires_and_closed_package_is_rejected(school):
    from datetime import timedelta
    from app.db import utcnow
    e=school
    result=preview(e,'sections',[[10,'عام','X','س']]).json()
    with e['sessions'].begin() as session:
        session.get(m.ExcelUpload,result['id']).created_at=utcnow()-timedelta(hours=25)
    assert approve(e,result).status_code==409
    pid=e['packages'][0]['id']
    with e['sessions'].begin() as session:
        session.get(m.Package,pid).status='LOCKED'
    response=preview(e,'students',[['090','اسم',10,'عام','A']],package=pid)
    assert response.status_code==409


def test_history_is_scoped_and_preserves_archive_without_credentials(env):
    result=preview(env,'sections',[[10,'عام','X','س']]).json()
    response=env['client'].get(env['prefix']+'/imports',headers=env['headers'])
    assert response.status_code==200,response.text
    assert response.json()[0]['id']==result['id'] and response.json()[0]['row_count']==1
    assert 'source_base64' not in response.text and 'payload' not in response.text
    other=env['client'].get('/api/v1/years/'+env['other']+'/imports',headers=env['headers'])
    assert other.json()==[]


def test_upgrade_from_existing_schema_preserves_school_records(tmp_path, monkeypatch):
    import sqlite3
    from datetime import date
    from alembic import command
    from alembic.config import Config
    from app.db import build_engine, session_factory
    from app.repositories import AuthRepository
    from app.services import seed_year
    from conftest import ROOT
    url='sqlite:///'+(tmp_path/'existing.db').as_posix()
    monkeypatch.setenv('ANDALUS_DATABASE_URL',url)
    cfg=Config(str(ROOT/'alembic.ini'))
    command.upgrade(cfg,'0002')
    engine=build_engine(url)
    with session_factory(engine).begin() as session:
        user=AuthRepository(session).add(m.User(username='preserved',display_name='اسم محفوظ',password_hash='existing-hash'))
        # Seed the historical schema through reflection: current ORM has newer columns.
        from sqlalchemy import MetaData, Table
        from uuid import uuid4
        from app.db import utcnow
        old_years=Table('academic_years',MetaData(),autoload_with=session.connection())
        year_id=str(uuid4())
        session.execute(old_years.insert().values(id=year_id,code='2026-2027',starts_on=date(2026,8,1),ends_on=date(2027,7,1),status='OPEN',created_at=utcnow()))
        for seq,code in enumerate(['MID_T1','END_T1','MID_T2','END_T2'],1):
            session.add(m.Package(academic_year_id=year_id,code=code,name_ar=code,sequence_no=seq))
        session.add(m.Student(academic_year_id=year_id,personal_number='000123',full_name='طالب محفوظ'))
    engine.dispose()
    command.upgrade(cfg,'head')
    with sqlite3.connect(tmp_path/'existing.db') as connection:
        assert connection.execute('select personal_number,full_name from students').fetchone()==('000123','طالب محفوظ')
        assert connection.execute('select username,password_hash from users').fetchone()==('preserved','existing-hash')
        assert connection.execute('select count(*) from packages').fetchone()[0]==4
        assert connection.execute('select count(*) from excel_uploads').fetchone()[0]==0
        assert connection.execute('select current_year_id from system_state').fetchone()[0]==year_id
        assert connection.execute('select deleted_at from academic_years').fetchone()[0] is None
        assert connection.execute('pragma foreign_key_check').fetchall()==[]

def test_assignment_preview_names_and_conflicting_excel_rows(school):
    e=school; teacher(e)
    post(e,'/users',{'username':'second_teacher','display_name':'المعلم الثاني','password':PASSWORD,'role':'TEACHER','employee_code':'T2'})
    pid=e['packages'][0]['id']
    result=preview(e,'assignments',[
        ['T1',10,'عام','A','الرياضيات'],
        ['T2',10,'عام','A','الرياضيات'],
        ['T1',10,'عام','A','الرياضيات'],
    ],package=pid).json()
    assert not result['valid'] and len(result['errors'])==2
    assert result['rows'][0]['values']['اسم المعلم']=='معلم'
    assert result['rows'][1]['values']['اسم المعلم']=='المعلم الثاني'
    message=result['errors'][0]['message']
    assert all(x in message for x in ['معلم (T1)','المعلم الثاني (T2)','صف Excel 2','صف Excel 3','الرياضيات','A'])
    assert 'صف Excel 4' in result['errors'][1]['message']
    assert count(e,m.Assignment)==0 and approve(e,result).status_code==409
    with e['sessions']() as session:
        job=session.get(m.ExcelUpload,result['id'])
        assert 'اسم المعلم' not in job.payload['rows'][0][1]
    valid=preview(e,'assignments',[['T1',10,'عام','A','الرياضيات']],package=pid).json()
    assert valid['valid'] and approve(e,valid).status_code==200


def test_assignment_error_includes_unknown_teacher_without_inventing_name(school):
    e=school
    result=preview(e,'assignments',[['UNKNOWN',10,'عام','A','الرياضيات']],package=e['packages'][0]['id']).json()
    assert not result['valid']
    assert result['rows'][0]['values']['اسم المعلم']=='معلم غير موجود في العام المختار'
    assert 'UNKNOWN' in result['errors'][0]['message']

def test_import_shared_password_hashes_and_redacts_every_persisted_preview(env):
    import json
    from zipfile import ZipFile
    secret='Shared123'
    result=preview(env,'teachers',[
        ['shared.one','المعلم الأول','SH1',secret],
        ['shared.two','المعلم الثاني','SH2',secret],
        ['random.three','المعلم الثالث','SH3',''],
    ]).json()
    assert result['valid'],result
    assert secret not in json.dumps(result,ensure_ascii=False)
    assert '_password_hash' not in str(result)
    with env['sessions']() as session:
        job=session.get(m.ExcelUpload,result['id'])
        assert secret not in str(job.payload)+str(job.preview)
        assert job.payload['rows'][0][1]['_password_hash'].startswith('$argon2')
        with ZipFile(BytesIO(base64.b64decode(job.source_base64))) as archive:
            assert all(secret.encode() not in archive.read(n) for n in archive.namelist())
    receipt=approve(env,result).json()
    assert len(receipt['credentials'])==1 and receipt['credentials'][0]['username']=='random.three'
    for username in ['shared.one','shared.two']:
        assert env['client'].post('/api/v1/auth/login',json={'username':username,'password':secret}).status_code==200
    with env['sessions']() as session:
        assert secret not in str([a.after_json for a in session.scalars(select(m.AuditLog))])


def test_short_password_blocks_all_and_legacy_template_still_works(env):
    result=preview(env,'teachers', [['short.user','معلم','BAD','12345']]).json()
    assert not result['valid'] and result['errors'][0]['column']=='كلمة المرور'
    assert approve(env,result).status_code==409 and count(env,m.User)==1
    result=preview(env,'teachers',[['old.template','معلم','OLD']],headers=TEMPLATES['teachers'][:3]).json()
    assert result['valid'] and approve(env,result).status_code==200

def test_reupload_teacher_password_requires_confirmation_and_revokes_login(env):
    e=env
    created=preview(e,'teachers',[['reset.teacher','معلم','RESET','before123']]).json()
    assert approve(e,created).status_code==200
    logged=e['client'].post('/api/v1/auth/login',json={'username':'reset.teacher','password':'before123'}).json()
    changed=preview(e,'teachers',[['reset.teacher','معلم','RESET','after123']]).json()
    assert changed['valid'] and changed['replacement_count']==1
    assert approve(e,changed).status_code==422
    assert e['client'].post('/api/v1/auth/login',json={'username':'reset.teacher','password':'before123'}).status_code==200
    assert approve(e,changed,acknowledge_replacement=True).status_code==200
    assert e['client'].post('/api/v1/auth/login',json={'username':'reset.teacher','password':'after123'}).status_code==200
    assert e['client'].post('/api/v1/auth/login',json={'username':'reset.teacher','password':'before123'}).status_code==401
    assert e['client'].get('/api/v1/me',headers={'Authorization':'Bearer '+logged['access_token']}).status_code==401
    blank=preview(e,'teachers',[['reset.teacher','معلم','RESET','']]).json()
    assert blank['valid'] and blank['change_count']==0
    assert approve(e,blank).status_code==200
    mismatch=preview(e,'teachers',[['reset.teacher','معلم','OTHER','wrong123']]).json()
    assert not mismatch['valid'] and approve(e,mismatch).status_code==409

def test_password_import_cannot_reset_principal_and_stales_after_other_reset(env):
    e=env
    post(e,'/users',{'username':'principal_pw','display_name':'مدير','password':PASSWORD,'role':'PRINCIPAL'})
    forbidden=preview(e,'teachers',[['principal_pw','مدير','P1','123456']]).json()
    assert not forbidden['valid'] and approve(e,forbidden).status_code==409
    created=preview(e,'teachers',[['same.teacher','معلم','SAME','001234']]).json()
    assert approve(e,created).status_code==200
    a=preview(e,'teachers',[['same.teacher','معلم','SAME','111111']]).json()
    b=preview(e,'teachers',[['same.teacher','معلم','SAME','222222']]).json()
    assert approve(e,a,acknowledge_replacement=True).status_code==200
    assert approve(e,b,acknowledge_replacement=True).status_code==409
