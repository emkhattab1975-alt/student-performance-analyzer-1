from decimal import Decimal as D
from fractions import Fraction as F
import random

import pytest

from app.domain import Mark, effective, student_result, subject_result, ranks, compare, average, display


def e(status="PRESENT", score="80", maximum="100", **kwargs):
    return effective("math", D(maximum), Mark(status, D(score) if score is not None else None), **kwargs)


@pytest.mark.parametrize("value,label", [("100", "ممتاز"), ("90", "ممتاز"), ("89.99", "جيد جداً"), ("80", "جيد جداً"), ("79.99", "جيد"), ("70", "جيد"), ("60", "متوسط"), ("50", "ضعيف"), ("49.99", "راسب"), ("0", "راسب")])
def test_levels(value, label):
    assert student_result([e(score=value)]).level == label


def test_student_weighted_totals_and_all_statuses():
    rows = [e(score="40", maximum="50"), e("ABSENT", None), e("CHEATING", None), e("EXCUSED", None), e(None, None), e(score="100", excluded=True), e(score="90", core=False)]
    result = student_result(rows)
    assert result.total == D(130)
    assert result.denominator == D(350)
    assert result.percentage == F(260, 7)
    assert result.flags == ("غائب", "غش")
    assert result.output()["marker"] == "*"


def test_no_denominator_unranked_and_no_fake_zero():
    result = student_result([e("EXCUSED", None), e(None, None), e(excluded=True)])
    assert result.percentage is None
    assert ranks({"a": result}) == {"a": None}
    assert subject_result([e("ABSENT", None)]).achievement is None


def test_second_round_replaces_excuse_and_zero_is_present():
    row = effective("math", D(100), Mark("EXCUSED"), Mark("PRESENT", D(0)), second_round_enabled=True)
    assert row.round_used == 2
    assert row.original_status == "EXCUSED"
    assert row.subject_included
    assert student_result([row]).percentage == 0
    assert subject_result([row]).included == 1


@pytest.mark.parametrize("status", ["ABSENT", "CHEATING", "EXCUSED", None])
def test_non_numeric_round_two_keeps_excuse(status):
    row = effective("math", D(100), Mark("EXCUSED"), Mark(status), second_round_enabled=True)
    assert row.mark.status == "EXCUSED"
    assert not row.student_included
    assert not row.subject_included


@pytest.mark.parametrize("first,enabled", [("PRESENT", True), ("ABSENT", True), ("CHEATING", True), (None, True), ("EXCUSED", False)])
def test_ineligible_round_two(first, enabled):
    with pytest.raises(ValueError):
        effective("s", D(100), Mark(first, D(50) if first == "PRESENT" else None), Mark("PRESENT", D(80)), second_round_enabled=enabled)


def test_subject_coverage_pass_boundary_excludes_absence():
    result = subject_result([e(score="50"), e(score="0"), e("ABSENT", None), e("CHEATING", None), e("EXCUSED", None), e(None, None)])
    assert result.achievement == 25
    assert result.pass_rate == 50
    assert result.included == 2 and result.total == 6
    assert result.included + result.absent + result.cheating + result.excused + result.blank == result.total


def test_competition_ranks_and_exact_not_display_ties():
    values = {"a": student_result([e(score="100")]), "b": student_result([e(score="90")]), "c": student_result([e(score="90")]), "d": student_result([e(score="80")])}
    assert ranks(values) == {"a": 1, "b": 2, "c": 2, "d": 4}
    a = student_result([e(score="8999.99", maximum="10000")])
    b = student_result([e(score="9000", maximum="10000")])
    assert display(a.percentage) == display(b.percentage) == "90.00"
    assert ranks({"a": a, "b": b}) == {"a": 2, "b": 1}
    assert a.level == "جيد جداً"


def test_group_comparison_common_subjects_and_threshold():
    result = compare({"math": F(80), "a": F(100)}, {"math": F(70), "b": F(0)})
    assert result["delta_pp"] == "-10.00" and result["is_decline"]
    assert result["shared_subject_ids"] == ["math"]
    assert result["omitted_subject_ids"] == ["a", "b"]
    assert compare({"a": None}, {"a": F(0)})["delta_pp"] is None
    assert average([F(100), F(50), None]) == 75


@pytest.mark.parametrize("status,score", [("OTHER", None), ("PRESENT", None), (None, D(0)), ("ABSENT", D(0)), ("PRESENT", D(-1)), ("PRESENT", D("NaN"))])
def test_bad_marks_rejected(status, score):
    with pytest.raises(ValueError):
        Mark(status, score)


def test_excluded_subject_never_counts():
    row = e(excluded=True)
    assert not row.subject_included and not row.student_included
    assert subject_result([row]).achievement is None


def test_randomized_totals_against_independent_integer_oracle():
    rng = random.Random(42)
    for _ in range(200):
        rows, points, denominator = [], 0, 0
        for i in range(12):
            maximum = rng.choice([20, 50, 100])
            status = rng.choice(["PRESENT", "ABSENT", "CHEATING", "EXCUSED", None])
            excluded = rng.choice([False, False, True])
            score = rng.randrange(maximum * 100 + 1) if status == "PRESENT" else None
            rows.append(effective(str(i), D(maximum), Mark(status, D(score) / 100 if score is not None else None), excluded=excluded))
            if not excluded and status in ("PRESENT", "ABSENT", "CHEATING"):
                denominator += maximum * 100
                points += score or 0
        result = student_result(rows)
        assert result.percentage == (F(points * 100, denominator) if denominator else None)
