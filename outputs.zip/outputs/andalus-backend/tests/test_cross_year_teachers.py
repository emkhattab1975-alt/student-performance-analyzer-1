import pytest
from sqlalchemy import select
from app import models as m
from conftest import post,PASSWORD
from test_excel_import import preview,approve,count


def existing(e,password='before123'):
    result=preview(e,'teachers',[['shared.teacher','معلم مشترك','T1',password]]).json()
    assert result['valid'] and approve(e,result).status_code==200
    return {**e,'prefix':'/api/v1/years/'+e['other'],'year':e['other'],'other':e['year']}

def test_link_existing_account_and_preserve_password(env):
    target=existing(env);before=count(env,m.User)
    result=preview(target,'teachers',[['shared.teacher','معلم مشترك','T1','']]).json()
    assert result['valid'] and result['replacement_count']==0 and result['change_count']==1
    assert 'ربط حساب' in result['rows'][0]['changes'][0]['entity']
    with env['sessions']() as s:
        assert not s.scalar(select(m.Teacher).where(m.Teacher.academic_year_id==target['year']))
    receipt=approve(target,result);assert receipt.status_code==200,receipt.text
    assert receipt.json()['credentials']==[] and count(env,m.User)==before
    response=env['client'].post('/api/v1/auth/login',json={'username':'shared.teacher','password':'before123'})
    assert response.status_code==200
    me=env['client'].get('/api/v1/me',headers={'Authorization':'Bearer '+response.json()['access_token']}).json()
    assert {x['academic_year_id'] for x in me['memberships']}=={env['year'],target['year']}
    users=env['client'].get(target['prefix']+'/users',headers=env['headers']).json()
    assert any(x['username']=='shared.teacher' for x in users)
    repeated=preview(target,'teachers',[['shared.teacher','معلم مشترك','T1','']]).json()
    assert repeated['change_count']==0 and approve(target,repeated).status_code==200

def test_link_and_reset_shared_password_requires_ack(env):
    target=existing(env)
    result=preview(target,'teachers',[['shared.teacher','معلم مشترك','T1','after123']]).json()
    assert result['valid'] and result['replacement_count']==1
    assert approve(target,result).status_code==422
    assert approve(target,result,acknowledge_replacement=True).status_code==200
    assert env['client'].post('/api/v1/auth/login',json={'username':'shared.teacher','password':'after123'}).status_code==200
    assert env['client'].post('/api/v1/auth/login',json={'username':'shared.teacher','password':'before123'}).status_code==401

@pytest.mark.parametrize('name,code',[('شخص آخر','T1'),('معلم مشترك','WRONG')])
def test_mismatched_identity_does_not_link(env,name,code):
    target=existing(env);result=preview(target,'teachers',[['shared.teacher',name,code,'after123']]).json()
    assert not result['valid'] and approve(target,result).status_code==409
    with env['sessions']() as s:assert not s.scalar(select(m.Teacher).where(m.Teacher.academic_year_id==target['year']))

def test_cannot_link_privileged_account_from_other_year(env):
    post(env,'/users',{'username':'principal','display_name':'مدير','password':PASSWORD,'role':'PRINCIPAL'})
    target={**env,'prefix':'/api/v1/years/'+env['other']}
    result=preview(target,'teachers',[['principal','مدير','P1','after123']]).json()
    assert not result['valid'] and approve(target,result).status_code==409

def test_source_password_change_stales_target_preview(env):
    target=existing(env)
    first=preview(target,'teachers',[['shared.teacher','معلم مشترك','T1','after123']]).json()
    source=preview(env,'teachers',[['shared.teacher','معلم مشترك','T1','changed123']]).json()
    assert approve(env,source,acknowledge_replacement=True).status_code==200
    assert approve(target,first,acknowledge_replacement=True).status_code==409

def test_target_code_collision_is_rejected(env):
    target=existing(env)
    other=preview(target,'teachers',[['different.teacher','معلم آخر','T1','other123']]).json()
    assert approve(target,other).status_code==200
    result=preview(target,'teachers',[['shared.teacher','معلم مشترك','T1','']]).json()
    assert not result['valid']

def test_disabled_membership_is_not_reactivated(env):
    target=existing(env)
    with env['sessions'].begin() as s:
        user=s.scalar(select(m.User).where(m.User.username=='shared.teacher'))
        s.add(m.Membership(academic_year_id=target['year'],user_id=user.id,role='TEACHER',is_active=False))
    result=preview(target,'teachers',[['shared.teacher','معلم مشترك','T1','after123']]).json()
    assert not result['valid']
