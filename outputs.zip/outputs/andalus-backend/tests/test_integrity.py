from datetime import timedelta
from decimal import Decimal
from io import StringIO
from pathlib import Path
import sqlite3
from uuid import uuid4

from alembic import command
from alembic.config import Config
import jwt
import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError

from app import models as m
from app.db import utcnow
from app.domain import display
from conftest import PASSWORD, mark, post, revision, save_scores, ROOT
from test_api import get, teacher


def test_audit_is_immutable_even_in_raw_sql(env):
    for statement in ["UPDATE audit_logs SET action='tampered'", "DELETE FROM audit_logs"]:
        with env["engine"].connect() as connection:
            with pytest.raises(IntegrityError):
                connection.execute(text(statement))
            connection.rollback()


def test_database_rejects_cross_package_score_and_invalid_null_status(school):
    e = school
    p1, p2 = [p["id"] for p in e["packages"][:2]]
    for wrong_package, wrong_status in [(True, False), (False, True)]:
        with e["sessions"]() as session:
            row = m.Score(academic_year_id=e["year"], package_id=p1, stage_id=e["stage"]["id"],
                          enrollment_id=e["enrollments"][p1][0]["id"], subject_maximum_id=e["maxima"][p2 if wrong_package else p1][0]["id"],
                          round=1, score_status=None if wrong_status else "PRESENT", score=Decimal(50))
            session.add(row)
            with pytest.raises(IntegrityError):
                session.flush()
            session.rollback()


def test_import_pointer_cannot_reference_another_scope(school):
    e, p = school, school["packages"][0]["id"]
    with e["sessions"].begin() as session:
        scopes = [m.ImportScope(academic_year_id=e["year"], package_id=p, stage_id=e["stage"]["id"], kind="GRADES", round_key=r) for r in (1, 2)]
        session.add_all(scopes)
        session.flush()
        batch = m.ImportBatch(academic_year_id=e["year"], scope_id=scopes[0].id, upload_group_id=str(uuid4()), version_no=1,
                              status="READY", original_filename="test.json", source_storage_key="test.json", source_sha256="0" * 64, uploaded_by=e["admin"])
        session.add(batch)
        session.flush()
        identifiers = scopes[1].id, batch.id
    with e["sessions"]() as session:
        scope = session.get(m.ImportScope, identifiers[0])
        scope.active_batch_id = identifiers[1]
        with pytest.raises(IntegrityError):
            session.flush()
        session.rollback()


def test_enrollment_history_and_full_cohort_comparison(school):
    e = school
    p1, p2 = [p["id"] for p in e["packages"][:2]]
    # One student moves between packages, keeping the earlier placement unchanged.
    with e["sessions"].begin() as session:
        enrollment = session.get(m.Enrollment, e["enrollments"][p2][2]["id"])
        enrollment.section_id = e["section2"]["id"]
    newcomer = post(e, "/students", {"personal_number": "0009", "full_name": "طالب جديد"})
    newcomer_enrollment = post(e, f"/packages/{p2}/enrollments", {"student_id": newcomer["id"], "section_id": e["section"]["id"]})
    save_scores(e, p1, [mark(e, p1, 0, "PRESENT", "100")])
    new_mark = {"enrollment_id": newcomer_enrollment["id"], "subject_maximum_id": e["maxima"][p2][0]["id"], "round": 1, "score_status": "PRESENT", "score": "0"}
    save_scores(e, p2, [mark(e, p2, 0, "PRESENT", "100"), new_mark])
    report = get(e, f'/comparisons?first_package_id={p1}&second_package_id={p2}&section_id={e["section"]["id"]}')
    assert report["overall"]["delta_pp"] == "-50.00"  # includes the newcomer, not only matched pupils
    history = get(e, f"/student-progress?first_package_id={p1}&second_package_id={p2}")
    changed = next(row for row in history if row["student_id"] == e["students"][2]["id"])
    assert changed["section_changed"]
    first = get(e, f"/packages/{p1}/students")
    assert next(row for row in first if row["student_id"] == e["students"][2]["id"])["section_id"] == e["section"]["id"]


def test_teacher_average_is_unweighted_and_comparison_needs_both_assignments(school):
    e = school
    p1, p2 = [p["id"] for p in e["packages"][:2]]
    _, tid, headers = teacher(e)
    for sec in (e["section"], e["section2"]):
        post(e, f"/packages/{p1}/assignments", {"teacher_id": tid, "section_id": sec["id"], "stage_subject_id": e["curriculum"]["id"]})
    student = post(e, "/students", {"personal_number": "0099", "full_name": "شعبة ب"})
    enrollment = post(e, f"/packages/{p1}/enrollments", {"student_id": student["id"], "section_id": e["section2"]["id"]})
    rows = [mark(e, p1, i, "PRESENT", "100") for i in range(3)]
    rows.append({"enrollment_id": enrollment["id"], "subject_maximum_id": e["maxima"][p1][0]["id"], "round": 1, "score_status": "PRESENT", "score": "0"})
    save_scores(e, p1, rows)
    result = get(e, f"/packages/{p1}/teachers/{tid}", headers)
    assert result[0]["achievement"] == "50.00"  # equal section weights, not pooled 75%
    comparison = f'/comparisons?first_package_id={p1}&second_package_id={p2}&section_id={e["section"]["id"]}'
    assert e["client"].get(e["prefix"] + comparison, headers=headers).status_code == 403
    post(e, f"/packages/{p2}/assignments", {"teacher_id": tid, "section_id": e["section"]["id"], "stage_subject_id": e["curriculum"]["id"]})
    save_scores(e, p2, [mark(e, p2, 0, "PRESENT", "60"), mark(e, p2, 0, "PRESENT", "15", subject_index=1)])
    result = get(e, comparison, headers)
    assert all(row["subject_id"] == e["subject"]["id"] for row in result["subjects"])
    events = get(e, "/events", headers)
    assert all(row["subject_id"] == e["subject"]["id"] for row in events)


def test_core_only_group_vs_student_total(school):
    e = school
    p1, p2 = [p["id"] for p in e["packages"][:2]]
    save_scores(e, p1, [mark(e, p1, 0, "PRESENT", "100"), mark(e, p1, 0, "PRESENT", "0", subject_index=1)])
    save_scores(e, p2, [mark(e, p2, 0, "PRESENT", "80"), mark(e, p2, 0, "PRESENT", "80", subject_index=1)])
    query = f'/comparisons?first_package_id={p1}&second_package_id={p2}&section_id={e["section"]["id"]}'
    assert get(e, query)["overall"]["delta_pp"] == "30.00"
    assert get(e, query + "&core_only=true")["overall"]["delta_pp"] == "-20.00"
    assert get(e, f"/packages/{p1}/students")[0]["percentage"] == "50.00"


def test_locked_package_rejects_writes(school):
    e, p = school, school["packages"][0]["id"]
    post(e, f"/packages/{p}", {"expected_revision": revision(e, p), "has_second_round": False, "status": "LOCKED"}, "patch")
    response = e["client"].put(e["prefix"] + f"/packages/{p}/scores", headers=e["headers"], json={"expected_revision": revision(e, p), "scores": [mark(e, p, 0, "PRESENT", "90")]})
    assert response.status_code == 409


@pytest.mark.parametrize("bad_score", ["NaN", "Infinity", "-1", "10.001"])
def test_score_decimal_validation(school, bad_score):
    e, p = school, school["packages"][0]["id"]
    response = e["client"].put(e["prefix"] + f"/packages/{p}/scores", headers=e["headers"], json={"expected_revision": revision(e, p), "scores": [mark(e, p, 0, "PRESENT", bad_score)]})
    assert response.status_code == 422


def test_expired_and_tampered_access_tokens(env):
    e = env
    original = e["headers"]["Authorization"].split()[1]
    payload = jwt.decode(original, options={"verify_signature": False})
    payload["exp"] = int((utcnow() - timedelta(hours=1)).timestamp())
    token = jwt.encode(payload, "test-secret-never-use-in-production-12345", algorithm="HS256")
    assert e["client"].get("/api/v1/me", headers={"Authorization": "Bearer " + token}).status_code == 401
    token = jwt.encode(payload, "some-other-secret-with-more-than-32-characters", algorithm="HS256")
    assert e["client"].get("/api/v1/me", headers={"Authorization": "Bearer " + token}).status_code == 401


def test_leading_zeros_and_repeated_student_in_same_year(env):
    e = env
    first = post(e, "/students", {"personal_number": "٠٠٠١٢٣", "full_name": "طالب"})
    assert first["personal_number"] == "000123"
    assert e["client"].post(e["prefix"] + "/students", headers=e["headers"], json={"personal_number": "000123", "full_name": "مكرر"}).status_code == 409
    assert e["client"].post(f'/api/v1/years/{e["other"]}/students', headers=e["headers"], json={"personal_number": "000123", "full_name": "العام التالي"}).status_code == 201


def test_postgresql_offline_migration_has_deferred_fk_and_no_duplicate_names(monkeypatch):
    output = StringIO()
    monkeypatch.setenv("ANDALUS_DATABASE_URL", "postgresql://localhost/andalus")
    cfg = Config(str(ROOT / "alembic.ini"), output_buffer=output)
    command.upgrade(cfg, "head", sql=True)
    sql = output.getvalue()
    assert "ALTER TABLE import_scopes ADD CONSTRAINT fk_scope_active_batch" in sql
    assert "CREATE TRIGGER audit_immutable" in sql
    for table in m.Base.metadata.tables.values():
        names = [str(c.name) for c in table.constraints if c.name]
        assert len(names) == len(set(names)), table.name


def test_migration_downgrade_and_upgrade_empty_database(tmp_path, monkeypatch):
    url = f"sqlite:///{(tmp_path / 'roundtrip.db').as_posix()}"
    monkeypatch.setenv("ANDALUS_DATABASE_URL", url)
    cfg = Config(str(ROOT / "alembic.ini"))
    command.upgrade(cfg, "head")
    command.downgrade(cfg, "base")
    command.upgrade(cfg, "head")
    with sqlite3.connect(tmp_path / "roundtrip.db") as db:
        assert db.execute("SELECT version_num FROM alembic_version").fetchone()[0] == "0004"


def test_concurrent_writers_cannot_overwrite_same_revision(school):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Barrier
    e, p = school, school["packages"][0]["id"]
    rev = revision(e, p)
    barrier = Barrier(2)

    def save(value):
        barrier.wait(timeout=10)
        return e["client"].put(e["prefix"] + f"/packages/{p}/scores", headers=e["headers"],
            json={"expected_revision": rev, "scores": [mark(e, p, 0, "PRESENT", value)]}).status_code

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(save, ["60", "90"]))
    assert sorted(results) == [200, 409]
    assert revision(e, p) == rev + 1
    with e["sessions"]() as session:
        assert len(list(session.scalars(select(m.Score)))) == 1
