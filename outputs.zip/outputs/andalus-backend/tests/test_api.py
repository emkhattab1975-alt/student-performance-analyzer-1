from decimal import Decimal
from sqlalchemy import select, text
import pytest

from app import models as m
from app.backups import run_backup
from app.repositories import YearContext, YearRepository
from conftest import PASSWORD, mark, post, revision, save_scores


def get(env, path, headers=None):
    response = env["client"].get(env["prefix"] + path, headers=headers or env["headers"])
    assert response.status_code == 200, response.text
    return response.json()


def teacher(env):
    user = post(env, "/users", {"username": "teacher", "display_name": "معلم", "password": PASSWORD,
                               "role": "TEACHER", "employee_code": "T1"})
    login = env["client"].post("/api/v1/auth/login", json={"username": "teacher", "password": PASSWORD}).json()
    headers = {"Authorization": "Bearer " + login["access_token"]}
    teachers = get(env, "/catalog")["teachers"]
    tid = next(t["id"] for t in teachers if t["membership_id"] == user["membership_id"])
    return user, tid, headers


def test_schema_wal_foreign_keys_and_seed(env):
    with env["engine"].connect() as connection:
        assert connection.exec_driver_sql("PRAGMA journal_mode").scalar() == "wal"
        assert connection.exec_driver_sql("PRAGMA foreign_keys").scalar() == 1
        assert connection.exec_driver_sql("PRAGMA foreign_key_check").all() == []
        assert connection.exec_driver_sql("SELECT version_num FROM alembic_version").scalar()
    catalog = get(env, "/catalog")
    assert len(catalog["packages"]) == 4 and len(catalog["stages"]) == 5
    assert env["client"].get("/health").json()["status"] == "ok"
    assert env["client"].get(env["prefix"] + "/catalog").status_code == 401


def test_results_and_absence_display(school):
    e = school
    p = e["packages"][0]["id"]
    save_scores(e, p, [mark(e, p, 0, "PRESENT", "100"), mark(e, p, 0, "ABSENT", subject_index=1),
                       mark(e, p, 1, "PRESENT", "80"), mark(e, p, 1, "PRESENT", "80", subject_index=1),
                       mark(e, p, 2, "EXCUSED")])
    students = get(e, f"/packages/{p}/students")
    by_id = {row["student_id"]: row for row in students}
    first = by_id[e["students"][0]["id"]]
    assert first["percentage"] == "50.00" and first["stage_rank"] == 2 and first["marker"] == "*"
    absent = next(s for s in first["subjects"] if s["subject_id"] == e["computing"]["id"])
    assert absent["score"] is None and absent["display"] == "غائب"
    assert by_id[e["students"][2]["id"]]["rank_label"] == "بلا ترتيب"
    report = get(e, f'/packages/{p}/subjects/{e["curriculum"]["id"]}/sections/{e["section"]["id"]}')
    assert report["achievement"] == "90.00" and report["included_students"] == 2 and report["excused"] == 1


def test_atomic_batch_and_optimistic_revision(school):
    e, p = school, school["packages"][0]["id"]
    rev = revision(e, p)
    response = e["client"].put(e["prefix"] + f"/packages/{p}/scores", headers=e["headers"], json={"expected_revision": rev,
        "scores": [mark(e, p, 0, "PRESENT", "50"), mark(e, p, 1, "PRESENT", "101")]})
    assert response.status_code == 422
    with e["sessions"]() as session:
        assert session.scalar(select(m.Score.id)) is None
        assert session.scalar(select(m.AuditLog.id).where(m.AuditLog.action == "CREATE_SCORE")) is None
    assert revision(e, p) == rev
    save_scores(e, p, [mark(e, p, 0, "PRESENT", "50")])
    response = e["client"].put(e["prefix"] + f"/packages/{p}/scores", headers=e["headers"], json={"expected_revision": rev, "scores": [mark(e, p, 1, "PRESENT", "60")]})
    assert response.status_code == 409


def test_round_two_and_maximum_change(school):
    e, p = school, school["packages"][0]["id"]
    save_scores(e, p, [mark(e, p, 0, "EXCUSED")])
    payload = {"expected_revision": revision(e, p), "scores": [mark(e, p, 0, "PRESENT", "85", round=2)]}
    assert e["client"].put(e["prefix"] + f"/packages/{p}/scores", json=payload, headers=e["headers"]).status_code == 422
    post(e, f"/packages/{p}", {"expected_revision": revision(e, p), "has_second_round": True, "status": "DRAFT"}, "patch")
    save_scores(e, p, [mark(e, p, 0, "PRESENT", "85", round=2)])
    student = next(row for row in get(e, f"/packages/{p}/students") if row["student_id"] == e["students"][0]["id"])
    math = next(s for s in student["subjects"] if s["subject_id"] == e["subject"]["id"])
    assert student["percentage"] == "85.00" and math["round_used"] == 2
    assert e["client"].put(e["prefix"] + f"/packages/{p}/maxima", headers=e["headers"], json={"stage_subject_id": e["curriculum"]["id"], "max_score": "80"}).status_code == 422
    assert e["client"].put(e["prefix"] + f"/packages/{p}/scores", headers=e["headers"], json={"expected_revision": revision(e, p), "scores": [mark(e, p, 0, "ABSENT")]}).status_code == 422


def test_teacher_cannot_read_overall_or_other_subject(school):
    e, p = school, school["packages"][0]["id"]
    _, tid, headers = teacher(e)
    post(e, f"/packages/{p}/assignments", {"teacher_id": tid, "section_id": e["section"]["id"], "stage_subject_id": e["curriculum"]["id"]})
    allowed = get(e, f'/packages/{p}/subjects/{e["curriculum"]["id"]}/sections/{e["section"]["id"]}', headers)
    assert "stage_rank" not in str(allowed) and "percentage" not in str(allowed)
    for path in [f"/packages/{p}/students", "/settings", "/audit", "/catalog",
                 f'/packages/{p}/subjects/{e["curriculum2"]["id"]}/sections/{e["section"]["id"]}',
                 f'/packages/{p}/subjects/{e["curriculum"]["id"]}/sections/{e["section2"]["id"]}']:
        assert e["client"].get(e["prefix"] + path, headers=headers).status_code == 403
    assert e["client"].post(e["prefix"] + "/students", headers=headers, json={"personal_number": "88", "full_name": "ممنوع"}).status_code == 403
    assert e["client"].get(f'/api/v1/years/{e["other"]}/catalog', headers=headers).status_code == 403


def test_principal_cannot_admin_but_can_enter_grades(school):
    e, p = school, school["packages"][0]["id"]
    post(e, "/users", {"username": "principal", "display_name": "المدير", "password": PASSWORD, "role": "PRINCIPAL"})
    token = e["client"].post("/api/v1/auth/login", json={"username": "principal", "password": PASSWORD}).json()["access_token"]
    h = {"Authorization": "Bearer " + token}
    assert e["client"].get(e["prefix"] + "/settings", headers=h).status_code == 403
    assert e["client"].post(e["prefix"] + "/users", headers=h, json={"username": "illegal", "display_name": "x", "password": PASSWORD, "role": "SYSTEM_ADMIN"}).status_code == 403
    assert e["client"].put(e["prefix"] + f"/packages/{p}/scores", headers=h, json={"expected_revision": revision(e, p), "scores": [mark(e, p, 0, "PRESENT", "90")]}).status_code == 200


def test_cross_year_ids_rejected_at_api_and_database(school):
    e, p = school, school["packages"][0]["id"]
    other_catalog = e["client"].get(f'/api/v1/years/{e["other"]}/catalog', headers=e["headers"]).json()
    foreign_stage = other_catalog["stages"][0]["id"]
    assert e["client"].post(e["prefix"] + "/sections", headers=e["headers"], json={"stage_id": foreign_stage, "code": "X", "name_ar": "X"}).status_code == 404
    from sqlalchemy.exc import IntegrityError
    with e["sessions"]() as session:
        session.add(m.Section(academic_year_id=e["year"], stage_id=foreign_stage, code="X", name_ar="X"))
        with pytest.raises(IntegrityError):
            session.flush()
        session.rollback()
    with e["sessions"]() as session:
        repo = YearRepository(session, YearContext(e["other"], e["admin"], "unused", "SYSTEM_ADMIN"))
        assert repo.all(m.Student) == []


def test_comparison_alert_resolution_and_common_subjects(school):
    e = school
    p1, p2 = [p["id"] for p in e["packages"][:2]]
    save_scores(e, p1, [mark(e, p1, 0, "PRESENT", "90"), mark(e, p1, 1, "ABSENT")])
    save_scores(e, p2, [mark(e, p2, 0, "PRESENT", "70"), mark(e, p2, 1, "CHEATING")])
    path = f'/comparisons?first_package_id={p1}&second_package_id={p2}&section_id={e["section"]["id"]}'
    report = get(e, path)
    assert report["overall"]["delta_pp"] == "-20.00"
    events = get(e, "/events")
    assert sum(ev["event_type"] == "GROUP_DECLINE" and ev["resolved_at"] is None for ev in events) == 2
    save_scores(e, p2, [mark(e, p2, 0, "PRESENT", "95")])
    assert all(ev["resolved_at"] is not None for ev in get(e, "/events") if ev["event_type"] == "GROUP_DECLINE")


def test_refresh_rotation_reuse_and_user_revocation(env):
    e = env
    login = e["client"].post("/api/v1/auth/login", json={"username": "admin", "password": PASSWORD}).json()
    old = login["refresh_token"]
    fresh = e["client"].post("/api/v1/auth/refresh", json={"refresh_token": old})
    assert fresh.status_code == 200
    assert e["client"].post("/api/v1/auth/refresh", json={"refresh_token": old}).status_code == 401
    assert e["client"].post("/api/v1/auth/refresh", json={"refresh_token": fresh.json()["refresh_token"]}).status_code == 401
    user = post(e, "/users", {"username": "reader", "display_name": "مدير", "password": PASSWORD, "role": "PRINCIPAL"})
    token = e["client"].post("/api/v1/auth/login", json={"username": "reader", "password": PASSWORD}).json()["access_token"]
    post(e, f'/users/{user["id"]}', {"is_active": False}, "patch")
    assert e["client"].get("/api/v1/me", headers={"Authorization": "Bearer " + token}).status_code == 401


def test_settings_audit_levels_and_life_skills(env):
    e = env
    subject = post(e, "/subjects", {"code": "LIFE", "name_ar": "المهارات الحياتية", "is_core": True})
    assert subject["is_excluded"] and not subject["is_core"]
    assert e["client"].patch(e["prefix"] + f'/subjects/{subject["id"]}/policy', headers=e["headers"], json={"is_core": True, "is_excluded": False}).status_code == 422
    data = {"school_name": "مجمع الأندلس التعليمي", "decline_threshold_pp": "12", "expected_revision": 1,
            "levels": [{"code": "LOW", "label": "منخفض", "minimum_percent": 0}, {"code": "HIGH", "label": "مرتفع", "minimum_percent": 75}]}
    assert post(e, "/settings", data, "put")["settings"]["revision"] == 2
    assert e["client"].put(e["prefix"] + "/settings", headers=e["headers"], json=data).status_code == 409
    assert any(row["action"] == "UPDATE_SETTINGS" for row in get(e, "/audit"))


def test_backup_verified_restore(env):
    import sqlite3
    path = run_backup(env["engine"], env["tmp"] / "backups")
    with sqlite3.connect(path) as db:
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []
        assert db.execute("SELECT COUNT(*) FROM academic_years").fetchone()[0] == 2
    with env["sessions"]() as session:
        row = session.scalar(select(m.BackupRun))
        assert row.status == "COMPLETED" and row.verified_at and row.checksum
