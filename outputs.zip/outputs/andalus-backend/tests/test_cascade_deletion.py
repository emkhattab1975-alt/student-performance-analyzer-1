import pytest
from sqlalchemy import select,text
from app import models as m
from conftest import post,mark,save_scores,PASSWORD
from test_api import teacher
from test_management import listing,confirm


def preview(e,kind,ids,pid=None,headers=None):
    e['client'].app.state.settings.backup_directory=str(e['tmp']/'backups')
    return e['client'].post(e['prefix']+'/manage/'+kind+'/delete-preview',params={'package_id':pid} if pid else {},headers=headers or e['headers'],json={'ids':ids,'revision':listing(e,kind,pid)['revision'],'cascade':True})

@pytest.mark.parametrize('kind',['students','sections','subjects','teachers','enrollments','scores','assignments','maxima'])
def test_current_year_individual_cascade(school,kind):
    e=school;p=e['packages'][0]['id'];p2=e['packages'][1]['id'];_,tid,teacher_headers=teacher(e)
    assignment=post(e,'/packages/'+p+'/assignments',{'teacher_id':tid,'section_id':e['section']['id'],'stage_subject_id':e['curriculum']['id']})
    save_scores(e,p,[mark(e,p,0,'PRESENT','90'),mark(e,p,1,'PRESENT','60')]);save_scores(e,p2,[mark(e,p2,0,'PRESENT','80')])
    roots={'students':e['students'][0]['id'],'sections':e['section']['id'],'subjects':e['subject']['id'],'teachers':tid,'enrollments':e['enrollments'][p][0]['id'],'maxima':e['maxima'][p][0]['id'],'assignments':assignment['id'],'scores':listing(e,'scores',p)['rows'][0]['id']}
    models={'students':m.Student,'sections':m.Section,'subjects':m.Subject,'teachers':m.Teacher,'enrollments':m.Enrollment,'maxima':m.SubjectMaximum,'assignments':m.Assignment,'scores':m.Score}
    pid=p if kind in ['enrollments','maxima','assignments','scores'] else None
    result=preview(e,kind,[roots[kind]],pid);assert result.status_code==200,result.text
    data=result.json();assert data['token'] and not data['blocked'] and data['summary']
    with e['sessions']() as s:assert s.get(models[kind],roots[kind]) is not None
    res=confirm(e,kind,data['token'],pid);assert res.status_code==200,res.text
    assert res.json()['total_deleted']==data['total_deleted']
    assert len(list((e['tmp']/'backups').glob('*.db')))==1
    with e['sessions']() as s:
        assert s.get(models[kind],roots[kind]) is None
        assert s.get(m.SystemState,1).current_year_id==e['year']
        assert s.get(m.AcademicYear,e['year']).deleted_at is None
        assert len(list(s.scalars(select(m.Package).where(m.Package.academic_year_id==e['other']))))==4
        assert not s.execute(text('PRAGMA foreign_key_check')).all()
        if kind in ['sections','subjects']:
            assert not list(s.scalars(select(m.Score).where(m.Score.academic_year_id==e['year'])))
            assert len(list(s.scalars(select(m.Student).where(m.Student.academic_year_id==e['year']))))==3
        if pid:
            assert len(list(s.scalars(select(m.Score).where(m.Score.package_id==p2))))==1
        if kind=='students':
            assert len(list(s.scalars(select(m.Score).where(m.Score.academic_year_id==e['year']))))==1
        if kind=='teachers':
            assert len(list(s.scalars(select(m.Score).where(m.Score.academic_year_id==e['year']))))==3
    if kind=='teachers':assert e['client'].get(e['prefix']+'/context',headers=teacher_headers).status_code==403

def test_bulk_selection_removes_only_selected_students(school):
    e=school;p=e['packages'][0]['id'];save_scores(e,p,[mark(e,p,i,'PRESENT','70') for i in range(3)])
    ids=[s['id'] for s in e['students'][:2]]
    data=preview(e,'students',ids).json();assert data['count']==2
    assert confirm(e,'students',data['token']).json()['affected']==2
    assert [x['id'] for x in listing(e,'students')['rows']]==[e['students'][2]['id']]
    assert len(listing(e,'scores',p)['rows'])==1

def test_new_dependency_invalidates_preview(school):
    e=school;_,tid,_=teacher(e);p=e['packages'][0]['id']
    data=preview(e,'sections',[e['section']['id']]).json()
    post(e,'/packages/'+p+'/assignments',{'teacher_id':tid,'section_id':e['section']['id'],'stage_subject_id':e['curriculum']['id']})
    assert confirm(e,'sections',data['token']).status_code==409
    assert len(listing(e,'sections')['rows'])==2

def test_teacher_deletion_preserves_shared_account(school):
    e=school;_,tid,_=teacher(e)
    with e['sessions'].begin() as s:
        member=s.get(m.Membership,s.get(m.Teacher,tid).membership_id);uid=member.user_id
        s.add(m.Membership(academic_year_id=e['other'],user_id=uid,role='TEACHER'))
    token=preview(e,'teachers',[tid]).json()['token'];assert confirm(e,'teachers',token).status_code==200
    with e['sessions']() as s:
        assert s.get(m.User,uid).is_active
        assert s.scalar(select(m.Membership).where(m.Membership.academic_year_id==e['other'],m.Membership.user_id==uid))

@pytest.mark.parametrize('role',['PRINCIPAL','TEACHER'])
def test_nonadmin_cannot_request_cascade(env,role):
    e=env;student=post(e,'/students',{'personal_number':'99','full_name':'طالب'})
    post(e,'/users',{'username':role.lower(),'display_name':'مستخدم','password':PASSWORD,'role':role,'employee_code':'T1' if role=='TEACHER' else None})
    token=e['client'].post('/api/v1/auth/login',json={'username':role.lower(),'password':PASSWORD}).json()['access_token']
    assert preview(e,'students',[student['id']],headers={'Authorization':'Bearer '+token}).status_code==403

def test_backup_failure_does_not_delete(school):
    e=school;token=preview(e,'students',[e['students'][0]['id']]).json()['token']
    file=e['tmp']/'file';file.write_text('not directory');e['client'].app.state.settings.backup_directory=str(file)
    assert confirm(e,'students',token).status_code==503
    assert len(listing(e,'students')['rows'])==3

def test_annual_cascade_checks_locked_dependent_packages(school):
    e=school;p=e['packages'][0]['id']
    with e['sessions'].begin() as s:s.get(m.Package,p).status='LOCKED'
    assert preview(e,'students',[e['students'][0]['id']]).status_code==409

def test_cascade_removes_fk_events_and_receipts(school):
    e=school
    with e['sessions'].begin() as s:
        member=s.scalar(select(m.Membership).where(m.Membership.academic_year_id==e['year'],m.Membership.user_id==e['admin']))
        event=m.Event(academic_year_id=e['year'],event_type='GROUP_DECLINE',section_id=e['section']['id'],subject_id=e['subject']['id'],payload={},deduplication_key='test-event')
        s.add(event);s.flush();s.add(m.EventReceipt(academic_year_id=e['year'],event_id=event.id,membership_id=member.id))
    data=preview(e,'subjects',[e['subject']['id']]).json()
    assert any(x['label']=='قراءات الإشعارات' and x['count']==1 for x in data['summary'])
    assert confirm(e,'subjects',data['token']).status_code==200
    with e['sessions']() as s:assert not s.execute(text('PRAGMA foreign_key_check')).all()

def test_round_two_is_included_and_other_subject_kept(school):
    e=school;p=e['packages'][0]['id']
    with e['sessions'].begin() as s:s.get(m.Package,p).has_second_round=True
    save_scores(e,p,[mark(e,p,0,'EXCUSED')]);save_scores(e,p,[mark(e,p,0,'PRESENT','90',round=2),mark(e,p,0,'PRESENT','70',subject_index=1)])
    with e['sessions']() as s:
        score=s.scalar(select(m.Score).where(m.Score.academic_year_id==e['year'],m.Score.round==1,m.Score.score_status=='EXCUSED'));sid=score.id
    data=preview(e,'scores',[sid],p).json();assert data['total_deleted']==2
    assert confirm(e,'scores',data['token'],p).status_code==200
    assert len(listing(e,'scores',p)['rows'])==1

def test_cascade_cannot_select_other_year(env):
    e=env
    other=e['client'].post('/api/v1/years/'+e['other']+'/students',headers=e['headers'],json={'personal_number':'444','full_name':'عام آخر'}).json()
    assert preview(e,'students',[other['id']]).status_code==404
