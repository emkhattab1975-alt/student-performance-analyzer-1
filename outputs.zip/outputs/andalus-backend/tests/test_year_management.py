import sqlite3
import pytest
from sqlalchemy import select, text
from app import models as m
from app.year_management import ORDER
from conftest import post, save_scores, mark, PASSWORD


def call(e,year,action,body=None,headers=None):
    return e['client'].post('/api/v1/years/'+year+'/'+action,json=body or {},headers=headers or e['headers'])

def ready(e):
    e['client'].app.state.settings.backup_directory=str(e['tmp']/'backups')
    assert call(e,e['other'],'set-current').status_code==200
    p=call(e,e['year'],'delete-year-preview');assert p.status_code==200,p.text
    return {'token':p.json()['token'],'code':'2026-2027','acknowledge':True}

def test_current_protected_and_explicit(env):
    e=env
    assert call(e,e['year'],'delete-year-preview').status_code==409
    assert call(e,e['year'],'delete-year-confirm',{'token':'invalid','code':'2026-2027','acknowledge':True}).status_code==409
    assert call(e,e['other'],'set-current').status_code==200
    assert call(e,e['other'],'delete-year-preview').status_code==409
    me=e['client'].get('/api/v1/me',headers=e['headers']).json()
    assert [y['academic_year_id'] for y in me['memberships'] if y['is_current']]==[e['other']]

@pytest.mark.parametrize('role',['PRINCIPAL','TEACHER'])
def test_roles_cannot_manage(env,role):
    e=env;post(e,'/users',{'username':role.lower(),'display_name':'حساب اختبار','password':PASSWORD,'role':role,'employee_code':'T1' if role=='TEACHER' else None})
    login=e['client'].post('/api/v1/auth/login',json={'username':role.lower(),'password':PASSWORD}).json()
    headers={'Authorization':'Bearer '+login['access_token']}
    for action in ['set-current','delete-year-preview','delete-year-confirm']:
        result=call(e,e['year'],action,{'token':'x','code':'2026-2027','acknowledge':True},headers)
        assert result.status_code==403,result.text
    assert e['client'].get(e['prefix']+'/years',headers=headers).status_code==403

def test_purge_populated_year_preserves_other_and_backup(school):
    e=school;pid=e['packages'][0]['id'];save_scores(e,pid,[mark(e,pid,0,'PRESENT','70')])
    body=ready(e)
    with e['sessions']() as s:
        before=len(list(s.scalars(select(m.Package).where(m.Package.academic_year_id==e['other']))))
    result=call(e,e['year'],'delete-year-confirm',body);assert result.status_code==200,result.text
    with e['sessions']() as s:
        for model in ORDER:assert not list(s.scalars(select(model).where(model.academic_year_id==e['year']))),model
        assert s.get(m.AcademicYear,e['year']).deleted_at
        assert s.get(m.User,e['admin'])
        assert list(s.scalars(select(m.AuditLog).where(m.AuditLog.academic_year_id==e['year'])))
        assert len(list(s.scalars(select(m.Package).where(m.Package.academic_year_id==e['other']))))==before
        assert not s.execute(text('PRAGMA foreign_key_check')).all()
    with sqlite3.connect(e['tmp']/'backups'/result.json()['backup']) as s:
        assert s.execute('SELECT count(*) FROM scores WHERE academic_year_id=?',(e['year'],)).fetchone()[0]==1
        assert s.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert e['client'].get(e['prefix']+'/catalog',headers=e['headers']).status_code==403
    assert call(e,e['year'],'delete-year-confirm',body).status_code==403
    me=e['client'].get('/api/v1/me',headers=e['headers']).json()
    assert all(y['academic_year_id']!=e['year'] for y in me['memberships'])

def test_confirmation_and_stale_preview(env):
    e=env;body=ready(e)
    assert call(e,e['year'],'delete-year-confirm',{**body,'code':'wrong'}).status_code==422
    assert call(e,e['year'],'delete-year-confirm',{**body,'acknowledge':False}).status_code==422
    assert call(e,e['year'],'delete-year-confirm',{**body,'token':'tampered'}).status_code==409
    post(e,'/students',{'personal_number':'123','full_name':'طالب جديد'})
    assert call(e,e['year'],'delete-year-confirm',body).status_code==409
    assert not list((e['tmp']/'backups').glob('*.db'))

def test_backup_failure_rolls_back(env):
    e=env;body=ready(e)
    path=e['tmp']/'not-folder';path.write_text('file');e['client'].app.state.settings.backup_directory=str(path)
    assert call(e,e['year'],'delete-year-confirm',body).status_code==503
    assert e['client'].get(e['prefix']+'/catalog',headers=e['headers']).status_code==200
    with e['sessions']() as s: assert s.get(m.AcademicYear,e['year']).deleted_at is None

def test_closed_year_can_be_removed(env):
    e=env
    with e['sessions'].begin() as s:s.get(m.AcademicYear,e['year']).status='CLOSED'
    body=ready(e)
    assert call(e,e['year'],'delete-year-confirm',body).status_code==200

def test_current_switch_invalidates_preview(env):
    e=env;body=ready(e)
    assert call(e,e['year'],'set-current').status_code==200
    assert call(e,e['year'],'delete-year-confirm',body).status_code==409

def edit_body(e,year=None,**changes):
    year=year or e['year']
    rows=e['client'].get(e['prefix']+'/years',headers=e['headers']).json()
    row=next(r for r in rows if r['id']==year)
    return {**{key:row[key] for key in ['code','starts_on','ends_on','revision']},**changes}

def patch_year(e,body,year=None,headers=None):
    return e['client'].patch('/api/v1/years/'+(year or e['year'])+'/year-details',json=body,headers=headers or e['headers'])

def test_edit_current_year_preserves_records_and_current(school):
    e=school;pid=e['packages'][0]['id'];save_scores(e,pid,[mark(e,pid,0,'PRESENT','81')])
    body=edit_body(e,code='عام معدل',starts_on='2026-08-15',ends_on='2027-08-01')
    response=patch_year(e,body);assert response.status_code==200,response.text
    with e['sessions']() as s:
        year=s.get(m.AcademicYear,e['year'])
        assert year.code=='عام معدل' and str(year.starts_on)=='2026-08-15' and str(year.ends_on)=='2027-08-01'
        assert s.get(m.SystemState,1).current_year_id==e['year']
        assert len(list(s.scalars(select(m.Student).where(m.Student.academic_year_id==e['year']))))==3
        assert len(list(s.scalars(select(m.Score).where(m.Score.academic_year_id==e['year']))))==1
        audit=s.scalar(select(m.AuditLog).where(m.AuditLog.academic_year_id==e['year'],m.AuditLog.action=='EDIT_YEAR'))
        assert audit.before_json['code']=='2026-2027' and audit.after_json['code']=='عام معدل'
        assert s.get(m.AcademicYear,e['other']).code=='2027-2028'
    assert call(e,e['year'],'delete-year-preview').status_code==409
    assert patch_year(e,body).status_code==409
    assert next(y for y in e['client'].get('/api/v1/me',headers=e['headers']).json()['memberships'] if y['academic_year_id']==e['year'])['code']=='عام معدل'

@pytest.mark.parametrize('changes',[{'code':' '},{'code':'x'*21},{'starts_on':'2027-07-01','ends_on':'2027-07-01'},{'starts_on':'2028-01-01'},{'ends_on':'invalid'}])
def test_invalid_year_edit(env,changes):
    assert patch_year(env,edit_body(env,**changes)).status_code==422

def test_duplicate_name_and_stale_delete(env):
    e=env;delete_body=ready(e)
    assert patch_year(e,edit_body(e,code='2027-2028')).status_code==409
    assert patch_year(e,edit_body(e,ends_on='2027-07-02')).status_code==200
    assert call(e,e['year'],'delete-year-confirm',delete_body).status_code==409

@pytest.mark.parametrize('role',['PRINCIPAL','TEACHER'])
def test_only_admin_edits_year(env,role):
    e=env;post(e,'/users',{'username':role.lower(),'display_name':'حساب اختبار','password':PASSWORD,'role':role,'employee_code':'T1' if role=='TEACHER' else None})
    token=e['client'].post('/api/v1/auth/login',json={'username':role.lower(),'password':PASSWORD}).json()['access_token']
    assert patch_year(e,edit_body(e,code='unauthorized'),headers={'Authorization':'Bearer '+token}).status_code==403

def test_closed_year_edit(env):
    e=env
    with e['sessions'].begin() as s:s.get(m.AcademicYear,e['other']).status='CLOSED'
    assert patch_year(e,edit_body(e,e['other'],code='عام سابق معدل'),year=e['other']).status_code==200
    with e['sessions']() as s:assert s.get(m.SystemState,1).current_year_id==e['year']
