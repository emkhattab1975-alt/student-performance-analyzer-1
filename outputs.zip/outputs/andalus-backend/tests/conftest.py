from datetime import date
from pathlib import Path

from alembic import command
from alembic.config import Config
from fastapi.testclient import TestClient
import pytest

from app.config import Settings
from app.db import build_engine, session_factory
from app.main import create_app
from app.models import User
from app.repositories import AuthRepository
from app.security import hash_password
from app.services import seed_year

ROOT = Path(__file__).resolve().parents[1]
PASSWORD = "Tests-Only-Password-123!"


@pytest.fixture
def env(tmp_path, monkeypatch):
    url = f"sqlite:///{(tmp_path / 'test.db').as_posix()}"
    monkeypatch.setenv("ANDALUS_DATABASE_URL", url)
    cfg = Config(str(ROOT / "alembic.ini"))
    command.upgrade(cfg, "head")
    engine = build_engine(url)
    sessions = session_factory(engine)
    with sessions.begin() as session:
        auth = AuthRepository(session)
        user = auth.add(User(username="admin", display_name="مدير النظام", password_hash=hash_password(PASSWORD)))
        year = seed_year(session, "2026-2027", date(2026, 9, 1), date(2027, 7, 1), user.id)
        other = seed_year(session, "2027-2028", date(2027, 9, 1), date(2028, 7, 1), user.id)
        year_id, other_id, admin_id = year.id, other.id, user.id
    app = create_app(Settings(database_url=url, jwt_secret="test-secret-never-use-in-production-12345"), engine)
    with TestClient(app) as client:
        response = client.post("/api/v1/auth/login", json={"username": "admin", "password": PASSWORD})
        assert response.status_code == 200, response.text
        headers = {"Authorization": "Bearer " + response.json()["access_token"]}
        prefix = f"/api/v1/years/{year_id}"
        yield {"client": client, "engine": engine, "sessions": sessions, "year": year_id, "other": other_id,
               "admin": admin_id, "headers": headers, "prefix": prefix, "tmp": tmp_path}
    engine.dispose()


def post(env, path, data, method="post", headers=None):
    response = getattr(env["client"], method)(env["prefix"] + path, json=data, headers=headers or env["headers"])
    assert response.status_code in (200, 201), response.text
    return response.json()


@pytest.fixture
def school(env):
    catalog = env["client"].get(env["prefix"] + "/catalog", headers=env["headers"]).json()
    packages = sorted(catalog["packages"], key=lambda p: p["sequence_no"])
    stage = next(s for s in catalog["stages"] if s["grade"] == 10)
    section = post(env, "/sections", {"stage_id": stage["id"], "code": "A", "name_ar": "أ"})
    section2 = post(env, "/sections", {"stage_id": stage["id"], "code": "B", "name_ar": "ب"})
    subject = post(env, "/subjects", {"code": "MATH", "name_ar": "الرياضيات"})
    computing = post(env, "/subjects", {"code": "COMPUTING", "name_ar": "الحوسبة"})
    curriculum = post(env, "/stage-subjects", {"stage_id": stage["id"], "subject_id": subject["id"]})
    curriculum2 = post(env, "/stage-subjects", {"stage_id": stage["id"], "subject_id": computing["id"]})
    students = [post(env, "/students", {"personal_number": f"000{i}", "full_name": f"طالب {i}"}) for i in range(1, 4)]
    maxima, enrollments = {}, {}
    for package in packages[:2]:
        pid = package["id"]
        maxima[pid] = [post(env, f"/packages/{pid}/maxima", {"stage_subject_id": cur["id"], "max_score": "100"}, "put") for cur in (curriculum, curriculum2)]
        enrollments[pid] = [post(env, f"/packages/{pid}/enrollments", {"student_id": student["id"], "section_id": section["id"]}) for student in students]
    env.update(packages=packages, stage=stage, section=section, section2=section2, subject=subject,
               computing=computing, curriculum=curriculum, curriculum2=curriculum2, students=students, maxima=maxima, enrollments=enrollments)
    return env


def revision(env, package_id):
    catalog = env["client"].get(env["prefix"] + "/catalog", headers=env["headers"]).json()
    return next(p["data_revision"] for p in catalog["packages"] if p["id"] == package_id)


def save_scores(env, package_id, rows):
    return post(env, f"/packages/{package_id}/scores", {"expected_revision": revision(env, package_id), "scores": rows}, "put")


def mark(env, package_id, student_index, status, score=None, subject_index=0, round=1):
    return {"enrollment_id": env["enrollments"][package_id][student_index]["id"],
            "subject_maximum_id": env["maxima"][package_id][subject_index]["id"], "round": round,
            "score_status": status, "score": score}
