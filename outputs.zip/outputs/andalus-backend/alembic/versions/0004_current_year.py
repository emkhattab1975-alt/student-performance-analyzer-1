"""Explicit current year and deleted-year tombstones retaining append-only audit."""
from alembic import op
import sqlalchemy as sa
from datetime import datetime, timezone, timedelta
revision='0004'
down_revision='0003'
branch_labels=None
depends_on=None

def upgrade():
    op.add_column('academic_years',sa.Column('deleted_at',sa.DateTime(),nullable=True))
    op.create_table('system_state',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('current_year_id',sa.String(36),sa.ForeignKey('academic_years.id',ondelete='RESTRICT')),sa.CheckConstraint('id = 1',name='singleton'))
    op.create_index('ix_system_state_fk_current_year_id','system_state',['current_year_id'])
    today=datetime.now(timezone(timedelta(hours=3))).date().isoformat()
    # A scalar subquery works in offline migrations too and returns NULL on a fresh install.
    op.execute(sa.text(f"""INSERT INTO system_state (id,current_year_id) VALUES (1,
        (SELECT id FROM academic_years ORDER BY
         CASE WHEN starts_on <= '{today}' AND ends_on >= '{today}' THEN 0
              WHEN starts_on <= '{today}' THEN 1 ELSE 2 END,
         CASE WHEN starts_on <= '{today}' THEN starts_on END DESC,
         starts_on ASC, id ASC LIMIT 1))"""))


def downgrade():
    op.drop_table('system_state')
    op.drop_column('academic_years','deleted_at')
