"""Append-only audit history and the deferred PostgreSQL import pointer."""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade():
    dialect = op.get_context().dialect.name
    if dialect == "sqlite":
        op.execute("CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_logs BEGIN SELECT RAISE(ABORT, 'audit logs are append-only'); END")
        op.execute("CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_logs BEGIN SELECT RAISE(ABORT, 'audit logs are append-only'); END")
    elif dialect == "postgresql":
        # use_alter on the model avoids a circular CREATE TABLE dependency.
        op.create_foreign_key("fk_scope_active_batch", "import_scopes", "import_batches",
                              ["academic_year_id", "id", "active_batch_id"], ["academic_year_id", "scope_id", "id"])
        op.execute("""CREATE FUNCTION andalus_audit_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
            BEGIN RAISE EXCEPTION 'audit logs are append-only'; END; $$""")
        op.execute("CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION andalus_audit_immutable()")


def downgrade():
    dialect = op.get_context().dialect.name
    if dialect == "sqlite":
        op.execute("DROP TRIGGER audit_no_update")
        op.execute("DROP TRIGGER audit_no_delete")
    elif dialect == "postgresql":
        op.execute("DROP TRIGGER audit_immutable ON audit_logs")
        op.execute("DROP FUNCTION andalus_audit_immutable()")
        op.drop_constraint("fk_scope_active_batch", "import_scopes", type_="foreignkey")
