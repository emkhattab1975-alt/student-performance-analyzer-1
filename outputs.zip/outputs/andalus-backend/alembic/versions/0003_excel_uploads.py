"""Persist Excel previews and source versions without changing existing records."""
from alembic import op
import sqlalchemy as sa
revision = '0003'
down_revision = '0002'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('excel_uploads',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('academic_year_id', sa.String(36), sa.ForeignKey('academic_years.id', ondelete='RESTRICT'), nullable=False),
        sa.Column('uploaded_by', sa.String(36), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('package_id', sa.String(36)),
        sa.Column('kind', sa.String(20), nullable=False),
        sa.Column('filename', sa.String(200), nullable=False),
        sa.Column('source_sha256', sa.String(64), nullable=False),
        sa.Column('source_base64', sa.Text(), nullable=False),
        sa.Column('payload', sa.JSON(), nullable=False),
        sa.Column('preview', sa.JSON(), nullable=False),
        sa.Column('fingerprint', sa.String(64), nullable=False),
        sa.Column('status', sa.String(12), nullable=False),
        sa.Column('applied_at', sa.DateTime()),
        sa.UniqueConstraint('academic_year_id', 'id'),
        sa.ForeignKeyConstraint(['academic_year_id', 'package_id'], ['packages.academic_year_id', 'packages.id'], ondelete='RESTRICT'),
        sa.CheckConstraint("status IN ('READY','INVALID','APPLIED')", name='status'))
    op.create_index('ix_excel_uploads_academic_year_id', 'excel_uploads', ['academic_year_id'])
    op.create_index('ix_excel_uploads_fk_uploaded_by', 'excel_uploads', ['uploaded_by'])
    op.create_index('ix_excel_uploads_fk_academic_year_id_package_id', 'excel_uploads', ['academic_year_id', 'package_id'])

def downgrade():
    op.drop_table('excel_uploads')
