import os
from dotenv import load_dotenv
from alembic import context
from app.db import build_engine
from app.models import Base

config = context.config
load_dotenv(override=False, encoding="utf-8-sig")
url = os.environ.get("ANDALUS_DATABASE_URL", config.get_main_option("sqlalchemy.url"))

if context.is_offline_mode():
    context.configure(url=url, target_metadata=Base.metadata, literal_binds=True, compare_type=True)
    with context.begin_transaction():
        context.run_migrations()
else:
    engine = build_engine(url)
    with engine.connect() as connection:
        context.configure(connection=connection, target_metadata=Base.metadata, compare_type=True, render_as_batch=engine.dialect.name == "sqlite")
        with context.begin_transaction():
            context.run_migrations()
    engine.dispose()
