import { NextRequest, NextResponse } from 'next/server';
import { backendFetch, jsonError, validOrigin } from '@/lib/session';
export async function GET() {
  if (!process.env.SETUP_TOKEN) return NextResponse.json({ needs_setup: false });
  try {
    const response = await backendFetch('setup', { headers: { 'X-Setup-Token': process.env.SETUP_TOKEN } });
    if (!response.ok) return NextResponse.json({ needs_setup: false });
    return NextResponse.json(await response.json(), { headers: { 'Cache-Control': 'no-store' } });
  } catch { return jsonError('تعذر الاتصال بالخادم', 503); }
}
export async function POST(request: NextRequest) {
  if (!validOrigin(request)) return jsonError('مصدر الطلب غير مسموح', 403);
  if (!process.env.SETUP_TOKEN) return jsonError('التهيئة الأولية غير متاحة', 403);
  try {
    const body = await request.text();
    if (body.length > 8000) return jsonError('حجم الطلب أكبر من المسموح', 413);
    const response = await backendFetch('setup', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Setup-Token': process.env.SETUP_TOKEN }, body });
    return new NextResponse(await response.text(), { status: response.status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
  } catch { return jsonError('تعذر الاتصال بالخادم', 503); }
}
