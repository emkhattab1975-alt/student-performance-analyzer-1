import { NextRequest } from 'next/server';
import { jsonError, proxy, validOrigin } from '@/lib/session';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

async function handle(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  if (!['GET', 'HEAD'].includes(request.method) && !validOrigin(request)) return jsonError('مصدر الطلب غير مسموح', 403);
  const { path } = await context.params;
  if (!path.length || !['me', 'years'].includes(path[0]) || path.some(segment => !/^[a-zA-Z0-9_-]+$/.test(segment))) return jsonError('مسار غير مسموح', 404);
  try { return await proxy(request, path.join('/') + request.nextUrl.search); }
  catch { return jsonError('تعذر الاتصال بخدمة النتائج. حاول مرة أخرى.', 503); }
}
export { handle as GET, handle as POST, handle as PUT, handle as PATCH };
