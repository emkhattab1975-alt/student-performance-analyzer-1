import { NextRequest, NextResponse } from 'next/server';
import { backendFetch, clearTokens, jsonError, refreshCookie, validOrigin } from '@/lib/session';
export async function POST(request: NextRequest) {
  if (!validOrigin(request)) return jsonError('مصدر الطلب غير مسموح', 403);
  const token = request.cookies.get(refreshCookie)?.value;
  try {
    if (token) await backendFetch('auth/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: token }) });
  } catch { /* Local credentials must still be cleared when the API is unavailable. */ }
  const response = NextResponse.json({ ok: true });
  clearTokens(response);
  return response;
}
