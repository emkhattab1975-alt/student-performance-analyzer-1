import { NextRequest, NextResponse } from 'next/server';
import { backendFetch, jsonError, setTokens, validOrigin } from '@/lib/session';
export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  if (!validOrigin(request)) return jsonError('مصدر الطلب غير مسموح', 403);
  try {
    const input = await request.json();
    if (typeof input.username !== 'string' || typeof input.password !== 'string' || input.password.length > 1024) return jsonError('أدخل اسم المستخدم وكلمة المرور');
    const upstream = await backendFetch('auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: input.username, password: input.password }) });
    if (!upstream.ok) return new NextResponse(await upstream.text(), { status: upstream.status, headers: { 'Content-Type': 'application/json' } });
    const response = NextResponse.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } });
    setTokens(response, await upstream.json());
    return response;
  } catch { return jsonError('تعذر الاتصال بالخادم. تحقق من تشغيل خدمة النتائج.', 503); }
}
