import type { Metadata } from 'next';
import '@fontsource/cairo/400.css';
import '@fontsource/cairo/500.css';
import '@fontsource/cairo/600.css';
import '@fontsource/cairo/700.css';
import './globals.css';
import { AppearanceControls } from '@/components/appearance';

export const metadata: Metadata = { title: 'الأندلس | نتائج الطلاب', description: 'منصة إدارة وتحليل نتائج الطلاب — مجمع الأندلس التعليمي' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="ar" dir="rtl" data-appearance="school"><body><AppearanceControls/>{children}</body></html>;
}
