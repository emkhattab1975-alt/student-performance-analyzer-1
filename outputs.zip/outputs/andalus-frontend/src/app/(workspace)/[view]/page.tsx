'use client';
import { useParams } from 'next/navigation';
import { useWorkspace } from '@/components/shell';
import Dashboard from '@/features/dashboard';
import Reports from '@/features/reports';
import Comparisons from '@/features/comparisons';
import Teachers from '@/features/teachers';
import Notifications from '@/features/notifications';
import Records from '@/features/records';
import Imports from '@/features/imports';
import Management, { Years } from '@/features/management';
import { AuditPage, SettingsPage, UsersPage } from '@/features/admin';
import { Empty } from '@/components/ui';
export default function Page() {
  const { view } = useParams<{view:string}>();
  const w = useWorkspace();
  const admin = w.context.role === 'SYSTEM_ADMIN', manager = w.context.role !== 'TEACHER';
  switch(view) {
    case 'dashboard': return <Dashboard/>;
    case 'reports': return <Reports/>;
    case 'comparisons': return <Comparisons/>;
    case 'progress': return manager ? <Comparisons progress/> : null;
    case 'teachers': return <Teachers/>;
    case 'notifications': return <Notifications/>;
    case 'manage': return manager ? <Management/> : null;
    case 'years': return admin ? <Years/> : null;
    case 'imports': return manager ? <Imports/> : null;
    case 'records': return manager ? <Records/> : null;
    case 'users': return admin ? <UsersPage/> : null;
    case 'settings': return admin ? <SettingsPage/> : null;
    case 'audit': return admin ? <AuditPage/> : null;
    default: return <Empty title="الصفحة غير موجودة" text="اختر إحدى صفحات المنصة من القائمة الجانبية."/>;
  }
}

