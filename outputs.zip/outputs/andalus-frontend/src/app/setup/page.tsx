'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { BookOpen, ArrowLeft } from 'lucide-react';
export default function Setup() {
  const [available, setAvailable] = useState<boolean | null>(null), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => { fetch('/api/setup').then(r => r.json()).then(data => setAvailable(Boolean(data.needs_setup))).catch(() => setError('تعذر الاتصال بالخادم')); }, []);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError('');
    const f = new FormData(event.currentTarget);
    if (!/^[a-zA-Z0-9_.@-]{3,100}$/.test(String(f.get('username') || ''))) { setError('اسم المستخدم يجب أن يكون بالإنجليزية دون مسافات، مثل Mohammad.ALKHATTAB'); setBusy(false); return; }
    if (String(f.get('ends_on')) <= String(f.get('starts_on'))) { setError('تاريخ نهاية العام يجب أن يكون بعد تاريخ بدايته'); setBusy(false); return; }
    if (f.get('password') !== f.get('confirm')) { setError('كلمتا المرور غير متطابقتين'); setBusy(false); return; }
    try {
      const body = Object.fromEntries(f); delete body.confirm;
      const response = await fetch('/api/setup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await response.json();
      if (!response.ok) {
        const labels: Record<string, string> = { username: 'اسم المستخدم: استخدم ٣ إلى ١٠٠ حرف إنجليزي أو رقم دون مسافات', display_name: 'اسم مدير النظام: أدخل اسماً من ١ إلى ٢٠٠ محرف', password: 'كلمة المرور: يجب أن تتكون من ١٢ إلى ٢٥٦ محرفاً', code: 'اسم العام الدراسي: مطلوب وبحد أقصى ٢٠ محرفاً', starts_on: 'تاريخ بداية العام غير صالح', ends_on: 'تاريخ نهاية العام غير صالح' };
        const detail = Array.isArray(data.detail) ? [...new Set(data.detail.map((issue: { loc?: string[] }) => labels[issue.loc?.at(-1) || ''] || 'تحقق من أن نهاية العام تلي بدايته'))].join(' — ') : data.detail;
        throw new Error(typeof detail === 'string' ? detail : 'تعذر إنشاء الحساب. حاول مرة أخرى');
      }
      window.location.assign('/login?created=1');
    } catch (err) { setError(err instanceof Error ? err.message : 'تعذر إتمام التهيئة'); setBusy(false); }
  }
  return <main className="boot" style={{ marginTop: '6vh', textAlign: 'right' }}><div className="panel panel-pad"><div className="brand" style={{ marginBottom: 25 }}><span className="brand-icon"><BookOpen size={25}/></span><div><strong>الأندلس</strong><small>تهيئة مساحة المدرسة</small></div></div>
    <h1>البداية بحسابك الحقيقي</h1><p className="muted" style={{ marginBlock: 12 }}>أنشئ حساب مدير النظام والعام الدراسي. لن تُضاف أسماء طلاب أو نتائج تجريبية.</p>
    {available === null ? <p>جارٍ التحقق من حالة النظام…</p> : !available ? <div className="notice">التهيئة غير متاحة أو اكتملت مسبقاً. <Link href="/login">انتقل إلى تسجيل الدخول</Link></div> : <form onSubmit={submit} className="form-grid" style={{ marginTop: 25 }}>
      <label className="field"><span>اسم مدير النظام</span><input name="display_name" required maxLength={200}/></label>
      <label className="field"><span>اسم المستخدم (بالإنجليزية، دون مسافات)</span><input name="username" required minLength={3} maxLength={100} pattern={String.raw`[a-zA-Z0-9_.@\-]+`} title="حروف إنجليزية وأرقام أو . _ @ - دون مسافات" aria-describedby="username-help" autoComplete="username" dir="ltr"/><small id="username-help">مثال: Mohammad.ALKHATTAB — استخدم النقطة بدلاً من المسافة.</small></label>
      <label className="field"><span>كلمة المرور (١٢ محرفاً على الأقل)</span><input name="password" type="password" required minLength={12} maxLength={256} autoComplete="new-password" dir="ltr"/></label>
      <label className="field"><span>تأكيد كلمة المرور</span><input name="confirm" type="password" required minLength={12} maxLength={256} autoComplete="new-password" dir="ltr"/></label>
      <label className="field full"><span>اسم العام الدراسي</span><input name="code" placeholder="مثال: 2026-2027" required maxLength={20}/></label>
      <label className="field"><span>بداية العام</span><input name="starts_on" type="date" required/></label><label className="field"><span>نهاية العام</span><input name="ends_on" type="date" required/></label>
      {error && <div className="error-box full" role="alert">{error}</div>}<div className="full"><button className="button primary" disabled={busy}>{busy ? 'جارٍ إنشاء مساحة المدرسة…' : 'إنشاء الحساب والعام الدراسي'}<ArrowLeft size={17}/></button></div>
    </form>}
  </div></main>;
}
