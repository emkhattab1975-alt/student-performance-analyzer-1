'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { SchoolLogo } from '@/components/appearance';
import { ArrowLeft, BookOpen, Eye, EyeOff, LockKeyhole, ShieldCheck } from 'lucide-react';

export default function Login() {
  const [show, setShow] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [needsSetup, setNeedsSetup] = useState(false);
  useEffect(() => { fetch('/api/setup').then(r => r.json()).then(data => setNeedsSetup(Boolean(data.needs_setup))).catch(() => {}); }, []);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setBusy(true);
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: form.get('username'), password: form.get('password') }) });
      const data = await response.json();
      if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'تحقق من بيانات الدخول');
      window.location.assign('/dashboard');
    } catch (err) { setError(err instanceof Error ? err.message : 'تعذر الاتصال بالخادم'); setBusy(false); }
  }
  return <main className="login-screen">
    <section className="login-story" aria-label="منصة الأندلس">
      <div className="brand light"><span className="brand-icon"><BookOpen size={27}/></span><div><strong>الأندلس</strong><small>منصة النتائج والتحليل</small></div></div>
      <div className="story-body"><span className="eyebrow light-text">من المعرفة إلى الأثر</span><h1>نقرأ النتائج.<br/>لنفتح آفاقاً<br/><em>أوسع لطلابنا.</em></h1><p>مساحة واحدة لمتابعة التحصيل، وفهم التقدم، واتخاذ قرارات تعليمية تستند إلى البيانات.</p></div>
      <div className="story-bottom"><span>مجمع الأندلس التعليمي</span><span>التعليم يصنع الفرق</span></div>
      <div className="story-decoration" aria-hidden="true"><div/><div/><div/></div>
    </section>
    <section className="login-form-area"><div className="login-form-wrap"><SchoolLogo/>
      <div className="login-symbol"><LockKeyhole size={25}/></div><span className="eyebrow">أهلاً بعودتك</span><h2>تسجيل الدخول</h2><p className="muted">أدخل بيانات حسابك للوصول إلى مساحة عملك.</p>
      <form onSubmit={submit} className="form-stack">
        <label className="field"><span>اسم المستخدم</span><input name="username" autoComplete="username" dir="ltr" required placeholder="اسم المستخدم" maxLength={100}/></label>
        <label className="field"><span>كلمة المرور</span><div className="password-field"><input name="password" type={show ? 'text' : 'password'} autoComplete="current-password" required dir="ltr" placeholder="كلمة المرور" maxLength={1024}/><button type="button" className="icon-button" onClick={() => setShow(!show)} aria-label={show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}>{show ? <EyeOff size={18}/> : <Eye size={18}/>}</button></div></label>
        {error && <div className="error-box" role="alert">{error}</div>}
        <button className="button primary login-submit" disabled={busy}>{busy ? 'جارٍ تسجيل الدخول…' : 'دخول إلى المنصة'}<ArrowLeft size={18}/></button>
      </form>
      <p className="login-help">تحتاج إلى حساب أو استعادة كلمة المرور؟<br/>تواصل مع مدير النظام في المجمع.</p>
      {needsSetup && <Link href="/setup" className="button" style={{ width: '100%', marginTop: 18 }}>الاستخدام الأول؟ هيّئ حساب المدرسة<ArrowLeft size={15}/></Link>}
      <div className="security-note"><ShieldCheck size={17}/><span>وصول آمن بحسب صلاحيات حسابك</span></div>
    </div><p className="login-footer">مجمع الأندلس التعليمي · منصة نتائج الطلاب</p></section>
  </main>;
}
