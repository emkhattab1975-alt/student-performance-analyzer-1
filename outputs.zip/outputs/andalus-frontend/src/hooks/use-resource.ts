'use client';
import { useCallback, useEffect, useState } from 'react';
import { api } from '@/lib/api';

export function useResource<T>(path: string | null, interval = 0) {
  const [state, setState] = useState<{ path: string | null; data: T | null; error: string; loading: boolean }>({ path, data: null, error: '', loading: Boolean(path) });
  const [version, setVersion] = useState(0);
  const reload = useCallback(() => setVersion(n => n + 1), []);
  useEffect(() => {
    if (!path) return;
    const controller = new AbortController();
    let running = false;
    const load = async () => {
      if (running) return;
      running = true;
      try {
        const data = await api<T>(path, { signal: controller.signal });
        if (!controller.signal.aborted) setState({ path, data, error: '', loading: false });
      } catch (error) {
        if (!controller.signal.aborted) setState({ path, data: null, error: error instanceof Error ? error.message : 'تعذر تحميل البيانات', loading: false });
      } finally { running = false; }
    };
    setState({ path, data: null, error: '', loading: true });
    void load();
    const timer = interval ? window.setInterval(load, interval) : undefined;
    return () => { controller.abort(); if (timer) window.clearInterval(timer); };
  }, [path, version, interval]);
  // Never render data from a previously selected year/package, even for one render.
  const current = state.path === path ? state : { data: null, error: '', loading: Boolean(path) };
  return { ...current, reload };
}
