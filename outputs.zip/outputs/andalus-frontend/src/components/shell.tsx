'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ArrowUpLeft, BarChart3, Bell, BookOpen, ChevronDown, CircleHelp, ClipboardList, FileChartColumnIncreasing, GraduationCap, LayoutDashboard, LogOut, Menu, Settings2, ShieldCheck, TrendingUp, Users, X } from 'lucide-react';
import { useResource } from '@/hooks/use-resource';
import { roleName } from '@/lib/format';
import type { Context, Me } from '@/lib/types';
import { Failure, Loading } from './ui';
import { SchoolLogo } from './appearance';

type Workspace = { me: Me; context: Context; year: string; packageId: string; setPackageId: (id: string) => void;
  stage: string; setStage: (id: string) => void; section: string; setSection: (id: string) => void; coreOnly: boolean;
  setCoreOnly: (value: boolean) => void; refreshContext: () => void; base: string };
const WorkspaceContext = createContext<Workspace | null>(null);
export function useWorkspace() { const value = useContext(WorkspaceContext); if (!value) throw new Error('Missing workspace'); return value; }
const nav = [
  { href: '/dashboard', label: 'لوحة التحكم', icon: LayoutDashboard, group: 'المتابعة والتحليل' },
  { href: '/reports', label: 'التقارير والكشوف', icon: FileChartColumnIncreasing },
  { href: '/comparisons', label: 'مقارنة الباقات', icon: BarChart3 },
  { href: '/progress', label: 'تقدم الطلاب', icon: TrendingUp, restricted: 'management' },
  { href: '/teachers', label: 'تحصيل المعلمين', icon: GraduationCap },
  { href: '/notifications', label: 'الإشعارات', icon: Bell },
  { href: '/records', label: 'البيانات والدرجات', icon: ClipboardList, group: 'إدارة المنصة', restricted: 'management' },
  { href: '/imports', label: 'استيراد Excel', icon: ClipboardList, restricted: 'management' },
  { href: '/manage', label: 'تعديل وحذف السجلات', icon: ClipboardList, restricted: 'management' },
  { href: '/years', label: 'الأعوام الدراسية', icon: BookOpen, restricted: 'admin' },
  { href: '/users', label: 'إدارة المستخدمين', icon: Users, restricted: 'admin' },
  { href: '/settings', label: 'إعدادات النظام', icon: Settings2, restricted: 'admin' },
  { href: '/audit', label: 'سجل التدقيق', icon: ShieldCheck, restricted: 'admin' },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const user = useResource<Me>('me');
  const [year, setYear] = useState(''), [selectedPackage, selectPackage] = useState('');
  const [stage, setStage] = useState(''), [section, setSection] = useState(''), [coreOnly, setCoreOnly] = useState(false), [mobile, setMobile] = useState(false);
  const selectedYear = year || user.data?.memberships.find(m => m.is_current)?.academic_year_id || user.data?.memberships[0]?.academic_year_id || '';
  const resource = useResource<Context>(selectedYear ? `years/${selectedYear}/context` : null);
  const ctx = resource.data;
  const packageId = ctx?.packages.some(p => p.id === selectedPackage) ? selectedPackage : ctx?.packages[0]?.id || '';
  useEffect(() => { setMobile(false); }, [pathname]);
  useEffect(() => { const requested = new URLSearchParams(window.location.search).get('year'); if (requested && user.data?.memberships.some(m => m.academic_year_id === requested)) setYear(requested); }, [user.data]);
  if (user.error) return <main className="boot"><Failure message={user.error} retry={user.reload}/><Link href="/login" className="button">تسجيل الدخول</Link></main>;
  if (!user.data) return <main className="boot"><Loading/></main>;
  if (!user.data.memberships.length) return <main className="boot"><h1>لا توجد عضوية دراسية فعالة</h1><p>تواصل مع مدير النظام لإسناد حسابك إلى عام دراسي.</p><button className="button" onClick={logout}>تسجيل الخروج</button></main>;
  const role = ctx?.role || user.data.memberships.find(m => m.academic_year_id === selectedYear)!.role;
  const visibleNav = nav.filter(item => item.restricted !== 'admin' || role === 'SYSTEM_ADMIN').filter(item => item.restricted !== 'management' || role !== 'TEACHER');
  const current = nav.find(item => item.href === pathname);
  const permitted = !current?.restricted || current.restricted === 'admin' && role === 'SYSTEM_ADMIN' || current.restricted === 'management' && role !== 'TEACHER';
  async function logout() { await fetch('/api/auth/logout', { method: 'POST' }); window.location.assign('/login'); }

  return <div className="app-shell">
    <a href="#main-content" className="skip-link">انتقل إلى المحتوى</a>
    {mobile && <button className="sidebar-backdrop" onClick={() => setMobile(false)} aria-label="إغلاق القائمة"/>}
    <aside className={`sidebar no-print ${mobile ? 'open' : ''}`}>
      <Link href="/dashboard" className="brand"><SchoolLogo/><span className="legacy-brand"><span className="brand-icon"><BookOpen size={25}/></span><div><strong>الأندلس</strong><small>منصة النتائج والتحليل</small></div></span></Link>
      <button className="mobile-close icon-button" onClick={() => setMobile(false)} aria-label="إغلاق القائمة"><X size={21}/></button>
      <div className="school-label">{ctx?.school_name || 'مجمع الأندلس التعليمي'}</div>
      <nav aria-label="التنقل الرئيسي">{visibleNav.map((item, i) => <div key={item.href}>{(item.group || i === 0) && <p className="nav-group">{item.group}</p>}<Link href={item.href} className={`nav-item ${pathname === item.href ? 'active' : ''}`} aria-current={pathname === item.href ? 'page' : undefined}><item.icon size={19}/><span>{item.label}</span>{pathname === item.href && <span className="active-dot"/>}</Link></div>)}</nav>
      <div className="sidebar-bottom"><div className="scope-note"><ShieldCheck size={18}/><span>مساحة عمل {roleName[role]}<small>البيانات وفق صلاحيات حسابك</small></span></div><button onClick={logout} className="logout"><LogOut size={17}/>تسجيل الخروج</button></div>
    </aside>
    <div className="main-column">
      <header className="topbar no-print"><div className="topbar-location"><button className="icon-button mobile-menu" onClick={() => setMobile(true)} aria-label="فتح القائمة"><Menu size={22}/></button><span className="muted">الرئيسية</span><span className="breadcrumb-separator">/</span><strong>{current?.label || 'مساحة العمل'}</strong></div>
        <div className="topbar-tools"><label className="year-select"><span className="sr-only">العام الدراسي</span><select value={selectedYear} onChange={event => { setYear(event.target.value); selectPackage(''); setStage(''); setSection(''); }}>{user.data.memberships.map(m => <option value={m.academic_year_id} key={m.academic_year_id}>{m.code}{m.is_current ? " · العام الحالي" : ""}</option>)}</select><ChevronDown size={14}/></label><Link href="/notifications" className="icon-button header-bell" aria-label="الإشعارات"><Bell size={20}/></Link><div className="account"><span className="avatar">{user.data.display_name.slice(0, 1)}</span><div><strong>{user.data.display_name}</strong><small>{roleName[role]}</small></div></div></div>
      </header>
      <main id="main-content" className="workspace-main">
        {resource.error ? <Failure message={resource.error} retry={resource.reload}/> : !ctx ? <Loading/> : !permitted ? <div className="panel"><div className="empty"><ShieldCheck size={40}/><h1>هذه الصفحة خارج صلاحيات حسابك</h1><Link href="/dashboard" className="button primary">العودة إلى لوحة التحكم</Link></div></div> :
          <WorkspaceContext.Provider value={{ me: user.data, context: ctx, year: selectedYear, packageId, setPackageId: id => { selectPackage(id); setSection(''); }, stage, setStage: id => { setStage(id); setSection(''); }, section, setSection, coreOnly, setCoreOnly, refreshContext: resource.reload, base: `years/${selectedYear}` }}>
            <div className="print-header"><SchoolLogo/><strong>{ctx.school_name}</strong><span>{current?.label} · العام الدراسي {ctx.year_code}</span>{ctx.header_text && <p>{ctx.header_text}</p>}</div>
            {children}
            <footer className="workspace-footer"><span>{ctx.school_name}</span><span>نتائج دقيقة. رؤية أوضح.</span></footer>
            {ctx.footer_text && <div className="print-footer">{ctx.footer_text}</div>}
          </WorkspaceContext.Provider>}
      </main>
    </div>
  </div>;
}

export function Filters({ core = true, sections = true }: { core?: boolean; sections?: boolean }) {
  const w = useWorkspace();
  const allowedSections = w.context.role === 'TEACHER' ? new Set(w.context.assignments.filter(a => a.package_id === w.packageId).map(a => a.section_id)) : null;
  const available = w.context.sections.filter(s => (!w.stage || s.stage_id === w.stage) && (!allowedSections || allowedSections.has(s.id)));
  return <div className="filter-bar no-print">
    <label className="field"><span>الباقة الدراسية</span><select value={w.packageId} onChange={e => w.setPackageId(e.target.value)}>{w.context.packages.map(p => <option value={p.id} key={p.id}>{p.name_ar}</option>)}</select></label>
    <label className="field"><span>الصف والمسار</span><select value={w.stage} onChange={e => w.setStage(e.target.value)}><option value="">جميع الصفوف</option>{w.context.stages.map(s => <option key={s.id} value={s.id}>{s.name_ar}</option>)}</select></label>
    {sections && <label className="field"><span>الشعبة</span><select value={w.section} onChange={e => w.setSection(e.target.value)}><option value="">جميع الشعب</option>{available.map(s => <option key={s.id} value={s.id}>{w.context.stages.find(g => g.id === s.stage_id)?.name_ar} / {s.name_ar}</option>)}</select></label>}
    {core && <label className="toggle"><input type="checkbox" checked={w.coreOnly} onChange={e => w.setCoreOnly(e.target.checked)}/><span>المواد الأساسية فقط</span></label>}
  </div>;
}

