'use client';
import { Inbox, LoaderCircle, RefreshCw, TriangleAlert, Download, Printer } from 'lucide-react';
import { downloadCsv, pct } from '@/lib/format';
import type { Mark } from '@/lib/types';

export function Empty({ title = 'لا توجد بيانات بعد', text = 'ستظهر النتائج هنا بعد إضافة البيانات إلى الباقة المحددة.', children }: { title?: string; text?: string; children?: React.ReactNode }) {
  return <div className="empty"><span className="empty-icon"><Inbox size={28}/></span><h3>{title}</h3><p>{text}</p>{children}</div>;
}
export function Loading() { return <div className="loading" role="status"><LoaderCircle className="spin" size={23}/><span>جارٍ تحميل البيانات…</span></div>; }
export function Failure({ message, retry }: { message: string; retry?: () => void }) {
  return <div className="error-box" role="alert"><TriangleAlert size={20}/><span>{message}</span>{retry && <button className="button small" onClick={retry}><RefreshCw size={14}/>إعادة المحاولة</button>}</div>;
}
export function Panel({ title, subtitle, action, children, className = '' }: { title?: string; subtitle?: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return <section className={`panel ${className}`}>{(title || action) && <div className="panel-heading"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>{action}</div>}{children}</section>;
}
export function PageTitle({ title, description, actions }: { title: string; description: string; actions?: React.ReactNode }) {
  return <div className="page-title"><div><span className="eyebrow">منصة النتائج والتحليل</span><h1>{title}</h1><p>{description}</p></div>{actions && <div className="actions no-print">{actions}</div>}</div>;
}
export function ExportActions({ filename, rows }: { filename: string; rows: (string | number | null)[][] }) {
  return <><button className="button" onClick={() => downloadCsv(filename, rows)} disabled={rows.length < 2}><Download size={16}/>تصدير CSV</button><button className="button primary" onClick={() => window.print()}><Printer size={16}/>طباعة التقرير</button></>;
}
export function ScoreBadge({ mark }: { mark: Mark }) {
  return <span className={`score-badge ${mark.tone === 'muted-red' ? 'danger' : mark.tone === 'gray' ? 'gray' : ''}`}>
    {mark.display}{mark.round_used === 2 && <small>الدور الثاني</small>}{mark.is_excluded && <small>مستبعدة</small>}
  </span>;
}
export function Percent({ value }: { value: string | number | null }) {
  return <span className={`percentage ${value == null ? 'muted' : Number(value) >= 80 ? 'green-text' : Number(value) < 50 ? 'red-text' : ''}`}>{pct(value)}</span>;
}
export function PrintLegend() { return <p className="report-legend">غائب / غش: احتساب بصفر في نتيجة الطالب فقط. معذور وغير مسجلة: مستثناة. * تتضمن النتيجة مواد غياب/غش احتُسبت بصفر. الدرجة الرقمية للدور الثاني تحل محل العذر.</p>; }
export function Notice({ children }: { children: React.ReactNode }) { return <div className="notice">{children}</div>; }
