'use client';
import { useEffect, useState } from 'react';
import { Eye, RotateCcw } from 'lucide-react';
const modes = [{id:'school',name:'ألوان المدرسة'},{id:'night',name:'ليلي'},{id:'warm',name:'قراءة دافئة'},{id:'contrast',name:'تباين عالٍ'},{id:'system',name:'حسب الجهاز'},{id:'original',name:'المظهر السابق'}];
const key = 'andalus-appearance-trial-v1';
export function AppearanceControls() {
 const [mode,setMode]=useState('school'),[scale,setScale]=useState(100),[ready,setReady]=useState(false);
 useEffect(()=>{try{const saved=JSON.parse(localStorage.getItem(key)||'null');if(saved&&modes.some(x=>x.id===saved.mode))setMode(saved.mode);if(saved&&[90,100,110,120,130,140].includes(saved.scale))setScale(saved.scale);}catch{}setReady(true);},[]);
 useEffect(()=>{if(!ready)return;const media=window.matchMedia('(prefers-color-scheme: dark)');const apply=()=>{document.documentElement.dataset.appearance=mode==='system'?(media.matches?'night':'school'):mode;document.documentElement.style.setProperty('--text-scale',String(scale/100));};apply();media.addEventListener('change',apply);try{localStorage.setItem(key,JSON.stringify({mode,scale}));}catch{}return()=>media.removeEventListener('change',apply);},[mode,scale,ready]);
 return <div className="appearance-toolbar no-print" aria-label="خيارات العرض"><span className="trial-label"><Eye size={17} aria-hidden="true"/>خيارات العرض</span><label><span className="sr-only">نمط العرض</span><select aria-label="نمط العرض" value={mode} onChange={e=>setMode(e.target.value)}>{modes.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></label><div className="text-controls" dir="ltr"><button type="button" aria-label="تصغير النص" disabled={scale===90} onClick={()=>setScale(s=>Math.max(90,s-10))}>A−</button><output aria-live="polite" aria-label="حجم النص">{scale}%</output><button type="button" aria-label="تكبير النص" disabled={scale===140} onClick={()=>setScale(s=>Math.min(140,s+10))}>A+</button><button type="button" aria-label="إعادة الحجم الافتراضي" title="إعادة الحجم الافتراضي" onClick={()=>setScale(100)}><RotateCcw size={16}/></button></div><button type="button" className="cancel-trial" onClick={()=>{setMode('school');setScale(100);}}>المظهر الافتراضي</button></div>;
}
export function SchoolLogo(){return <img className="trial-school-logo" src="/school-logo-trial.png" width="328" height="106" alt="مجمع الأندلس التعليمي — مدرسة الأندلس الثانوية الخاصة للبنين"/>;}

