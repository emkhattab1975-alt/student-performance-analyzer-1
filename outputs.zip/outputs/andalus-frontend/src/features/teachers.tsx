'use client';
import { useState } from 'react';
import { Filters, useWorkspace } from '@/components/shell';
import { Empty, ExportActions, Failure, Loading, PageTitle, Panel, Percent, PrintLegend } from '@/components/ui';
import { useResource } from '@/hooks/use-resource';
import { num } from '@/lib/format';
type Row = { subject_id: string; achievement: string | null; included_sections: number; total_sections: number; sections: { section_id: string; achievement: string | null }[] };
export default function Teachers() {
  const w = useWorkspace();
  const [selected, select] = useState('');
  const teacher = w.context.teachers.find(t => t.id === selected) || w.context.teachers[0];
  const resource = useResource<Row[]>(teacher ? `${w.base}/packages/${w.packageId}/teachers/${teacher.id}` : null);
  const subject = (id: string) => w.context.subjects.find(s => s.id === id)?.name_ar || '';
  const rows = resource.data || [];
  return <><PageTitle title={w.context.role === 'TEACHER' ? 'تحصيل موادي' : 'تحصيل المعلمين'} description="متوسط نسب تحصيل الشعب بأوزان متساوية، لكل مادة على حدة."/>
    <div className="filter-bar no-print"><label className="field"><span>الباقة الدراسية</span><select value={w.packageId} onChange={e => w.setPackageId(e.target.value)}>{w.context.packages.map(p => <option key={p.id} value={p.id}>{p.name_ar}</option>)}</select></label><label className="field"><span>المعلم</span><select value={teacher?.id || ''} onChange={e => select(e.target.value)}>{w.context.teachers.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label></div>
    {!teacher ? <Panel><Empty title="لا توجد حسابات معلمين مسندة"/></Panel> : resource.loading ? <Loading/> : resource.error ? <Failure message={resource.error} retry={resource.reload}/> : <Panel title={teacher.name} subtitle={w.context.packages.find(p => p.id === w.packageId)?.name_ar} action={<div className="actions no-print"><ExportActions filename="تحصيل-المعلم.csv" rows={[
      ['المادة','التحصيل','الشعب المحتسبة','كل الشعب'], ...rows.map(r => [subject(r.subject_id),r.achievement,r.included_sections,r.total_sections])
    ]}/></div>}>
      {!rows.length ? <Empty title="لا يوجد إسناد في الباقة المختارة"/> : <div className="table-wrap"><table><thead><tr><th>المادة</th><th>نسبة تحصيل المعلم</th><th>الشعب المحتسبة</th><th>تفصيل الشعب</th></tr></thead><tbody>{rows.map(r => <tr key={r.subject_id}><td><strong>{subject(r.subject_id)}</strong></td><td><Percent value={r.achievement}/></td><td>{num(r.included_sections)} من {num(r.total_sections)}</td><td>{r.sections.map(s => { const sec = w.context.sections.find(x => x.id === s.section_id); return <div key={s.section_id} className="table-muted">{w.context.stages.find(g => g.id === sec?.stage_id)?.name_ar} / {sec?.name_ar}: <Percent value={s.achievement}/></div>; })}</td></tr>)}</tbody></table></div>}<p className="coverage">تستبعد الشعبة التي لا تحتوي درجات محتسبة من المتوسط. لا يستخدم عدد طلاب الشعبة كوزن.</p><PrintLegend/>
    </Panel>}
  </>;
}
