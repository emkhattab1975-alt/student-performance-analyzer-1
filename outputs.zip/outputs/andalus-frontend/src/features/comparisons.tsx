'use client';
import { useState } from 'react';
import { useWorkspace } from '@/components/shell';
import { ComparisonChart } from '@/components/charts';
import { Empty, ExportActions, Failure, Loading, Notice, PageTitle, Panel, Percent, PrintLegend } from '@/components/ui';
import { useResource } from '@/hooks/use-resource';
import { num, pct } from '@/lib/format';
import { query } from '@/lib/api';
import type { Comparison, Progress, Student } from '@/lib/types';

export function DeltaBadge({ value }: { value: string | null }) { return value == null ? <span className="muted">غير متاح</span> : <span className={`delta ${Number(value) > 0 ? 'positive' : Number(value) < 0 ? 'negative' : ''}`}><span dir="ltr">{Number(value) > 0 ? '+' : ''}{num(value,2)}</span><small>نقطة</small></span>; }

export default function Comparisons({ progress = false }: { progress?: boolean }) {
  const w = useWorkspace();
  const [firstId, setFirstId] = useState(''), [secondId, setSecondId] = useState(''), [sectionId, setSectionId] = useState('');
  const first = w.context.packages.find(p => p.id === firstId) || w.context.packages[0];
  const subsequent = w.context.packages.filter(p => p.sequence_no > (first?.sequence_no || 0));
  const second = subsequent.find(p => p.id === secondId) || subsequent[0];
  const sections = w.context.sections.filter(s => w.context.role !== 'TEACHER' || w.context.assignments.some(a => a.package_id === first?.id && a.section_id === s.id && w.context.assignments.some(b => b.package_id === second?.id && b.section_id === s.id && b.stage_subject_id === a.stage_subject_id)));
  const section = sections.find(s => s.id === sectionId) || sections[0];
  const valid = first && second && (progress || section);
  return <>
    <PageTitle title={progress ? 'تقدم الطلاب' : 'مقارنة الباقات'} description={progress ? 'متابعة تغير نتائج الطالب، مع مراعاة انتقاله بين الشعب والمسارات.' : 'قارن التحصيل على المواد المشتركة، وحدد مواضع التقدم والتراجع.'}/>
    <div className="filter-bar no-print">
      <label className="field"><span>الباقة الأولى</span><select value={first?.id || ''} onChange={e => setFirstId(e.target.value)}>{w.context.packages.filter(p => p.sequence_no < 4).map(p => <option key={p.id} value={p.id}>{p.name_ar}</option>)}</select></label>
      <label className="field"><span>الباقة الثانية</span><select value={second?.id || ''} onChange={e => setSecondId(e.target.value)}>{subsequent.map(p => <option key={p.id} value={p.id}>{p.name_ar}</option>)}</select></label>
      {!progress && <label className="field"><span>الشعبة</span><select value={section?.id || ''} onChange={e => setSectionId(e.target.value)}>{sections.map(s => <option key={s.id} value={s.id}>{w.context.stages.find(g => g.id === s.stage_id)?.name_ar} / {s.name_ar}</option>)}</select></label>}
      {!progress && <label className="toggle"><input type="checkbox" checked={w.coreOnly} onChange={e => w.setCoreOnly(e.target.checked)}/>المواد الأساسية فقط</label>}
    </div>
    {!valid ? <Panel><Empty title="لا يوجد نطاق مشترك للمقارنة" text="تحتاج المقارنة إلى باقتين، وإسناد مشترك في الباقتين لحساب المعلم."/></Panel> : progress ? <ProgressReport first={first.id} second={second.id}/> : <ComparisonReport first={first.id} second={second.id} section={section!.id}/>}
  </>;
}

function ComparisonReport({ first, second, section }: { first: string; second: string; section: string }) {
  const w = useWorkspace();
  const resource = useResource<Comparison>(`${w.base}/comparisons?${query({ first_package_id: first, second_package_id: second, section_id: section, core_only: w.coreOnly })}`);
  if (resource.loading) return <Loading/>;
  if (resource.error) return <Failure message={resource.error} retry={resource.reload}/>;
  if (!resource.data) return null;
  const r = resource.data;
  const subject = (id: string) => w.context.subjects.find(s => s.id === id)?.name_ar || 'مادة';
  const firstName = w.context.packages.find(p => p.id === first)!.name_ar, secondName = w.context.packages.find(p => p.id === second)!.name_ar;
  const sc = w.context.sections.find(s => s.id === section)!;
  return <div className="stack"><Notice>المقارنة تشمل كامل طلاب الشعبة في كل باقة، على المواد المشتركة ذات النتائج المحتسبة. الفرق بالنقاط المئوية، وقد يتأثر بتغيّر الطلاب.</Notice>
    <Panel title={`${w.context.stages.find(s => s.id === sc.stage_id)?.name_ar} / ${sc.name_ar}`} subtitle={`${firstName} ← ${secondName}`} action={<div className="actions no-print"><ExportActions filename="مقارنة-الباقات.csv" rows={[
      ['المادة',firstName,secondName,'الفرق بالنقاط'], ...r.subjects.map(s => [subject(s.subject_id),s.first,s.second,s.delta_pp])
    ]}/></div>}>
      <div className="panel-body"><div className="kpi-grid" style={{ marginBottom: 0 }}><div className="kpi"><div className="kpi-label">تحصيل الباقة الأولى</div><div className="kpi-value">{pct(r.overall.first)}</div></div><div className="kpi"><div className="kpi-label">تحصيل الباقة الثانية</div><div className="kpi-value">{pct(r.overall.second)}</div></div><div className="kpi"><div className="kpi-label">القيمة المضافة</div><div className="kpi-value"><DeltaBadge value={r.overall.delta_pp}/></div></div><div className="kpi"><div className="kpi-label">المواد المشتركة</div><div className="kpi-value">{num(r.overall.shared_subject_count)}</div></div></div></div>
      {r.overall.shared_subject_count ? <ComparisonChart first={firstName} second={secondName} data={r.subjects.filter(s => s.delta_pp !== null).map(s => ({ name: subject(s.subject_id), first: s.first === null ? null : Number(s.first), second: s.second === null ? null : Number(s.second) }))}/> : <Empty title="لا توجد نتائج مشتركة قابلة للمقارنة" text="يلزم وجود طلاب محتسبين للمادة في الباقتين."/>}
      <div className="table-wrap"><table><thead><tr><th>المادة</th><th>الباقة الأولى</th><th>الباقة الثانية</th><th>الفرق</th><th>التغطية الأولى</th><th>التغطية الثانية</th></tr></thead><tbody>{r.subjects.map(s => <tr key={s.subject_id}><td><strong>{subject(s.subject_id)}</strong>{s.is_decline && <span className="badge red" style={{ marginInlineStart: 8 }}>تراجع</span>}</td><td><Percent value={s.first}/></td><td><Percent value={s.second}/></td><td><DeltaBadge value={s.delta_pp}/></td><td className="table-muted" style={{ whiteSpace: 'normal', maxWidth: 240 }}>{s.first_coverage?.coverage_text || 'لا توجد بيانات'}</td><td className="table-muted" style={{ whiteSpace: 'normal', maxWidth: 240 }}>{s.second_coverage?.coverage_text || 'لا توجد بيانات'}</td></tr>)}</tbody></table></div>
      {r.overall.omitted_subject_ids.length > 0 && <p className="coverage">مواد لم تدخل المقارنة: {r.overall.omitted_subject_ids.map(subject).join('، ')}</p>}<PrintLegend/>
    </Panel></div>;
}

function ProgressReport({ first, second }: { first: string; second: string }) {
  const w = useWorkspace();
  const resource = useResource<Progress[]>(`${w.base}/student-progress?${query({ first_package_id: first, second_package_id: second })}`);
  const students = useResource<Student[]>(`${w.base}/students`);
  if (resource.loading || students.loading) return <Loading/>;
  if (resource.error || students.error) return <Failure message={resource.error || students.error} retry={() => { resource.reload(); students.reload(); }}/>;
  const rows = resource.data || [];
  const name = (id: string) => students.data?.find(s => s.id === id)?.full_name || 'طالب';
  return <Panel title="تقدم الطلاب بين الباقتين" subtitle={`${w.context.packages.find(p => p.id === first)?.name_ar} ← ${w.context.packages.find(p => p.id === second)?.name_ar}`} action={<div className="actions no-print"><ExportActions filename="تقدم-الطلاب.csv" rows={[
    ['الطالب','النسبة الأولى','النسبة الثانية','التغير','الاتجاه','تغير المسار','تغير الشعبة'], ...rows.map(r => [name(r.student_id),r.first_percentage,r.second_percentage,r.delta_pp,r.direction,r.stage_changed?'نعم':'لا',r.section_changed?'نعم':'لا'])
  ]}/></div>}>
    {!rows.length ? <Empty/> : <div className="table-wrap"><table><thead><tr><th>الطالب</th><th>النسبة الأولى</th><th>النسبة الثانية</th><th>التغير</th><th>الاتجاه</th><th>ملاحظات المقارنة</th><th>المواد المشتركة الحاضرة</th></tr></thead><tbody>{rows.map(r => <tr key={r.student_id}><td><strong>{name(r.student_id)}</strong></td><td><Percent value={r.first_percentage}/></td><td><Percent value={r.second_percentage}/></td><td><DeltaBadge value={r.delta_pp}/></td><td><span className={`badge ${r.direction === 'متقدم' ? 'green' : r.direction === 'متراجع' ? 'red' : 'gray'}`}>{r.direction}</span></td><td>{[r.stage_changed && 'تغيّر المسار',r.section_changed && 'تغيّرت الشعبة',r.subjects_changed && 'تغيّرت المواد'].filter(Boolean).join(' · ') || '—'}</td><td style={{ whiteSpace: 'normal', minWidth: 160 }}>{r.common_present_subjects.length ? r.common_present_subjects.map(s => <div key={s.subject_id} className="table-muted">{w.context.subjects.find(m => m.id === s.subject_id)?.name_ar}: <DeltaBadge value={s.delta_pp}/></div>) : 'غير متاح'}</td></tr>)}</tbody></table></div>}<PrintLegend/>
  </Panel>;
}
