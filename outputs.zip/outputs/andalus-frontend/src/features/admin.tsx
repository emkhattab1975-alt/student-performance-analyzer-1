'use client';
import { useState } from 'react';
import { Plus, Save, UserCheck, UserX, X } from 'lucide-react';
import { useWorkspace } from '@/components/shell';
import { Empty, Failure, Loading, Notice, PageTitle, Panel } from '@/components/ui';
import { useResource } from '@/hooks/use-resource';
import { send } from '@/lib/api';
import { date, roleName } from '@/lib/format';
import type { Role, SettingsData, User } from '@/lib/types';

export function UsersPage() {
  const w = useWorkspace();
  const resource = useResource<User[]>(`${w.base}/users`);
  const [creating, setCreating] = useState(false), [reset, setReset] = useState<User | null>(null), [error, setError] = useState(''), [busy, setBusy] = useState(false), [role, setRole] = useState<Role>('TEACHER');
  async function create(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setBusy(true);
    const f = new FormData(event.currentTarget);
    try { await send(`${w.base}/users`, { username: f.get('username'), display_name: f.get('display_name'), password: f.get('password'), role, employee_code: role === 'TEACHER' ? f.get('employee_code') : null }); setCreating(false); resource.reload(); }
    catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  }
  async function change(user: User) {
    if (!window.confirm(`${user.is_active ? 'تعطيل' : 'تفعيل'} حساب ${user.display_name}؟ يسري التغيير على الحساب في جميع الأعوام.`)) return;
    setError(''); setBusy(true);
    try { await send(`${w.base}/users/${user.id}`, { is_active: !user.is_active }, 'PATCH'); resource.reload(); }
    catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  }
  async function password(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!reset) return;
    setBusy(true); setError('');
    try { await send(`${w.base}/users/${reset.id}/password`, { password: new FormData(event.currentTarget).get('password') }, 'PUT'); setReset(null); }
    catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  }
  return <><PageTitle title="إدارة المستخدمين" description="حسابات المدرسة وأدوارها. تغييرات الحسابات تُسجّل في سجل التدقيق." actions={<button className="button primary" onClick={() => { setCreating(true); setError(''); }}><Plus size={17}/>مستخدم جديد</button>}/>
    {error && !creating && !reset && <Failure message={error}/>}
    {resource.loading ? <Loading/> : resource.error ? <Failure message={resource.error} retry={resource.reload}/> : <Panel title="مستخدمو العام الدراسي" subtitle={w.context.year_code}><div className="table-wrap"><table><thead><tr><th>المستخدم</th><th>اسم الدخول</th><th>الدور</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>{resource.data?.map(user => <tr key={user.id}><td><strong>{user.display_name}</strong>{user.id === w.me.id && <span className="badge" style={{ marginInlineStart: 8 }}>أنت</span>}</td><td dir="ltr">{user.username}</td><td>{roleName[user.role]}</td><td><span className={`badge ${user.is_active ? 'green' : 'gray'}`}>{user.is_active ? 'فعال' : 'معطل'}</span></td><td><div className="actions"><button className="button small" disabled={busy || user.id === w.me.id} onClick={() => change(user)}>{user.is_active ? <UserX size={14}/> : <UserCheck size={14}/>} {user.is_active ? 'تعطيل' : 'تفعيل'}</button><button className="button small" onClick={() => { setReset(user); setError(''); }}>إعادة تعيين كلمة المرور</button></div></td></tr>)}</tbody></table></div></Panel>}
    {(creating || reset) && <div className="dialog-backdrop"><section className="dialog" role="dialog" aria-modal="true" aria-labelledby="user-dialog-title"><div className="dialog-heading"><h2 id="user-dialog-title">{creating ? 'إضافة مستخدم' : `كلمة مرور ${reset?.display_name}`}</h2><button className="icon-button" disabled={busy} onClick={() => { setCreating(false); setReset(null); }} aria-label="إغلاق"><X size={20}/></button></div>
      <form className="form-stack" onSubmit={creating ? create : password}>
        {creating && <><label className="field"><span>الاسم</span><input name="display_name" required maxLength={200}/></label><label className="field"><span>اسم المستخدم بالإنجليزية</span><input name="username" dir="ltr" required minLength={3} maxLength={100} pattern="[a-zA-Z0-9_.@-]+" autoComplete="off"/></label><label className="field"><span>الدور</span><select value={role} onChange={e => setRole(e.target.value as Role)}><option value="TEACHER">المعلم</option><option value="PRINCIPAL">المدير</option><option value="SYSTEM_ADMIN">مدير النظام</option></select></label>{role === 'TEACHER' && <label className="field"><span>رمز الموظف</span><input name="employee_code" required maxLength={40}/></label>}</>}
        <label className="field"><span>كلمة مرور جديدة (١٢ محرفاً على الأقل)</span><input name="password" type="password" dir="ltr" autoComplete="new-password" required minLength={12} maxLength={256}/></label>
        {error && <Failure message={error}/>}<button className="button primary" disabled={busy}>{busy ? 'جارٍ الحفظ…' : 'حفظ'}</button>
      </form></section></div>}
  </>;
}

export function SettingsPage() {
  const w = useWorkspace();
  const resource = useResource<SettingsData>(`${w.base}/settings`);
  return <><PageTitle title="إعدادات النظام" description="هوية المدرسة وقواعد التصنيف والتحليل لهذا العام الدراسي."/>
    {resource.loading ? <Loading/> : resource.error ? <Failure message={resource.error} retry={resource.reload}/> : resource.data && <SettingsForm key={resource.data.settings.revision} data={resource.data} reload={resource.reload}/>}
  </>;
}
function SettingsForm({ data, reload }: { data: SettingsData; reload: () => void }) {
  const w = useWorkspace();
  const [levels, setLevels] = useState(data.levels), [busy, setBusy] = useState(false), [error, setError] = useState(''), [success, setSuccess] = useState('');
  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(''); setSuccess('');
    const form = new FormData(event.currentTarget);
    try { await send(`${w.base}/settings`, { school_name: form.get('school_name'), decline_threshold_pp: form.get('threshold'), levels: levels.map(l => ({ code: l.code, label: l.label, minimum_percent: l.minimum_percent })), expected_revision: data.settings.revision }, 'PUT'); setSuccess('تم حفظ الإعدادات.'); reload(); w.refreshContext(); }
    catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  }
  async function policy(id: string, core: boolean, excluded: boolean) {
    setBusy(true); setError('');
    try { await send(`${w.base}/subjects/${id}/policy`, { is_core: core, is_excluded: excluded }, 'PATCH'); w.refreshContext(); }
    catch (err) { setError((err as Error).message); } finally { setBusy(false); }
  }
  return <div className="stack">{error && <Failure message={error}/>} {success && <div className="success-box" role="status">{success}</div>}
    <form onSubmit={save} className="settings-layout"><Panel title="هوية المدرسة والتحليل" subtitle="التغييرات تخص العام الحالي"><div className="panel-body form-stack"><label className="field"><span>اسم المدرسة</span><input name="school_name" defaultValue={data.settings.school_name} required maxLength={200}/></label><label className="field"><span>حد التراجع الجماعي (نقاط مئوية)</span><input name="threshold" type="number" min="0.01" max="100" step="0.01" defaultValue={data.settings.decline_threshold_pp} required/></label><Notice>يعاد احتساب التحليلات وتنبيهات التراجع وفق الإعدادات الجديدة. تبقى قاعدة نجاح المادة ثابتة عند ٥٠٪ من النهاية.</Notice><button className="button primary" disabled={busy}><Save size={16}/>{busy ? 'جارٍ الحفظ…' : 'حفظ الإعدادات'}</button></div></Panel>
      <Panel title="حدود مستويات الطلاب" subtitle="الحد الأدنى لكل مستوى، دون تقريب النسبة"><div className="panel-body">{levels.map((level,i) => <div className="level-editor" key={level.code}><label className="field"><span className="sr-only">اسم المستوى {i+1}</span><input value={level.label} onChange={e => setLevels(levels.map((l,j) => j === i ? { ...l, label: e.target.value } : l))} required/></label><label className="field"><span className="sr-only">الحد الأدنى لمستوى {level.label}</span><input type="number" min="0" max="100" step="0.01" value={level.minimum_percent} onChange={e => setLevels(levels.map((l,j) => j === i ? { ...l, minimum_percent: e.target.value } : l))} required/></label></div>)}<p className="form-note">يجب أن يبدأ أدنى مستوى من صفر، وأن تكون الحدود غير مكررة.</p></div></Panel>
    </form>
    <Panel title="سياسة احتساب المواد" subtitle="غير الأساسية تدخل نسبة الطالب وترتيبه؛ المستبعدة لا تدخل أي حساب">
      {!w.context.subjects.length ? <Empty title="لم تُعرّف المواد بعد" text="أضف مواد المدرسة من صفحة البيانات والدرجات."/> : <div className="table-wrap"><table><thead><tr><th>المادة</th><th>مادة أساسية</th><th>مستبعدة من الحسابات</th></tr></thead><tbody>{w.context.subjects.map(subject => <tr key={subject.id}><td>{subject.name_ar}</td><td><label className="toggle"><input aria-label={`أساسية: ${subject.name_ar}`} type="checkbox" checked={subject.is_core} disabled={busy || subject.is_excluded} onChange={e => policy(subject.id,e.target.checked,subject.is_excluded)}/>{subject.is_core ? 'نعم' : 'لا'}</label></td><td><label className="toggle"><input aria-label={`استبعاد: ${subject.name_ar}`} type="checkbox" checked={subject.is_excluded} disabled={busy || subject.name_ar === 'المهارات الحياتية'} onChange={e => policy(subject.id,e.target.checked ? false : subject.is_core,e.target.checked)}/>{subject.is_excluded ? 'مستبعدة' : 'محتسبة'}</label></td></tr>)}</tbody></table></div>}
    </Panel>
    <Panel title="إدارة الباقات" subtitle="تفعيل الدور الثاني أو قفل إدخال الدرجات"><div className="table-wrap"><table><thead><tr><th>الباقة</th><th>الدور الثاني</th><th>الحالة</th><th>الإجراء</th></tr></thead><tbody>{w.context.packages.map(p => <tr key={p.id}><td>{p.name_ar}</td><td>{p.has_second_round ? 'مفعّل' : 'غير مفعّل'}</td><td>{p.status === 'LOCKED' ? 'مقفلة' : p.status === 'PUBLISHED' ? 'منشورة' : 'مسودة'}</td><td><div className="actions"><button className="button small" type="button" disabled={busy} onClick={async () => { setBusy(true); try { await send(`${w.base}/packages/${p.id}`, { has_second_round: !p.has_second_round, status: p.status, expected_revision: p.data_revision }, 'PATCH'); w.refreshContext(); } catch(err) { setError((err as Error).message); } finally { setBusy(false); } }}>{p.has_second_round ? 'تعطيل الدور الثاني' : 'تفعيل الدور الثاني'}</button><button className="button small" disabled={busy} onClick={async () => { setBusy(true); try { await send(`${w.base}/packages/${p.id}`, { has_second_round: p.has_second_round, status: p.status === 'LOCKED' ? 'DRAFT' : 'LOCKED', expected_revision: p.data_revision }, 'PATCH'); w.refreshContext(); } catch(err) { setError((err as Error).message); } finally { setBusy(false); } }}>{p.status === 'LOCKED' ? 'فتح الباقة' : 'قفل الباقة'}</button></div></td></tr>)}</tbody></table></div></Panel>
  </div>;
}

type Audit = { id: string; created_at: string; action: string; entity_type: string; entity_id: string; actor_user_id: string; before_json: unknown; after_json: unknown };
const actions: Record<string,string> = { EDIT_RECORD:'تعديل سجل',DELETE_RECORD:'حذف سجل',DISABLE_YEAR_TEACHER:'تعطيل عضوية معلم',BULK_RECORD_ACTION:'عملية جماعية',PREVIEW_EXCEL:'معاينة ملف Excel',APPLY_EXCEL:'اعتماد ملف Excel',CREATE:'إضافة سجل',CREATE_YEAR:'إنشاء عام',EDIT_YEAR:'تعديل بيانات العام',SET_CURRENT_YEAR:'تحديد العام الحالي',DELETE_YEAR:'حذف عام وبياناته',CREATE_USER:'إنشاء مستخدم',ADD_MEMBERSHIP:'إضافة عضوية',UPDATE_SETTINGS:'تعديل الإعدادات',UPDATE_SUBJECT_POLICY:'تعديل سياسة مادة',UPDATE_PACKAGE:'تعديل باقة',CREATE_SCORE:'إضافة درجة',UPDATE_SCORE:'تصحيح درجة',UPDATE_MAXIMUM:'تعديل النهاية',SET_USER_STATUS:'تغيير حالة مستخدم',RESET_PASSWORD:'إعادة تعيين كلمة المرور' };
const entities: Record<string,string> = { excel_uploads:'ملفات Excel',students:'الطلاب',sections:'الشعب',subjects:'المواد',stage_subjects:'مواد المراحل',student_enrollments:'الانتماءات',scores:'الدرجات',subject_maxima:'النهايات',teaching_assignments:'الأنصبة',users:'المستخدمون',year_settings:'الإعدادات',packages:'الباقات',academic_years:'الأعوام',year_memberships:'العضويات' };
export function AuditPage() {
  const w = useWorkspace();
  const resource = useResource<Audit[]>(`${w.base}/audit`), users = useResource<User[]>(`${w.base}/users`);
  return <><PageTitle title="سجل التدقيق" description="آخر ٢٠٠ عملية مسجلة في العام الحالي. السجل محمي من التعديل والحذف."/>
    {resource.loading ? <Loading/> : resource.error ? <Failure message={resource.error} retry={resource.reload}/> : <Panel title="العمليات المسجلة"><div className="table-wrap"><table><thead><tr><th>الوقت</th><th>العملية</th><th>البيانات</th><th>نفذها</th><th>مرجع السجل</th></tr></thead><tbody>{resource.data?.map(row => <tr key={row.id}><td>{date(row.created_at)}</td><td>{actions[row.action] || 'عملية نظام'}</td><td>{entities[row.entity_type] || 'سجل نظام'}</td><td>{users.data?.find(u => u.id === row.actor_user_id)?.display_name || 'النظام'}</td><td className="table-muted" dir="ltr">{row.entity_id?.slice(0,8) || '—'}</td></tr>)}</tbody></table></div></Panel>}
  </>;
}
