'use client';
import { useState } from 'react';
import { Save } from 'lucide-react';
import { useWorkspace } from '@/components/shell';
import { Empty, Failure, Loading, Notice, PageTitle, Panel } from '@/components/ui';
import { useResource } from '@/hooks/use-resource';
import { send } from '@/lib/api';
import { num } from '@/lib/format';
import type { Editor, Student } from '@/lib/types';

type Field = { name: string; label: string; type?: string; options?: { value: string; label: string }[]; min?: string; step?: string };
function AddForm({ title, path, fields, method, onSaved }: { title: string; path: string; fields: Field[]; method?: string; onSaved: () => void }) {
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [success, setSuccess] = useState('');
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setSuccess(''); setBusy(true);
    const form = event.currentTarget;
    try { await send(path,Object.fromEntries(new FormData(form)),method || 'POST'); form.reset(); setSuccess('تم الحفظ بنجاح.'); onSaved(); }
    catch(err) { setError((err as Error).message); } finally { setBusy(false); }
  }
  return <Panel title={title} className="record-card"><form onSubmit={submit} className="panel-body record-form-body"><div className="record-fields">{fields.map(field => <label className="field" key={field.name}><span>{field.label}</span>{field.options ? <select name={field.name} required defaultValue=""><option value="" disabled>اختر…</option>{field.options.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select> : <input name={field.name} type={field.type || 'text'} min={field.min} step={field.step} required/>}</label>)}</div><div className="record-form-footer">{error && <Failure message={error}/>} {success && <div className="success-box" role="status">{success}</div>}<button className="button primary" disabled={busy}><Save size={16} aria-hidden="true"/>{busy ? 'جارٍ الحفظ…' : 'حفظ'}</button></div></form></Panel>;
}

export default function Records() {
  const w = useWorkspace();
  const [tab, setTab] = useState(w.context.role === 'SYSTEM_ADMIN' ? 'setup' : 'students');
  const students = useResource<Student[]>(`${w.base}/students`);
  const editor = useResource<Editor>(`${w.base}/packages/${w.packageId}/editor`);
  const sections = w.context.sections.map(s => ({ value:s.id, label:`${w.context.stages.find(g => g.id === s.stage_id)?.name_ar} / ${s.name_ar}` }));
  const curricula = w.context.stage_subjects.map(c => ({ value:c.id, label:`${w.context.stages.find(g => g.id === c.stage_id)?.name_ar} · ${w.context.subjects.find(s => s.id === c.subject_id)?.name_ar}` }));
  const reload = () => { students.reload(); editor.reload(); };
  return <><PageTitle title="البيانات والدرجات" description="أضف بيانات المدرسة الفعلية، وثبّت انتماءات الطلاب لكل باقة، ثم أدخل الدرجات."/>
    <div className="filter-bar"><label className="field"><span>الباقة الدراسية</span><select value={w.packageId} onChange={e => w.setPackageId(e.target.value)}>{w.context.packages.map(p => <option key={p.id} value={p.id}>{p.name_ar}</option>)}</select></label><span className={`badge ${editor.data?.status === 'LOCKED' ? 'red' : 'green'}`}>{editor.data?.status === 'LOCKED' ? 'الباقة مقفلة' : 'البيانات تخص الباقة المحددة'}</span></div>
    <p className="records-sequence muted">ابدأ بتعريف الشعب والمواد وربطها بالصفوف، ثم الطلاب وانتماءاتهم، ثم النهايات والأنصبة، وأخيراً الدرجات. إسناد الأنصبة يتطلب إنشاء حسابات المعلمين من إدارة المستخدمين أو استيراد Excel.</p>
    <div className="tabs records-tabs" role="tablist" aria-label="إدارة البيانات">{[...(w.context.role === 'SYSTEM_ADMIN' ? [['setup','الشعب والمواد']] : []),['students','الطلاب والانتماءات'],['maxima','النهايات والأنصبة'],['scores','إدخال الدرجات']].map(([id,label]) => <button role="tab" aria-selected={tab === id} className={`tab ${tab === id ? 'active' : ''}`} key={id} onClick={() => setTab(id)}>{label}</button>)}</div>
    {students.error || editor.error ? <Failure message={students.error || editor.error} retry={reload}/> : students.loading || editor.loading ? <Loading/> : <>
      {tab === 'students' && <div className="stack"><div className="records-form-grid"><AddForm title="إضافة طالب" path={`${w.base}/students`} fields={[{name:'personal_number',label:'الرقم الشخصي'},{name:'full_name',label:'اسم الطالب'}]} onSaved={reload}/><AddForm title="إسناد الطالب إلى شعبة في الباقة" path={`${w.base}/packages/${w.packageId}/enrollments`} fields={[{name:'student_id',label:'الطالب',options:(students.data || []).map(s => ({value:s.id,label:`${s.full_name} · ${s.personal_number}`}))},{name:'section_id',label:'الشعبة',options:sections}]} onSaved={reload}/></div>
        <Panel title="الطلاب المسجلون في العام" subtitle="الانتماء المعروض يخص الباقة المختارة">{!students.data?.length ? <Empty title="أضف أول طالب للبدء"/> : <div className="table-wrap"><table><thead><tr><th>الطالب</th><th>الرقم الشخصي</th><th>الشعبة في الباقة</th></tr></thead><tbody>{students.data.map(s => { const enrollment = editor.data?.enrollments.find(e => e.student_id === s.id); return <tr key={s.id}><td>{s.full_name}</td><td dir="ltr">{s.personal_number}</td><td>{enrollment ? sections.find(c => c.value === enrollment.section_id)?.label : <span className="badge gray">لم يُسند بعد</span>}</td></tr>; })}</tbody></table></div>}</Panel></div>}
      {tab === 'setup' && w.context.role === 'SYSTEM_ADMIN' && <div className="stack"><div className="records-form-grid records-setup-grid"><AddForm title="إنشاء شعبة" path={`${w.base}/sections`} fields={[{name:'stage_id',label:'الصف والمسار',options:w.context.stages.map(s => ({value:s.id,label:s.name_ar}))},{name:'code',label:'رمز الشعبة'},{name:'name_ar',label:'اسم الشعبة'}]} onSaved={w.refreshContext}/><AddForm title="تعريف مادة" path={`${w.base}/subjects`} fields={[{name:'code',label:'رمز المادة'},{name:'name_ar',label:'اسم المادة بالعربية'}]} onSaved={w.refreshContext}/><AddForm title="ربط مادة بصف ومسار" path={`${w.base}/stage-subjects`} fields={[{name:'stage_id',label:'الصف والمسار',options:w.context.stages.map(s => ({value:s.id,label:s.name_ar}))},{name:'subject_id',label:'المادة',options:w.context.subjects.map(s => ({value:s.id,label:s.name_ar}))}]} onSaved={w.refreshContext}/></div><Notice>تُطبق السياسات الافتراضية عند إنشاء المادة. تُستبعد المهارات الحياتية دائماً. يمكنك ضبط المواد الأساسية من إعدادات النظام.</Notice></div>}
      {tab === 'maxima' && <div className="stack"><div className="records-form-grid"><AddForm title="تحديد النهاية أو تصحيحها" path={`${w.base}/packages/${w.packageId}/maxima`} method="PUT" fields={[{name:'stage_subject_id',label:'المادة والصف',options:curricula},{name:'max_score',label:'الدرجة النهائية',type:'number',min:'0.01',step:'0.01'}]} onSaved={reload}/><AddForm title="إسناد مادة وشعبة إلى معلم" path={`${w.base}/packages/${w.packageId}/assignments`} fields={[{name:'teacher_id',label:'المعلم',options:w.context.teachers.map(t => ({value:t.id,label:t.name}))},{name:'section_id',label:'الشعبة',options:sections},{name:'stage_subject_id',label:'المادة والصف',options:curricula}]} onSaved={w.refreshContext}/></div><Panel title="النهايات المعتمدة للباقة"><div className="table-wrap"><table><thead><tr><th>المادة والصف</th><th>النهاية</th></tr></thead><tbody>{editor.data?.maxima.map(m => <tr key={m.id}><td>{curricula.find(c => c.value === m.stage_subject_id)?.label}</td><td>{num(m.max_score,2)}</td></tr>)}</tbody></table></div>{!editor.data?.maxima.length && <Empty/>}</Panel></div>}
      {tab === 'scores' && editor.data && <ScoreEditor key={w.packageId} editor={editor.data} students={students.data || []} reload={editor.reload}/>}
    </>}
  </>;
}

function ScoreEditor({ editor, students, reload }: { editor: Editor; students: Student[]; reload: () => void }) {
  const w = useWorkspace();
  const [sectionId,setSectionId] = useState(''), [maximumId,setMaximumId] = useState(''), [round,setRound] = useState(1);
  const section = w.context.sections.find(s => s.id === sectionId) || w.context.sections[0];
  const maxima = editor.maxima.filter(m => m.stage_id === section?.stage_id);
  const maximum = maxima.find(m => m.id === maximumId) || maxima[0];
  return <div className="stack"><Notice>الحاضر يحتاج درجة رقمية، بما فيها الصفر الحقيقي. الغياب والغش والعذر تُحفظ حالات مستقلة. الفراغ يعني مادة غير مسجلة.</Notice><div className="filter-bar" style={{ margin:0 }}><label className="field"><span>الشعبة</span><select value={section?.id || ''} onChange={e => setSectionId(e.target.value)}>{w.context.sections.map(s => <option key={s.id} value={s.id}>{w.context.stages.find(g => g.id === s.stage_id)?.name_ar} / {s.name_ar}</option>)}</select></label><label className="field"><span>المادة</span><select value={maximum?.id || ''} onChange={e => setMaximumId(e.target.value)}>{maxima.map(m => <option key={m.id} value={m.id}>{w.context.subjects.find(s => s.id === w.context.stage_subjects.find(c => c.id === m.stage_subject_id)?.subject_id)?.name_ar}</option>)}</select></label><label className="field"><span>الدور</span><select value={round} onChange={e => setRound(Number(e.target.value))}><option value={1}>الدور الأول</option>{w.context.packages.find(p => p.id === w.packageId)?.has_second_round && <option value={2}>الدور الثاني للمعذورين</option>}</select></label></div>
    {!section || !maximum ? <Panel><Empty title="أكمل الشعب والنهايات أولاً" text="تحتاج المادة إلى نهاية محددة قبل تسجيل درجاتها."/></Panel> : <GradeGrid key={`${section.id}:${maximum.id}:${round}:${editor.data_revision}`} editor={editor} students={students} sectionId={section.id} maximumId={maximum.id} maximum={Number(maximum.max_score)} round={round} reload={reload}/>}
  </div>;
}
function GradeGrid({editor,students,sectionId,maximumId,maximum,round,reload}:{editor:Editor;students:Student[];sectionId:string;maximumId:string;maximum:number;round:number;reload:()=>void}) {
  const w = useWorkspace();
  const rows = editor.enrollments.filter(e => e.section_id === sectionId && (round === 1 || editor.scores.some(s => s.enrollment_id === e.id && s.subject_maximum_id === maximumId && s.round === 1 && s.score_status === 'EXCUSED')));
  const [draft,setDraft] = useState<Record<string,{status:string;score:string}>>({});
  const [busy,setBusy] = useState(false),[error,setError] = useState('');
  const current = (id:string) => { const stored = editor.scores.find(s => s.enrollment_id === id && s.subject_maximum_id === maximumId && s.round === round); return draft[id] || {status:stored?.score_status || 'EMPTY',score:stored?.score == null ? '' : String(stored.score)}; };
  async function save(event:React.FormEvent<HTMLFormElement>) {
    event.preventDefault();setBusy(true);setError('');
    try { await send(`${w.base}/packages/${w.packageId}/scores`,{expected_revision:editor.data_revision,scores:Object.entries(draft).map(([id,value])=>({enrollment_id:id,subject_maximum_id:maximumId,round,score_status:value.status === 'EMPTY' ? null : value.status,score:value.status === 'PRESENT' ? value.score : null}))},'PUT');reload(); }
    catch(err){setError((err as Error).message);}finally{setBusy(false);}
  }
  return <Panel title={`كشف الإدخال · النهاية ${num(maximum,2)}`} subtitle={round === 2 ? 'تظهر فقط المواد المعذور فيها بالدور الأول' : 'تُحفظ الصفوف المعدلة فقط في عملية واحدة'}><form onSubmit={save}>
    {error && <div className="panel-body"><Failure message={error}/></div>}
    {!rows.length ? <Empty title="لا يوجد طلاب مؤهلون في النطاق"/> : <div className="table-wrap"><table><thead><tr><th>الطالب</th><th>الرقم الشخصي</th><th>الحالة والدرجة</th><th>التغيير</th></tr></thead><tbody>{rows.map(row => { const student=students.find(s=>s.id===row.student_id);const value=current(row.id);return <tr key={row.id}><td>{student?.full_name}</td><td dir="ltr">{student?.personal_number}</td><td><div className="score-input"><select aria-label={`حالة ${student?.full_name}`} disabled={busy||editor.status==='LOCKED'} value={value.status} onChange={e=>setDraft({...draft,[row.id]:{status:e.target.value,score:e.target.value==='PRESENT'?value.score:''}})}><option value="EMPTY">غير مسجلة</option><option value="PRESENT">حاضر</option><option value="ABSENT">غائب</option><option value="CHEATING">غش</option><option value="EXCUSED">معذور</option></select>{value.status==='PRESENT'&&<input aria-label={`درجة ${student?.full_name}`} type="number" min="0" max={maximum} step="0.01" required value={value.score} disabled={busy||editor.status==='LOCKED'} onChange={e=>setDraft({...draft,[row.id]:{status:'PRESENT',score:e.target.value}})}/>}</div></td><td>{draft[row.id]&&<span className="badge">غير محفوظ</span>}</td></tr>;})}</tbody></table></div>}
    <div className="panel-pad actions"><button className="button primary" disabled={busy||!Object.keys(draft).length||editor.status==='LOCKED'}><Save size={16}/>{busy?'جارٍ الحفظ…':`حفظ التغييرات (${num(Object.keys(draft).length)})`}</button><button className="button" type="button" disabled={busy} onClick={()=>setDraft({})}>تراجع عن التعديلات</button></div>
  </form></Panel>;
}
