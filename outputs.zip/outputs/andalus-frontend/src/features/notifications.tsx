'use client';
import { Bell, CheckCheck, TrendingDown } from 'lucide-react';
import { useWorkspace } from '@/components/shell';
import { Empty, Failure, Loading, PageTitle, Panel } from '@/components/ui';
import { useResource } from '@/hooks/use-resource';
import { date, num } from '@/lib/format';
import type { SchoolEvent } from '@/lib/types';
export default function Notifications() {
  const w = useWorkspace();
  const resource = useResource<SchoolEvent[]>(`${w.base}/events`, 15000);
  return <><PageTitle title="الإشعارات" description="أحداث تحديث الدرجات وتنبيهات التراجع المسموح لك بمتابعتها. تحديث تلقائي كل ١٥ ثانية."/>
    {resource.loading ? <Loading/> : resource.error ? <Failure message={resource.error} retry={resource.reload}/> : <Panel title="آخر المستجدات" subtitle="التنبيهات المحلولة محفوظة لتتبع ما تغيّر">
      {!resource.data?.length ? <Empty title="لا توجد إشعارات حالياً" text="ستظهر تحديثات الدرجات وتنبيهات التراجع هنا عند حدوثها."/> : resource.data.map(event => <article className="event-row" key={event.id}><span className="event-icon">{event.event_type === 'GROUP_DECLINE' ? <TrendingDown size={19}/> : <CheckCheck size={19}/>}</span><div><h3>{event.event_type === 'GROUP_DECLINE' ? 'رُصد تراجع في التحصيل' : event.event_type === 'EXCEL_IMPORTED' ? 'اكتمل استيراد Excel' : 'تم تحديث الدرجات'}</h3><p>{event.event_type === 'GROUP_DECLINE' ? `${event.subject_id ? w.context.subjects.find(s => s.id === event.subject_id)?.name_ar : 'المعدل الجماعي'} · الشعبة ${w.context.sections.find(s => s.id === event.section_id)?.name_ar} · ${num(event.payload.delta_pp,2)} نقطة مئوية` : event.event_type === 'EXCEL_IMPORTED' ? `${num(event.payload.rows)} صف معتمد` : `${num(event.payload.count)} سجل درجة في ${w.context.packages.find(p => p.id === event.package_id)?.name_ar}`}</p><time dateTime={event.created_at}>{date(event.created_at)}</time></div><span className={`badge ${event.resolved_at ? 'green' : event.event_type === 'GROUP_DECLINE' ? 'red' : 'gray'}`}>{event.resolved_at ? 'تمت المعالجة' : event.event_type === 'GROUP_DECLINE' ? 'للمتابعة' : 'مكتمل'}</span></article>)}
    </Panel>}</>;
}
