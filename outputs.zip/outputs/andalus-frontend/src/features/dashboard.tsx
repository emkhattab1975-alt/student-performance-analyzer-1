'use client';
import Link from 'next/link';
import { ArrowLeft, BookOpen, ChartNoAxesCombined, CheckCheck, FileChartColumnIncreasing, Sparkles, Users } from 'lucide-react';
import { Filters, useWorkspace } from '@/components/shell';
import { Empty, Failure, Loading, PageTitle, Panel, Percent } from '@/components/ui';
import { AchievementChart, LevelsChart, TrendChart } from '@/components/charts';
import { useResource } from '@/hooks/use-resource';
import { query } from '@/lib/api';
import { num, pct } from '@/lib/format';
import type { Dashboard as DashboardData } from '@/lib/types';

export default function Dashboard() {
  const w = useWorkspace();
  const resource = useResource<DashboardData>(w.packageId ? `${w.base}/packages/${w.packageId}/dashboard?${query({ stage_id: w.stage, section_id: w.section, core_only: w.coreOnly })}` : null);
  const data = resource.data;
  const subjectName = (id: string) => w.context.subjects.find(s => s.id === id)?.name_ar || 'مادة';
  return <>
    <PageTitle title="لوحة التحكم" description={w.context.role === 'TEACHER' ? 'ملخص أداء شعبك وموادك المسندة، في مكان واحد.' : 'تابع التحصيل الدراسي، واكتشف فرص التحسن في الوقت المناسب.'} actions={<Link className="button" href="/reports"><FileChartColumnIncreasing size={16}/>استعراض التقارير<ArrowLeft size={15}/></Link>}/>
    <div className="welcome-banner"><div><h2>مرحباً، {w.me.display_name}</h2><p>كل نتيجة نقرأها اليوم، فرصة نصنعها للغد.</p></div><span className="banner-icon"><Sparkles size={27}/></span></div>
    <Filters/>
    {resource.error ? <Failure message={resource.error} retry={resource.reload}/> : resource.loading || !data ? <Loading/> : <>
      <div className="kpi-grid">
        <Kpi label={w.context.role === 'TEACHER' ? 'طلاب الشعب المسندة' : 'الطلاب المسجلون'} value={num(data.student_count)} caption="في الباقة والنطاق المحددين" icon={<Users size={18}/>} color="blue"/>
        <Kpi label="متوسط التحصيل" value={pct(data.achievement)} caption="متوسط نسب المواد والشعب بالتساوي" icon={<ChartNoAxesCombined size={18}/>} color="green"/>
        <Kpi label="النتائج المحتسبة" value={num(data.record_count)} caption="درجات الحاضرين والتعويض المعتمد" icon={<CheckCheck size={18}/>} color="red"/>
        <Kpi label="المواد في التحليل" value={num(data.subject_count)} caption={`${num(data.section_count)} شعبة ضمن النطاق الحالي`} icon={<BookOpen size={18}/>} color="purple"/>
      </div>
      {!data.has_results && <Panel><Empty title="بانتظار أولى النتائج" text={w.context.role === 'TEACHER' ? 'ستظهر تحليلات موادك عند اعتماد درجاتها. إذا لم تظهر شعبك، راجع مدير النظام بشأن الإسناد.' : 'لا توجد درجات محتسبة في هذا النطاق. أضف الطلاب والنهايات والدرجات، أو اختر باقة أخرى.'}>{w.context.role !== 'TEACHER' && <Link href="/records" className="button primary">إدارة البيانات والدرجات<ArrowLeft size={15}/></Link>}</Empty></Panel>}
      <div className="dashboard-charts" style={{ marginTop: data.has_results ? 0 : 22 }}>
        <Panel title="التحصيل حسب المادة" subtitle="متوسط تحصيل الشعب لكل مادة · من ١٠٠٪" action={<span className="badge green">{w.coreOnly ? 'المواد الأساسية' : 'جميع المواد المحتسبة'}</span>}>
          {data.has_results ? <AchievementChart data={data.subject_achievements.map(s => ({ name: subjectName(s.subject_id), value: s.achievement === null ? null : Number(s.achievement) }))}/> : <Empty title="لا توجد نسب لعرضها" text="نستخدم الدرجات المعتمدة فقط لإنشاء هذا الرسم."/>}
        </Panel>
        {w.context.role !== 'TEACHER' ? <Panel title="مستويات الطلاب" subtitle="بحسب النسبة الإجمالية وحدود المستويات المعتمدة">
          <LevelsChart data={data.levels}/>
        </Panel> : <Panel title="تغطية البيانات" subtitle="حالات الدرجات في موادك المسندة"><div className="panel-pad stack"><Coverage label="نتائج محتسبة" count={data.record_count} color="green"/><Coverage label="غياب / غش / عذر مستثنى" count={data.excluded_record_count} color="red"/><Coverage label="مواد غير مسجلة" count={data.blank_record_count} color="gray"/><p className="form-note">هذه أعداد سجلات درجات؛ قد يتكرر الطالب في أكثر من مادة.</p></div></Panel>}
      </div>
      <Panel title="التحصيل عبر الباقات" subtitle="متابعة اتجاه التحصيل في النطاق المحدد" action={<Link href="/comparisons" className="button small">مقارنة تفصيلية<ArrowLeft size={13}/></Link>}>
        {data.trend.some(t => t.achievement !== null) ? <TrendChart data={data.trend.map(t => ({ name: t.name, value: t.achievement === null ? null : Number(t.achievement) }))}/> : <Empty title="الرحلة تبدأ من أول باقة" text="تظهر النقاط عند توفر نتائج محتسبة؛ الباقات الفارغة لا تُعرض كصفر."/>}
        <p className="chart-caption">عرض اتجاه عام؛ مقارنة القيمة المضافة تستخدم المواد المشتركة بين الباقتين في صفحة المقارنة.</p>
      </Panel>
      {data.statistics.length > 0 && <Panel title="لمحة عن أداء الشعب" subtitle="التحصيل والنجاح للحاضرين المعتمدين فقط" action={<Link href="/reports" className="button small">عرض الكل<ArrowLeft size={13}/></Link>}><div className="table-wrap"><table><thead><tr><th>الصف / الشعبة</th><th>المادة</th><th>التحصيل</th><th>النجاح</th><th>المحتسبون</th></tr></thead><tbody>{data.statistics.slice(0,6).map(row => <tr key={row.section_id+row.subject_id}><td>{w.context.stages.find(s => s.id === row.stage_id)?.name_ar} / {w.context.sections.find(s => s.id === row.section_id)?.name_ar}</td><td>{subjectName(row.subject_id)}</td><td><Percent value={row.achievement}/></td><td><Percent value={row.pass_rate}/></td><td>{num(row.included_students)} <span className="muted">من {num(row.total_students)}</span></td></tr>)}</tbody></table></div></Panel>}
    </>}
  </>;
}
function Kpi({ label, value, caption, icon, color }: { label: string; value: string; caption: string; icon: React.ReactNode; color: string }) { return <section className="kpi"><div className="kpi-top"><span className="kpi-label">{label}</span><span className={`kpi-icon ${color}`}>{icon}</span></div><div className="kpi-value">{value}</div><p className="kpi-caption">{caption}</p></section>; }
function Coverage({ label, count, color }: { label: string; count: number; color: string }) { return <div className="kpi-top"><span>{label}</span><span className={`badge ${color}`}>{num(count)}</span></div>; }
