'use client';
import { Fragment, useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import { Filters, useWorkspace } from '@/components/shell';
import { Empty, ExportActions, Failure, Loading, PageTitle, Panel, Percent, PrintLegend, ScoreBadge } from '@/components/ui';
import { useResource } from '@/hooks/use-resource';
import { query } from '@/lib/api';
import { num } from '@/lib/format';
import type { Stats, StudentResult, SubjectReport } from '@/lib/types';

export default function Reports() {
  const w = useWorkspace();
  const [tab, setTab] = useState(w.context.role === 'TEACHER' ? 'subject' : 'ranking');
  return <>
    <PageTitle title="التقارير والكشوف" description="نتائج معتمدة، وتفاصيل واضحة لكل مادة وشعبة."/>
    <div className="tabs no-print" role="tablist" aria-label="نوع التقرير">
      {w.context.role !== 'TEACHER' && <button role="tab" aria-selected={tab === 'ranking'} className={`tab ${tab === 'ranking' ? 'active' : ''}`} onClick={() => setTab('ranking')}>ترتيب الطلاب</button>}
      <button role="tab" aria-selected={tab === 'statistics'} className={`tab ${tab === 'statistics' ? 'active' : ''}`} onClick={() => setTab('statistics')}>التحصيل والنجاح</button>
      <button role="tab" aria-selected={tab === 'subject'} className={`tab ${tab === 'subject' ? 'active' : ''}`} onClick={() => setTab('subject')}>كشف مادة</button>
    </div>
    <Filters core={tab === 'statistics'}/>
    <div className="report-context">{w.context.packages.find(p => p.id === w.packageId)?.name_ar}{w.stage && ` · ${w.context.stages.find(s => s.id === w.stage)?.name_ar}`}{w.section && ` · الشعبة ${w.context.sections.find(s => s.id === w.section)?.name_ar}`}</div>
    {tab === 'ranking' && w.context.role !== 'TEACHER' ? <Ranking/> : tab === 'statistics' ? <Statistics/> : <SubjectSheet/>}
  </>;
}

function Ranking() {
  const w = useWorkspace();
  const [search, setSearch] = useState(''), [expanded, setExpanded] = useState<string | null>(null);
  const resource = useResource<StudentResult[]>(`${w.base}/packages/${w.packageId}/students?${query({ stage_id: w.stage, section_id: w.section })}`);
  if (resource.loading) return <Loading/>;
  if (resource.error) return <Failure message={resource.error} retry={resource.reload}/>;
  const rows = (resource.data || []).filter(row => row.name.includes(search) || row.personal_number.includes(search));
  const section = (id: string) => w.context.sections.find(s => s.id === id)?.name_ar || '';
  const stage = (id: string) => w.context.stages.find(s => s.id === id)?.name_ar || '';
  const csv = [['الاسم', 'الرقم الشخصي', 'الصف', 'الشعبة', 'المجموع', 'النهاية المحتسبة', 'النسبة', 'المستوى', 'ترتيب الشعبة', 'ترتيب المرحلة', 'ملاحظات'], ...rows.map(row => [row.name, row.personal_number, stage(row.stage_id), section(row.section_id), row.total + row.marker, row.denominator, row.percentage === null ? null : row.percentage + row.marker, row.level, row.section_rank, row.stage_rank, row.flags.join(' / ')])];
  return <Panel title="كشف ترتيب الطلاب" subtitle="الترتيب داخل الشعبة والمرحلة / المسار · التعادل يمنح الرتبة نفسها" action={<div className="actions no-print"><ExportActions filename="ترتيب-الطلاب.csv" rows={csv}/></div>}>
    <div className="panel-body no-print"><label className="table-search"><Search size={15}/><span className="sr-only">ابحث باسم الطالب أو رقمه الشخصي</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث بالاسم أو الرقم الشخصي"/></label></div>
    {!rows.length ? <Empty title={search ? 'لا توجد نتائج للبحث' : 'لا يوجد طلاب في هذا النطاق'} text="اختر باقة أو شعبة أخرى، أو أضف انتماءات الطلاب أولاً."/> : <div className="table-wrap"><table><thead><tr><th>الطالب</th><th>الصف / الشعبة</th><th>المجموع</th><th>النسبة</th><th>المستوى</th><th>ترتيب الشعبة</th><th>ترتيب المرحلة</th><th className="no-print">التفاصيل</th></tr></thead><tbody>{rows.map(row => <Fragment key={row.enrollment_id}>
      <tr><td><div className="student-cell"><span className="avatar">{row.name[0]}</span><div><strong>{row.name}</strong><div className="table-muted" dir="ltr">{row.personal_number}</div></div>{row.flags.map(flag => <span className="badge red" key={flag}>{flag === 'غائب' ? 'غياب' : flag}</span>)}</div></td><td>{stage(row.stage_id)} / {section(row.section_id)}</td><td>{num(row.total,2)}{row.marker}<span className="table-muted"> / {num(row.denominator,2)}</span></td><td><Percent value={row.percentage}/>{row.marker}</td><td><span className={`badge ${row.level === 'ممتاز' ? 'green' : row.level === 'راسب' ? 'red' : 'gray'}`}>{row.level}</span></td><td>{row.section_rank === null ? 'بلا ترتيب' : num(row.section_rank)}</td><td>{row.stage_rank === null ? 'بلا ترتيب' : num(row.stage_rank)}</td><td className="no-print"><button className="icon-button" aria-label={`تفاصيل ${row.name}`} aria-expanded={expanded === row.enrollment_id} onClick={() => setExpanded(expanded === row.enrollment_id ? null : row.enrollment_id)}><ChevronDown size={17}/></button></td></tr>
      {expanded === row.enrollment_id && <tr className="detail-row"><td colSpan={8}><div className="detail-grid">{row.subjects.map(mark => <div key={mark.subject_id} className="detail-item"><span>{w.context.subjects.find(s => s.id === mark.subject_id)?.name_ar}</span><ScoreBadge mark={mark}/></div>)}</div></td></tr>}
    </Fragment>)}</tbody></table></div>}
    <div className="result-count">عدد الطلاب في الكشف: {num(rows.length)} · النسبة والترتيب يشملان المواد غير الأساسية، عدا المواد المستبعدة.</div><PrintLegend/>
  </Panel>;
}

function Statistics() {
  const w = useWorkspace();
  const resource = useResource<Stats[]>(`${w.base}/packages/${w.packageId}/statistics?${query({ stage_id: w.stage, section_id: w.section, core_only: w.coreOnly })}`);
  const subject = (id: string) => w.context.subjects.find(s => s.id === id)?.name_ar || '';
  const section = (id: string) => { const s = w.context.sections.find(x => x.id === id); return `${w.context.stages.find(g => g.id === s?.stage_id)?.name_ar} / ${s?.name_ar}`; };
  if (resource.loading) return <Loading/>;
  if (resource.error) return <Failure message={resource.error} retry={resource.reload}/>;
  const rows = resource.data || [];
  return <Panel title="نسب التحصيل والنجاح" subtitle={w.coreOnly ? 'المواد الأساسية فقط' : 'جميع المواد المحتسبة'} action={<div className="actions no-print"><ExportActions filename="التحصيل-والنجاح.csv" rows={[
    ['الشعبة','المادة','التحصيل','النجاح','المحتسبون','إجمالي الطلاب','غياب','غش','معذور','غير مسجلة'], ...rows.map(r => [section(r.section_id),subject(r.subject_id),r.achievement,r.pass_rate,r.included_students,r.total_students,r.absent,r.cheating,r.excused,r.blank])
  ]}/></div>}>
    {!rows.length ? <Empty/> : <div className="table-wrap"><table><thead><tr><th>الصف / الشعبة</th><th>المادة</th><th>التحصيل</th><th>النجاح</th><th>المحتسبون</th><th>غياب</th><th>غش</th><th>معذور</th><th>غير مسجلة</th></tr></thead><tbody>{rows.map(r => <Fragment key={r.section_id+r.subject_id}><tr><td>{section(r.section_id)}</td><td><strong>{subject(r.subject_id)}</strong></td><td><Percent value={r.achievement}/></td><td><Percent value={r.pass_rate}/></td><td>{num(r.included_students)} / {num(r.total_students)}</td><td>{num(r.absent)}</td><td>{num(r.cheating)}</td><td>{num(r.excused)}</td><td>{num(r.blank)}</td></tr><tr><td colSpan={9} className="coverage">{r.coverage_text}</td></tr></Fragment>)}</tbody></table></div>}<PrintLegend/>
  </Panel>;
}

function SubjectSheet() {
  const w = useWorkspace();
  const [selection, setSelection] = useState('');
  const sections = w.context.sections.filter(s => (!w.stage || s.stage_id === w.stage) && (!w.section || s.id === w.section));
  const options = sections.flatMap(section => w.context.stage_subjects.filter(c => c.stage_id === section.stage_id && (w.context.role !== 'TEACHER' || w.context.assignments.some(a => a.package_id === w.packageId && a.section_id === section.id && a.stage_subject_id === c.id))).map(c => ({ key: `${section.id}:${c.id}`, section: section.id, curriculum: c.id, name: `${w.context.subjects.find(s => s.id === c.subject_id)?.name_ar} · ${w.context.stages.find(s => s.id === section.stage_id)?.name_ar} / ${section.name_ar}` })));
  const selected = options.find(o => o.key === selection) || options[0];
  const resource = useResource<SubjectReport>(selected ? `${w.base}/packages/${w.packageId}/subjects/${selected.curriculum}/sections/${selected.section}` : null);
  return <Panel title="كشف درجات مادة" subtitle="الحالات الأصلية والدرجات التعويضية، دون تحويل الغياب إلى صفر في العرض" action={resource.data && <div className="actions no-print"><ExportActions filename="كشف-المادة.csv" rows={[
    ['الطالب','الدرجة أو الحالة','النهاية','الدور المعتمد'], ...resource.data.students.map(r => [r.name,r.mark.display,r.mark.maximum,r.mark.round_used])
  ]}/></div>}>
    <div className="panel-body no-print"><label className="field"><span>المادة والشعبة</span><select value={selected?.key || ''} onChange={e => setSelection(e.target.value)}><option value="" disabled>اختر المادة والشعبة</option>{options.map(o => <option key={o.key} value={o.key}>{o.name}</option>)}</select></label></div>
    {!selected ? <Empty title="لا توجد مواد متاحة في النطاق" text="راجع إعداد المواد والأنصبة للباقة المختارة."/> : resource.loading ? <Loading/> : resource.error ? <Failure message={resource.error} retry={resource.reload}/> : resource.data && <>
      <div className="panel-body"><strong>{selected.name}</strong><div className="actions" style={{ marginTop: 10 }}><span className="badge green">التحصيل <Percent value={resource.data.achievement}/></span><span className="badge">النجاح <Percent value={resource.data.pass_rate}/></span></div></div>
      {!resource.data.students.length ? <Empty/> : <div className="table-wrap"><table><thead><tr><th>الطالب</th><th>الدرجة / الحالة</th><th>النهاية</th><th>ملاحظات</th></tr></thead><tbody>{resource.data.students.map(row => <tr key={row.student_id}><td><strong>{row.name}</strong></td><td><ScoreBadge mark={row.mark}/></td><td>{num(row.mark.maximum,2)}</td><td className="muted">{row.mark.round_used === 2 ? 'درجة تعويضية معتمدة' : row.mark.second_round_status ? `حالة الدور الثاني: ${row.mark.second_round_status === 'ABSENT' ? 'غائب' : row.mark.second_round_status === 'CHEATING' ? 'غش' : 'معذور'}` : row.mark.is_excluded ? 'المادة مستبعدة من جميع الحسابات' : '—'}</td></tr>)}</tbody></table></div>}
      <p className="coverage">{resource.data.coverage_text}</p>
    </>}<PrintLegend/>
  </Panel>;
}
