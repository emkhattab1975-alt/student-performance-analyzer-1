'use client';
import { useEffect, useState } from 'react';
import { Download, Upload, CheckCheck } from 'lucide-react';
import { useWorkspace } from '@/components/shell';
import { PageTitle, Panel, Notice } from '@/components/ui';
import { api, send } from '@/lib/api';
import { date, downloadCsv, num } from '@/lib/format';

type Issue = { row: number; column: string; message: string };
type Change = { action: string; entity: string; before?: unknown; after?: unknown };
type Preview = { id: string; filename: string; kind: string; valid: boolean; row_count: number; change_count: number; replacement_count: number; errors: Issue[]; rows: {row:number; values:Record<string,string>; changes:Change[]}[] };
type Receipt = { saved_rows: number; change_count: number; credentials: {username:string;name:string;password:string}[] };
type History = {id:string;kind:string;filename:string;status:string;created_at:string;row_count:number};
const kinds = [ ['sections','الشعب'], ['subjects','المواد وربطها بالصفوف'], ['teachers','حسابات المعلمين'], ['students','الطلاب وانتماءاتهم'], ['maxima','الدرجات النهائية'], ['assignments','أنصبة المعلمين'], ['grades','درجات الطلاب'] ];
const adminKinds = ['sections','subjects','teachers'];
const statusNames: Record<string,string> = {READY:'بانتظار الاعتماد',INVALID:'يحتوي أخطاء',APPLIED:'تم الاعتماد',PRESENT:'حاضر',ABSENT:'غائب',CHEATING:'غش',EXCUSED:'معذور'};
function describe(value: unknown): string {
  if (value == null) return 'غير مسجل';
  if (typeof value === 'object') { const v = value as {status?:string;score?:string}; return v.status === 'PRESENT' ? String(v.score) : statusNames[v.status || ''] || 'فارغ'; }
  return String(value);
}
function saveWorkbook(file: {filename:string;content:string}) {
  const bytes = Uint8Array.from(atob(file.content), c => c.charCodeAt(0));
  const url = URL.createObjectURL(new Blob([bytes], {type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));
  const link = document.createElement('a'); link.href=url; link.download=file.filename; link.click(); URL.revokeObjectURL(url);
}
export default function Imports() {
  const w=useWorkspace();
  // Remount on scope change so an old preview can never be approved in another year/package.
  return <ImportScope key={w.year + ':' + w.packageId}/>;
}
function ImportScope() {
  const w=useWorkspace();
  const [kind,setKind]=useState(w.context.role==='SYSTEM_ADMIN'?'sections':'students');
  const [file,setFile]=useState<File|null>(null), [round,setRound]=useState('1');
  const [preview,setPreview]=useState<Preview|null>(null), [receipt,setReceipt]=useState<Receipt|null>(null);
  const [error,setError]=useState(''), [busy,setBusy]=useState(false), [ack,setAck]=useState(false), [page,setPage]=useState(0);
  const [history,setHistory]=useState<History[]>([]);
  const isPackage = !adminKinds.includes(kind);
  async function refreshHistory() { try { setHistory(await api<History[]>(w.base+'/imports')); } catch { /* main request surfaces errors */ } }
  useEffect(()=>{void refreshHistory();},[w.base]); // eslint-disable-line react-hooks/exhaustive-deps
  function reset() {setPreview(null);setReceipt(null);setAck(false);setError('');setPage(0);}
  async function template() {
    setBusy(true);setError('');
    try {saveWorkbook(await api(w.base+'/imports/templates/'+kind+(isPackage?'?package_id='+w.packageId:'')));}
    catch(e){setError((e as Error).message);} finally{setBusy(false);}
  }
  async function inspect() {
    if (!file) return;
    reset();setBusy(true);
    try {
      if (!file.name.toLowerCase().endsWith('.xlsx')) throw new Error('اختر ملف .xlsx. احفظ الملفات القديمة بهذه الصيغة من Excel أولاً.');
      if(file.size>1000000) throw new Error('الحد الأقصى للملف ١ ميغابايت؛ قسّمه إلى ملفات أصغر.');
      const content=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(new Error('تعذرت قراءة الملف'));reader.readAsDataURL(file);});
      setPreview(await send<Preview>(w.base+'/imports/preview/'+kind,{filename:file.name,content,package_id:isPackage?w.packageId:null,round:Number(round)}));
      await refreshHistory();
    }catch(e){setError((e as Error).message);}finally{setBusy(false);}
  }
  async function approve() {
    if (!preview) return;
    setBusy(true);setError('');
    try {setReceipt(await send<Receipt>(w.base+'/imports/'+preview.id+'/approve',{acknowledge_replacement:ack}));setPreview(null);await refreshHistory();}
    catch(e){setError((e as Error).message);}finally{setBusy(false);}
  }
  const headings = preview?.rows.length ? Object.keys(preview.rows[0].values) : [];
  return <>
    <PageTitle title="استيراد Excel" description="نزّل القالب، أدخل البيانات الحقيقية، ثم عاين الأخطاء والتغييرات قبل الاعتماد."/>
    <Notice>الترتيب المقترح: الشعب ← المواد ← حسابات المعلمين ← الطلاب ← النهايات ← الأنصبة ← الدرجات. ملف واحد لكل نوع، وورقة بيانات واحدة. لا تُحذف السجلات غير الواردة في الملف.</Notice>
    <Panel title="١. اختيار نطاق الاستيراد"><div className="panel-body form-stack">
      <div className="form-grid"><label className="field"><span>نوع البيانات</span><select disabled={busy || Boolean(receipt?.credentials.length)} value={kind} onChange={e=>{setKind(e.target.value);setFile(null);reset();}}>{kinds.filter(([id])=>w.context.role==='SYSTEM_ADMIN'||!adminKinds.includes(id)).map(([id,name])=><option key={id} value={id}>{name}</option>)}</select></label>
      {isPackage && <label className="field"><span>الباقة المستهدفة</span><select disabled={busy || Boolean(receipt?.credentials.length)} value={w.packageId} onChange={e=>w.setPackageId(e.target.value)}>{w.context.packages.map(p=><option key={p.id} value={p.id}>{p.name_ar}</option>)}</select></label>}
      {kind==='grades' && <label className="field"><span>الدور</span><select disabled={busy} value={round} onChange={e=>{setRound(e.target.value);reset();}}><option value="1">الدور الأول</option>{w.context.packages.find(p=>p.id===w.packageId)?.has_second_round && <option value="2">الدور الثاني للمعذورين فقط</option>}</select></label>}</div>
      <p className="muted">العام الدراسي: {w.context.year_code}. الحد الأقصى: ٢٠٠٠ صف، و٥٠٠٠ خلية درجات، و٢٠٠ حساب معلم لكل ملف.</p>
      <button className="button" disabled={busy} onClick={template}><Download size={16}/>تنزيل قالب Excel فارغ</button>
      {kind==='teachers' && <Notice>لمدير النظام فقط. الأعمدة: اسم المستخدم، اسم المعلم، رمز الموظف، كلمة المرور. يمكن توحيد كلمة المرور لجميع المعلمين: 6 إلى 256 محرفاً دون اشتراط رموز أو أحرف كبيرة. اكتبها كنص؛ تزال المسافات الطرفية. الخلية الفارغة تولّد كلمة عشوائية للحساب الجديد فقط وتُبقي كلمة الحساب الموجود. كلمات المرور المحددة في الملف تُخفى ولا تُعاد في التقرير. للحساب الموجود: تطابق اسم المستخدم ورمز الموظف واسم المعلم مطلوب؛ كلمة محددة تستبدل الحالية بعد التأكيد وتنهي جلساته السابقة. كلمة المرور مشتركة بين أعوام الحساب.</Notice>}
      {kind==='grades' && <Notice>أعمدة المواد غير المطلوبة يمكن حذفها من الملف. الخلية الفارغة داخل عمود مرفوع تستبدل الدرجة السابقة بفراغ. غ = غائب، غش = غش، م = معذور. عرّف النهايات أولاً.</Notice>}
    </div></Panel>
    <Panel title="٢. رفع الملف والمعاينة"><div className="panel-body form-stack"><label className="field"><span>ملف Excel (.xlsx)</span><input key={kind} type="file" accept=".xlsx" disabled={busy || Boolean(receipt?.credentials.length)} onChange={e=>{setFile(e.target.files?.[0]||null);reset();}}/></label><button className="button primary" disabled={!file||busy||Boolean(receipt?.credentials.length)} onClick={inspect}><Upload size={16}/>{busy?'جارٍ التحقق والمعالجة…':'معاينة والتحقق من الأخطاء'}</button><p className="muted">المعاينة لا تحفظ الطلاب أو الدرجات أو الحسابات. يُحتفظ بإصدار الملف وتقرير التحقق في العام الحالي.</p></div></Panel>
    {error && <div className="error-box" role="alert">{error}</div>}
    {preview && <Panel title="٣. مراجعة نتيجة التحقق"><div className="panel-body form-stack"><p>{preview.filename} · {num(preview.row_count)} صف · {num(preview.change_count)} تغيير · {num(preview.replacement_count)} استبدال · {num(preview.errors.length)} خطأ</p>
      {preview.errors.length>0 && <><div className="error-box">لم يُعتمد الملف. صحّح جميع الأخطاء في Excel ثم ارفعه مجدداً.</div><button className="button" onClick={()=>downloadCsv('أخطاء-الاستيراد.csv',[['الصف','العمود','الخطأ'],...preview.errors.map(e=>[e.row,e.column,e.message])])}>تنزيل تقرير الأخطاء</button><div className="table-wrap"><table><thead><tr><th>الصف في Excel</th><th>العمود</th><th>الخطأ</th></tr></thead><tbody>{preview.errors.slice(0,200).map((e,i)=><tr key={i}><td>{e.row}</td><td>{e.column||'السجل'}</td><td>{e.message}</td></tr>)}</tbody></table></div>{preview.errors.length>200&&<p>تُعرض أول ٢٠٠ رسالة؛ التقرير المنزّل يشمل جميع الأخطاء.</p>}</>}
      <div className="table-wrap"><table><thead><tr><th>صف Excel</th>{headings.map(h=><th key={h}>{h}</th>)}<th>التغييرات المقترحة</th></tr></thead><tbody>{preview.rows.slice(page*25,(page+1)*25).map(row=><tr key={row.row}><td>{row.row}</td>{headings.map(h=><td key={h}>{row.values[h]||'—'}</td>)}<td>{row.changes.length?row.changes.map((c,i)=><div key={i}>{c.action} · {c.entity}{c.action==='استبدال'&&<>: {describe(c.before)} ← {describe(c.after)}</>}</div>):'دون تغيير / راجع الأخطاء'}</td></tr>)}</tbody></table></div>
      <div className="actions"><button className="button" disabled={page===0} onClick={()=>setPage(page-1)}>السابق</button><span>صفحة {num(page+1)} من {num(Math.ceil(preview.row_count/25))}</span><button className="button" disabled={(page+1)*25>=preview.row_count} onClick={()=>setPage(page+1)}>التالي</button></div>
      {preview.replacement_count>0&&<label className="toggle"><input type="checkbox" checked={ack} onChange={e=>setAck(e.target.checked)}/>راجعت القيم السابقة والجديدة وأوافق على الاستبدال الموضح فقط.</label>}
      <button className="button primary" disabled={busy||!preview.valid||(preview.replacement_count>0&&!ack)} onClick={approve}><CheckCheck size={16}/>اعتماد {num(preview.row_count)} صف</button><p className="muted">لا تُقبل معاينة مضى عليها ٢٤ ساعة أو تغيرت بياناتها. أي فشل أثناء الاعتماد يلغي العملية كاملة.</p>
    </div></Panel>}
    {receipt && <Panel title="تم اعتماد الملف"><div className="panel-body form-stack"><div className="notice">اعتُمد {num(receipt.saved_rows)} صف، بإجمالي {num(receipt.change_count)} تغيير. يمكنك مراجعة النتائج والتقارير الآن.</div>
      {receipt.credentials.length>0&&<><Notice>بيانات الدخول تظهر مرة واحدة فقط. لا تُرسل الملف لجميع المعلمين؛ سلّم كل معلم بياناته وحده. يمكن لمدير النظام إعادة تعيين كلمة المرور لاحقاً.</Notice><button className="button primary" onClick={()=>downloadCsv('حسابات-المعلمين-سري.csv',[['الاسم','اسم المستخدم','كلمة المرور'],...receipt.credentials.map(c=>[c.name,c.username,c.password])])}><Download size={16}/>تنزيل بيانات دخول المعلمين</button><div className="table-wrap"><table><thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>كلمة المرور</th></tr></thead><tbody>{receipt.credentials.map(c=><tr key={c.username}><td>{c.name}</td><td dir="ltr">{c.username}</td><td dir="ltr">{c.password}</td></tr>)}</tbody></table></div><button className="button" onClick={()=>setReceipt(null)}>حفظت بيانات الدخول، إخفاؤها الآن</button></>}
      {!receipt.credentials.length&&<button className="button" onClick={()=>w.refreshContext()}>تحديث قوائم المدرسة</button>}
    </div></Panel>}
    <Panel title="آخر ملفاتك في العام الدراسي"><div className="table-wrap"><table><thead><tr><th>الملف</th><th>النوع</th><th>الصفوف</th><th>الحالة</th><th>وقت الرفع</th></tr></thead><tbody>{history.map(h=><tr key={h.id}><td>{h.filename}</td><td>{kinds.find(([id])=>id===h.kind)?.[1]}</td><td>{num(h.row_count)}</td><td>{statusNames[h.status]}</td><td>{date(h.created_at)}</td></tr>)}</tbody></table></div></Panel>
  </>;
}
