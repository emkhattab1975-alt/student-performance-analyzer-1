'use client';
import { useEffect, useRef, useState } from 'react';
import { Pencil, Trash2, X } from 'lucide-react';
import { useWorkspace } from '@/components/shell';
import { Empty, Failure, Loading, Notice, PageTitle, Panel } from '@/components/ui';
import { useResource } from '@/hooks/use-resource';
import { send } from '@/lib/api';
import { num } from '@/lib/format';

type Row={id:string;label:string;details:string;values:Record<string,string|number|boolean|null>};
type Field={name:string;label:string;type:string;required:boolean;options:{value:string;label:string}[]|null};
type Listing={revision:string;rows:Row[];fields:Field[];delete_action:string;notice:string};
type Preview={summary?:{label:string;count:number}[];packages?:string[];total_deleted?:number;count:number;action:string;curriculum_links:number;token:string|null;items:{id:string;label:string}[];blocked:{id:string;label:string;reason:string}[]};
const kinds=[['sections','الشعب'],['subjects','المواد'],['teachers','حسابات المعلمين'],['students','الطلاب'],['enrollments','أسماء الطلاب وشعبهم'],['scores','الدرجات'],['assignments','أنصبة المعلمين'],['maxima','الدرجات النهائية']];
const annual=['sections','subjects','teachers','students'];
const adminOnly=['sections','subjects','teachers'];
function Dialog({title,onClose,children}:{title:string;onClose:()=>void;children:React.ReactNode}) {
  const ref=useRef<HTMLDialogElement>(null);
  useEffect(()=>{const el=ref.current;el?.showModal();return()=>el?.close();},[]);
  return <dialog ref={ref} className="dialog manage-dialog" onCancel={e=>{e.preventDefault();onClose();}}><div className="dialog-heading"><h2>{title}</h2><button className="icon-button" onClick={onClose} aria-label="إغلاق"><X size={20}/></button></div>{children}</dialog>;
}
export default function Management(){const w=useWorkspace();return <Manager key={w.year+':'+w.packageId}/>;}
function Manager(){
  const w=useWorkspace();
  const [kind,setKind]=useState(w.context.role==='SYSTEM_ADMIN'?'sections':'students');
  const [search,setSearch]=useState(''),[selected,setSelected]=useState<Set<string>>(new Set()),[page,setPage]=useState(0);
  const [editing,setEditing]=useState<Row|null>(null),[preview,setPreview]=useState<Preview|null>(null),[ack,setAck]=useState(false);
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[success,setSuccess]=useState('');
  const [scoreStatus,setScoreStatus]=useState('');
  const suffix=annual.includes(kind)?'':'?package_id='+w.packageId;
  const base=w.base+'/manage/'+kind;
  const resource=useResource<Listing>(base+suffix),data=resource.data;
  const filtered=(data?.rows||[]).filter(row=>(row.label+' '+row.details).toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  const visible=filtered.slice(page*25,(page+1)*25);
  const allSelected=filtered.length>0&&filtered.every(row=>selected.has(row.id));
  function reset(){setSelected(new Set());setPreview(null);setEditing(null);setAck(false);setError('');setSuccess('');setPage(0);}
  function refresh(){reset();resource.reload();}
  async function save(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault();if(!data||!editing)return;setBusy(true);setError('');
    const form=new FormData(e.currentTarget),values:Record<string,unknown>={};
    for(const f of data.fields) values[f.name]=f.type==='checkbox'?form.get(f.name)==='on':form.get(f.name);
    if(kind==='scores'){values.score_status=scoreStatus||null;values.score=scoreStatus==='PRESENT'?(form.get('score')||null):null;}
    try{await send(base+'/'+editing.id+suffix,{revision:data.revision,values},'PATCH');setEditing(null);setSelected(new Set());resource.reload();setSuccess('تم حفظ التعديل.');}
    catch(err){setError((err as Error).message);}finally{setBusy(false);}
  }
  async function review(ids:string[]){
    if(!data||!ids.length)return;setBusy(true);setError('');setSuccess('');setAck(false);
    try{setPreview(await send<Preview>(base+'/delete-preview'+suffix,{ids,revision:data.revision,cascade:w.context.role==='SYSTEM_ADMIN'}));}
    catch(err){setError((err as Error).message);}finally{setBusy(false);}
  }
  async function confirm(){
    if(!preview?.token||!ack)return;setBusy(true);setError('');
    try{const result=await send<{affected:number;total_deleted?:number}>(base+'/delete-confirm'+suffix,{token:preview.token});setPreview(null);setSelected(new Set());resource.reload();setSuccess('تم تنفيذ العملية على '+num(result.affected)+' سجل محدد.'+(result.total_deleted!==undefined?' إجمالي المحذوف مع السجلات التابعة: '+num(result.total_deleted)+'.':''));}
    catch(err){setError((err as Error).message);}finally{setBusy(false);}
  }
  return <><PageTitle title="تعديل وحذف السجلات" description="تعديل السجلات الحالية، أو مراجعة الحذف الفردي والجماعي داخل النطاق المعروض."/>
    <Panel title="نطاق العمل"><div className="panel-body form-stack"><div className="form-grid"><label className="field"><span>نوع السجلات</span><select aria-label="نوع السجلات" value={kind} disabled={busy} onChange={e=>{setKind(e.target.value);setSearch('');reset();}}>{kinds.filter(([id])=>w.context.role==='SYSTEM_ADMIN'||!adminOnly.includes(id)).map(([id,label])=><option key={id} value={id}>{label}</option>)}</select></label>
      {!annual.includes(kind)&&<label className="field"><span>الباقة المعروضة</span><select aria-label="الباقة المعروضة" disabled={busy} value={w.packageId} onChange={e=>w.setPackageId(e.target.value)}>{w.context.packages.map(p=><option key={p.id} value={p.id}>{p.name_ar}</option>)}</select></label>}
      <label className="field"><span>بحث في السجلات</span><input aria-label="بحث في السجلات" value={search} disabled={busy} onChange={e=>{setSearch(e.target.value);setSelected(new Set());setPage(0);setSuccess('');}}/></label></div>
      <Notice>العام: {w.context.year_code}. {annual.includes(kind)?'النطاق: جميع سجلات هذا النوع في العام الحالي.':'النطاق: الباقة المعروضة فقط.'} تحديد الكل يشمل نتائج البحث عبر صفحات الجدول، ولا يشمل أي عام أو باقة أخرى.</Notice>
      {data&&<p className="muted">{data.notice}</p>}
    </div></Panel>
    {error&&!editing&&!preview&&<Failure message={error}/>}{success&&<Notice>{success} حدّث الصفحة عند الانتقال إلى القوائم الأخرى لإظهار أحدث الأسماء.</Notice>}
    {resource.loading?<Loading/>:resource.error?<Failure message={resource.error} retry={refresh}/>:data&&<Panel title={kinds.find(([id])=>id===kind)?.[1]} action={<div className="actions"><span>{num(selected.size)} محدد من {num(filtered.length)}</span><button className="button" disabled={busy} onClick={refresh}>تحديث القائمة</button><button className="button danger-button" disabled={busy||!selected.size||selected.size>5000} onClick={()=>review([...selected])}><Trash2 size={16}/>{data.delete_action} المحدد</button></div>}>
      {!filtered.length?<Empty title="لا توجد سجلات مطابقة"/>:<><div className="table-wrap"><table><thead><tr><th><input type="checkbox" aria-label="تحديد الكل في نتائج البحث" checked={allSelected} disabled={busy||filtered.length>5000} onChange={e=>setSelected(e.target.checked?new Set(filtered.map(r=>r.id)):new Set())}/></th><th>السجل</th><th>التفاصيل</th><th>الإجراءات</th></tr></thead><tbody>{visible.map(row=><tr key={row.id}><td><input type="checkbox" aria-label={'تحديد '+row.label} disabled={busy} checked={selected.has(row.id)} onChange={e=>{const next=new Set(selected);if(e.target.checked)next.add(row.id);else next.delete(row.id);setSelected(next);}}/></td><td>{row.label}</td><td>{row.details}</td><td><div className="actions"><button className="button small" disabled={busy} onClick={()=>{setEditing(row);setScoreStatus(String(row.values.score_status||''));setError('');}}><Pencil size={14}/>تعديل</button><button className="button small danger-button" disabled={busy} onClick={()=>review([row.id])}>{data.delete_action}</button></div></td></tr>)}</tbody></table></div>
      <div className="panel-body actions"><button className="button" disabled={page===0} onClick={()=>setPage(page-1)}>السابق</button><span>صفحة {num(page+1)} من {num(Math.ceil(filtered.length/25))}</span><button className="button" disabled={(page+1)*25>=filtered.length} onClick={()=>setPage(page+1)}>التالي</button>{filtered.length>5000&&<span>ضيّق البحث؛ الحد الأقصى للعملية ٥٠٠٠ سجل.</span>}</div></>}
    </Panel>}
    {editing&&data&&<Dialog title={'تعديل '+editing.label} onClose={()=>{if(!busy){setEditing(null);setError('');}}}><form className="form-stack" onSubmit={save}><Notice>{editing.details}</Notice>{kind==='enrollments'&&<Notice>{data.notice}</Notice>}{data.fields.map(f=><label className={f.type==='checkbox'?'toggle':'field'} key={f.name}><span>{f.label}</span>{f.type==='checkbox'?<input type="checkbox" name={f.name} defaultChecked={Boolean(editing.values[f.name])}/>:f.type==='select'?<select name={f.name} required={f.required} defaultValue={String(editing.values[f.name]??'')} onChange={e=>{if(f.name==='score_status')setScoreStatus(e.target.value);}}>{f.options?.map(o=><option value={o.value} key={o.value}>{o.label}</option>)}</select>:<input name={f.name} type={f.type} step={f.type==='number'?'0.01':undefined} min={f.type==='number'?'0':undefined} defaultValue={String(editing.values[f.name]??'')} required={f.required||(kind==='scores'&&f.name==='score'&&scoreStatus==='PRESENT')} disabled={kind==='scores'&&f.name==='score'&&scoreStatus!=='PRESENT'}/> }</label>)}{error&&<Failure message={error}/>}<button className="button primary" disabled={busy}>حفظ التعديل</button></form></Dialog>}
    {preview&&<Dialog title="مراجعة العملية قبل التأكيد" onClose={()=>{if(!busy){setPreview(null);setError('');}}}><div className="form-stack"><Notice>{preview.action}. العدد: {num(preview.count)}. العام: {w.context.year_code}{!annual.includes(kind)&&' · '+w.context.packages.find(p=>p.id===w.packageId)?.name_ar}.</Notice>
      {preview.curriculum_links>0&&<p>سيُحذف أيضاً {num(preview.curriculum_links)} رابط مادة بصف، بعد التحقق من خلوها من النهايات والأنصبة.</p>}
      {preview.blocked.length>0?<><Failure message="لن يُحذف أي سجل من هذه المجموعة لوجود ارتباطات محمية. راجع الأسباب أو غيّر التحديد."/><ul>{preview.blocked.map(row=><li key={row.id}>{row.label}: {row.reason}</li>)}</ul></>:<>{preview.summary&&<><Notice>الحذف نهائي ويشمل السجلات التابعة التالية. حذف الطالب يزيل تشعيبه ودرجاته؛ حذف الشعبة يزيل تشعيب طلابها ودرجاتهم وأنصبتها دون حذف ملفات الطلاب؛ حذف المادة يزيل نهاياتها ودرجاتها وأنصبتها. حذف ملف المعلم يزيل عضويته وأنصبته في هذا العام فقط.</Notice><div className="table-wrap"><table><thead><tr><th>ما سيُحذف</th><th>العدد</th></tr></thead><tbody>{preview.summary.map(x=><tr key={x.label}><td>{x.label}</td><td>{num(x.count)}</td></tr>)}</tbody></table></div><p>الإجمالي مع السجلات التابعة: {num(preview.total_deleted||0)}</p>{!!preview.packages?.length&&<p>الباقات المتأثرة: {preview.packages.join('، ')}</p>}</>}<p>هذه العملية تُسجّل في سجل التدقيق. السجلات المحددة:</p><ul style={{maxHeight:200,overflow:'auto'}}>{preview.items.slice(0,100).map(row=><li key={row.id}>{row.label}</li>)}</ul>{preview.items.length>100&&<p>تُعرض أول ١٠٠ نتيجة من المجموعة المحددة.</p>}<label className="toggle"><input type="checkbox" checked={ack} onChange={e=>setAck(e.target.checked)}/>راجعت النطاق والأعداد والسجلات التابعة وأوافق على تنفيذ العملية.</label><button className="button danger-button" disabled={busy||!ack} onClick={confirm}>تأكيد {data?.delete_action}</button></>}
      {error&&<Failure message={error}/>}<button className="button" disabled={busy} onClick={()=>{setPreview(null);setError('');}}>إلغاء</button></div></Dialog>}
  </>;
}

type AcademicYearRow={id:string;code:string;starts_on:string;ends_on:string;is_current:boolean;can_manage:boolean;revision:string};
type YearPreview={id:string;code:string;token:string;counts:{label:string;count:number}[]};
export function Years(){
 const w=useWorkspace();const resource=useResource<AcademicYearRow[]>(w.base+'/years');
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[created,setCreated]=useState(''),[success,setSuccess]=useState('');
 const [editing,setEditing]=useState<AcademicYearRow|null>(null);
 const [preview,setPreview]=useState<YearPreview|null>(null),[typed,setTyped]=useState(''),[ack,setAck]=useState(false);
 async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();setBusy(true);setError('');const body=Object.fromEntries(new FormData(e.currentTarget));if(String(body.ends_on)<=String(body.starts_on)){setError('نهاية العام يجب أن تلي بدايته');setBusy(false);return;}try{const year=await send<{id:string}>(w.base+'/years',body);setCreated(year.id);resource.reload();}catch(err){setError((err as Error).message);}finally{setBusy(false);}}
 async function saveYear(e:React.FormEvent<HTMLFormElement>){e.preventDefault();if(!editing)return;setBusy(true);setError('');const body=Object.fromEntries(new FormData(e.currentTarget));if(String(body.ends_on)<=String(body.starts_on)){setError('نهاية العام يجب أن تلي بدايته');setBusy(false);return;}try{await send('years/'+editing.id+'/year-details',{...body,revision:editing.revision},'PATCH');window.location.assign('/years?year='+w.year);}catch(err){setError((err as Error).message);setBusy(false);}}
 async function current(y:AcademicYearRow){setBusy(true);setError('');try{await send('years/'+y.id+'/set-current',{});window.location.assign('/years?year='+w.year);}catch(err){setError((err as Error).message);setBusy(false);}}
 async function review(y:AcademicYearRow){setBusy(true);setError('');setTyped('');setAck(false);try{setPreview(await send<YearPreview>('years/'+y.id+'/delete-year-preview',{}));}catch(err){setError((err as Error).message);}finally{setBusy(false);}}
 async function remove(){if(!preview)return;setBusy(true);setError('');try{const result=await send<{backup:string}>('years/'+preview.id+'/delete-year-confirm',{token:preview.token,code:typed,acknowledge:ack});setPreview(null);setSuccess('تم حذف بيانات العام وحفظ النسخة الاحتياطية: '+result.backup);if(preview.id===w.year){window.location.assign('/years');}else{resource.reload();w.refreshContext();}}catch(err){setError((err as Error).message);}finally{setBusy(false);}}
 return <><PageTitle title="الأعوام الدراسية" description="إنشاء الأعوام وتعديل أسمائها وفتراتها، وتحديد العام الحالي وإدارة حذف الأعوام الأخرى."/>
 {error&&!preview&&!editing&&<Failure message={error}/>} {success&&<Notice>{success} حدّث الصفحة لتحديث قائمة الأعوام أعلى الشاشة.</Notice>}
 <Panel title="إدارة الأعوام الدراسية"><div className="panel-body form-stack"><Notice>العام الحالي محمي من الحذف. اختيار عام من القائمة أعلى الصفحة يغيّر العرض فقط؛ استخدم «تعيين كعام حالي» لتغيير العام المعتمد للنظام.</Notice>
 {resource.loading?<Loading/>:resource.error?<Failure message={resource.error} retry={resource.reload}/>:<div className="table-wrap"><table><thead><tr><th>العام الدراسي</th><th>الفترة</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>{resource.data?.map(y=><tr key={y.id}><td>{y.code}{y.id===w.year&&<small className="muted"> · المحدد للعرض</small>}</td><td>{y.starts_on} — {y.ends_on}</td><td>{y.is_current?'العام الحالي · محمي من الحذف':'عام آخر'}</td><td><div className="actions">{y.can_manage&&<button className="button small" disabled={busy} onClick={()=>{setEditing(y);setError('');}}><Pencil size={14}/>تعديل</button>}{y.can_manage&&!y.is_current&&<><button className="button small" disabled={busy} onClick={()=>current(y)}>تعيين كعام حالي</button><button className="button small danger-button" disabled={busy} onClick={()=>review(y)}><Trash2 size={14}/>حذف العام وبياناته</button></>}</div></td></tr>)}</tbody></table></div>}
 <p className="muted">حذف العام يزيل طلابه وشعبه ومواده ودرجاته وأنصبته وملفات استيراده وإعداداته وعضوياته. تُحفظ نسخة احتياطية قبل الحذف، وتبقى سجلات التدقيق وحسابات الدخول العامة لحماية تاريخ العمليات والأعوام الأخرى.</p></div></Panel>
 <Panel title="إضافة عام دراسي جديد"><div className="panel-body form-stack"><Notice>يُضاف حسابك كمدير نظام في العام الجديد دون نسخ بيانات الأعوام السابقة. إنشاء العام لا يغيّر العام الحالي تلقائياً.</Notice>{created?<><Notice>تم إنشاء العام وباقاته الأربع بنجاح.</Notice><button className="button primary" onClick={()=>window.location.assign('/dashboard?year='+created)}>الانتقال إلى العام الجديد</button></>:<form className="form-stack" onSubmit={submit}><label className="field"><span>اسم العام الدراسي</span><input name="code" required maxLength={20}/></label><label className="field"><span>بداية العام</span><input name="starts_on" type="date" required/></label><label className="field"><span>نهاية العام</span><input name="ends_on" type="date" required/></label><button className="button primary" disabled={busy}>إنشاء العام الدراسي</button></form>}</div></Panel>
 {editing&&<Dialog title={'تعديل العام الدراسي '+editing.code} onClose={()=>{if(!busy){setEditing(null);setError('');}}}><form className="form-stack" onSubmit={saveYear}><Notice>عدّل اسم العام وفترته الزمنية. تبقى بيانات الطلاب والدرجات مرتبطة بالعام نفسه، ولا يتغيّر تحديد العام الحالي.</Notice><label className="field"><span>اسم العام الدراسي</span><input name="code" required maxLength={20} defaultValue={editing.code}/></label><div className="form-grid"><label className="field"><span>بداية العام</span><input name="starts_on" type="date" required defaultValue={editing.starts_on}/></label><label className="field"><span>نهاية العام</span><input name="ends_on" type="date" required defaultValue={editing.ends_on}/></label></div>{error&&<Failure message={error}/>}<div className="actions"><button className="button primary" disabled={busy}>حفظ التغييرات</button><button className="button" type="button" disabled={busy} onClick={()=>{setEditing(null);setError('');}}>إلغاء</button></div></form></Dialog>}
 {preview&&<Dialog title={'حذف العام الدراسي '+preview.code} onClose={()=>{if(!busy){setPreview(null);setError('');}}}><div className="form-stack"><Notice>راجع محتويات العام قبل الحذف النهائي. لا يوجد زر تراجع؛ الاستعادة تحتاج إلى النسخة الاحتياطية. لا تُحذف بيانات الأعوام الأخرى.</Notice><div className="table-wrap" style={{maxHeight:240,overflow:'auto'}}><table><thead><tr><th>البيانات التي ستُحذف</th><th>العدد</th></tr></thead><tbody>{preview.counts.map(row=><tr key={row.label}><td>{row.label}</td><td>{num(row.count)}</td></tr>)}</tbody></table></div><p>تُحفظ سجلات التدقيق وحسابات الدخول العامة والنسخ الاحتياطية.</p><label className="field"><span>اكتب اسم العام للتأكيد: {preview.code}</span><input aria-label="اسم العام لتأكيد الحذف" value={typed} onChange={e=>setTyped(e.target.value)} autoComplete="off"/></label><label className="toggle"><input type="checkbox" checked={ack} onChange={e=>setAck(e.target.checked)}/>راجعت البيانات وأوافق على حذف هذا العام وبياناته.</label>{error&&<Failure message={error}/>}<div className="actions"><button className="button danger-button" disabled={busy||!ack||typed!==preview.code} onClick={remove}>تأكيد حذف العام نهائياً</button><button className="button" disabled={busy} onClick={()=>{setPreview(null);setError('');}}>إلغاء</button></div></div></Dialog>}
 </>;
}
