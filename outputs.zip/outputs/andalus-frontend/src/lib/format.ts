export const roleName = { SYSTEM_ADMIN: 'مدير النظام', PRINCIPAL: 'المدير', TEACHER: 'المعلم' };
export function num(value: number | string | null | undefined, decimals = 0) {
  if (value === null || value === undefined || value === '') return '—';
  return new Intl.NumberFormat('ar-QA', { maximumFractionDigits: decimals, minimumFractionDigits: decimals }).format(Number(value));
}
export const pct = (value: number | string | null | undefined) => value == null ? '—' : `${num(value, 2)}٪`;
export function date(value: string) {
  return new Intl.DateTimeFormat('ar-QA', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Qatar' }).format(new Date(value.endsWith('Z') ? value : value + 'Z'));
}
export function downloadCsv(filename: string, rows: (string | number | null)[][]) {
  const escaped = rows.map(row => row.map(value => {
    let text = value == null ? '' : String(value);
    if (/^[=+\-@\t\r]/.test(text)) text = "'" + text;
    return '"' + text.replaceAll('"', '""') + '"';
  }).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF' + escaped], { type: 'text/csv;charset=utf-8;' }));
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
}
