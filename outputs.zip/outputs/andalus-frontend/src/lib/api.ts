export class ApiError extends Error { constructor(message: string, public status: number) { super(message); } }

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`/api/backend/${path}`, { ...init, credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json', ...init.headers } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && typeof window !== 'undefined') window.location.assign('/login?expired=1');
    const detail = Array.isArray(data.detail) ? 'تحقق من الحقول المطلوبة وصحة القيم المدخلة.' : data.detail;
    throw new ApiError(typeof detail === 'string' ? detail : 'تعذر إتمام الطلب', response.status);
  }
  return data as T;
}

export const send = <T,>(path: string, data: unknown, method = 'POST') => api<T>(path, { method, body: JSON.stringify(data) });

export function query(values: Record<string, string | boolean | undefined>) {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) if (value !== undefined && value !== '') search.set(key, String(value));
  return search.toString();
}
