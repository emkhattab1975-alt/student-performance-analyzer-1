import { createHash } from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';

const backend = (process.env.BACKEND_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');
const appOrigin = new URL(process.env.APP_ORIGIN || 'http://127.0.0.1:3000').origin;
export const accessCookie = 'andalus_access';
export const refreshCookie = 'andalus_refresh';
type Tokens = { access_token: string; refresh_token: string; expires_in: number };
const refreshing = new Map<string, { expires: number; task: Promise<Tokens | null> }>();

export function validOrigin(request: NextRequest) {
  return request.headers.get('origin') === appOrigin;
}

export function jsonError(detail: string, status = 400) {
  return NextResponse.json({ detail }, { status, headers: { 'Cache-Control': 'no-store' } });
}

export async function backendFetch(path: string, init: RequestInit = {}) {
  return fetch(`${backend}/api/v1/${path}`, { ...init, cache: 'no-store', signal: AbortSignal.timeout(path.includes('/imports/') ? 180000 : 30000) });
}

export function setTokens(response: NextResponse, tokens: Tokens) {
  const common = { httpOnly: true, secure: appOrigin.startsWith('https:'), sameSite: 'lax' as const, path: '/' };
  // Keep access cookie longer than JWT lifetime so the server can renew transparently.
  response.cookies.set(accessCookie, tokens.access_token, { ...common, maxAge: 60 * 60 * 24 * 7 });
  response.cookies.set(refreshCookie, tokens.refresh_token, { ...common, maxAge: 60 * 60 * 24 * 7 });
}

export function clearTokens(response: NextResponse) {
  response.cookies.set(accessCookie, '', { httpOnly: true, path: '/', maxAge: 0 });
  response.cookies.set(refreshCookie, '', { httpOnly: true, path: '/', maxAge: 0 });
}

async function renew(refresh: string): Promise<Tokens | null> {
  const now = Date.now();
  for (const [key, value] of refreshing) if (value.expires < now) refreshing.delete(key);
  const key = createHash('sha256').update(refresh).digest('hex');
  const existing = refreshing.get(key);
  if (existing) return existing.task;
  // One Node process is the supported LAN topology. Parallel requests share one rotation.
  const task = backendFetch('auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: refresh }) })
    .then(async response => response.ok ? response.json() as Promise<Tokens> : null);
  refreshing.set(key, { expires: now + 30000, task });
  return task;
}

export async function proxy(request: NextRequest, path: string) {
  const access = request.cookies.get(accessCookie)?.value;
  const refresh = request.cookies.get(refreshCookie)?.value;
  if (!access && !refresh) return jsonError('انتهت الجلسة، يرجى تسجيل الدخول', 401);
  const body = ['GET', 'HEAD'].includes(request.method) ? undefined : await request.text();
  if (body && Buffer.byteLength(body, 'utf8') > 2_000_000) return jsonError('حجم الطلب أكبر من المسموح', 413);
  const call = (token: string) => backendFetch(path, { method: request.method, headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }, body });
  let upstream = access ? await call(access) : null;
  let tokens: Tokens | null = null;
  if ((!upstream || upstream.status === 401) && refresh) {
    tokens = await renew(refresh);
    if (tokens) upstream = await call(tokens.access_token);
  }
  if (!upstream || upstream.status === 401) {
    const response = jsonError('انتهت الجلسة، يرجى تسجيل الدخول', 401);
    clearTokens(response);
    return response;
  }
  const response = new NextResponse(await upstream.text(), { status: upstream.status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });
  if (tokens) setTokens(response, tokens);
  return response;
}

