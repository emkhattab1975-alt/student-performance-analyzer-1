/** @type {import('next').NextConfig} */
const config = {
  distDir: process.env.ANDALUS_BUILD_DIR || (process.env.NODE_ENV === 'production' ? '.next-production' : '.next'),
  experimental: { cpus: 1 },
  cleanDistDir: process.env.ANDALUS_PRESERVE_BUILD !== '1',
  poweredByHeader: false,
  async headers() {
    return [{ source: '/:path*', headers: [
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'same-origin' },
      { key: 'X-Frame-Options', value: 'DENY' },
      { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
    ] }];
  },
};
export default config;

